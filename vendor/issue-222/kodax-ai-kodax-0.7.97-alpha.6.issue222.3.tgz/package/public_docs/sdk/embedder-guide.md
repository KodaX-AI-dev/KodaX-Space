# KodaX SDK — Product Client and Host Integration

This page describes the current FEATURE_298/299/301 development tree, checked against
package version `0.7.97-alpha.6`. The version alone does not claim that all current
working-tree changes are already published to npm. Check the installed
package exports and the connected Host's capabilities when migrating.

For applications sharing KodaX sessions, use `KodaXProductClient` from
`@kodax-ai/kodax/client`. The Host owns execution, configuration and persistence;
clients submit intent, answer interactions and render Host facts. The old
`KodaXClient` / `Client` classes and low-level Runtime facade are different
objects, not alternate names for this contract.

- [Product integration](#product-client-integration): connection and lifecycle.
- [Migration guide](../../docs/SDK_MIGRATION.md): old-to-new calls, ownership,
  errors, history, cancellation and acceptance checklist (Chinese).
- [Complete Client contract](../../docs/CLIENT_CONTRACT.md): normative behavior
  and method inventory; [types](../../packages/coding/src/client-contract.ts).
- [Removed surfaces](#migrating-to-v0797): breaking changes and replacements.
- [Space Host seams](../../docs/SPACE_SDK_SEAMS.md): trusted Main authorization,
  canonical Fork/Retry/Rewind, Host configuration, attachments, statistics and lifecycle limits.
- [Optional Artifact SDK](#optional-artifact-sdk): shared-Host or independent Node
  file rendering, current PNG evidence, preparation and supported format limits.
- Numbered sections below retain low-level library/Host guidance and historical
  release context. They are not instructions for a product UI to create its own
  execution owner or write the shared Host's files.

## Product Client integration

### Choose the connection entry

| Need | Entry | Ownership |
| --- | --- | --- |
| Start or attach a local compatible Host | `ensureKodaXClient(options)` | Uses the shared launcher; updates only an eligible idle Host |
| Attach without starting or replacing a Host | `connectKodaXClient(options)` | Passive Node connection |
| Browser/UI contract types | `import type` from `/client` or `@kodax-ai/coding/client-contract` | No running Host or browser transport is provided by types |
| Trusted Host bootstrap, scoped credentials, Host Tools, explicit embedding | `/runtime` | Separate low-level authority; never a fallback after product connection failure |
| Independent Agent/LLM/coding library | `/agent`, `/llm`, `/coding` | Independently usable; not a shared-Session product client |

Both product constructors return `Promise<KodaXProductClient>`. The `/client`
subpath is ESM; CommonJS hosts use `await import('@kodax-ai/kodax/client')`.
It is not a root-entry re-export. `endpoint` is a local named pipe/Unix socket,
not an HTTP/WebSocket address. A browser application needs its own supported
bridge; do not import the Node connector into browser code.

`homeDir` is the base directory containing `.kodax`, not `.kodax` itself.
`connect` additionally accepts `endpoint` and `token`; `ensure` accepts
`daemonStartupTimeoutMs`. Both accept `profile` and `clientInfo`. Presentation
metadata such as `clientInfo.name` grants no authority. Configure provider
credentials at the Host, rather than passing API keys in input submissions.
Both also accept trusted Main's optional `authorizeExecution`; see the
[Host authorization seam](../../docs/SPACE_SDK_SEAMS.md#可信执行授权).

### Show local startup progress

Both entries accept an optional `onStartupProgress` callback with the shared
`ClientStartupProgress` data type. Its stages are `checking`, `starting`,
`upgrading`, `waiting`, `connecting` and `ready`. `ensure` reports the actual
local launcher stages; passive `connect` only reports `connecting` and `ready`.
For `waiting`, `reason` is `connected_clients`, `host_starting` or `host_stopping`:
waiting for other clients to disconnect, a Host to start, or the previous Host
to exit. It does not forcibly stop busy clients or work. The low-level
`ensureKodaXRuntime` / `connectKodaXRuntime` entries accept the same callback;
the type is also exported by `/runtime` and the pure contract entry.

```ts
import { ensureKodaXClient, type ClientStartupProgress } from '@kodax-ai/kodax/client';

export async function openProductClient(
  showProgress: (progress: ClientStartupProgress) => void,
  hideProgress: () => void,
) {
  try {
    return await ensureKodaXClient({ onStartupProgress: showProgress });
  } finally {
    hideProgress(); // Also clear the indicator when startup fails.
  }
}
```

`ready` means authentication and capability checks have passed and Client APIs
are usable. It does not mean a UI has rendered or a Session has loaded. Stages
may repeat during existing retries; identical consecutive events are merged.
No per-poll event stream or persistent startup log is added. Callbacks run
locally and are not awaited; synchronous errors and rejected promises go to
the existing diagnostic sink without changing startup's result. Keep rendering
callbacks quick. Existing calls without the callback continue to work.

For `/repl` consumers, optional `onBeforeRender` fires immediately before the
session restoration notices and initial banner/TUI output so a caller can clear
its terminal loading indicator. It directly replaces the unreleased startup
display hook `onReady`, with no alias. This is a separate display handoff from
the launcher's `ready` stage; other UIs own their render boundary.

### Observe, submit, and settle

The following helper uses an existing Client and Session. The application owns
connection/session selection and supplies renderers that replace the displayed
view and answer `view.interactions` through `client.interactions.respond`.
Without an interaction UI, a Run can legitimately wait for an answer. This
example neither auto-approves requests nor infers completion from rendering.

```ts
import type {
  KodaXProductClient, ClientSessionView, ClientObservationStatus,
} from '@kodax-ai/kodax/client';

export async function submitImmediate(
  client: KodaXProductClient,
  sessionId: string,
  inputId: string,
  text: string,
  render: (view: ClientSessionView) => void,
  showConnection: (status: ClientObservationStatus) => void,
) {
  const observation = await client.sessions.observe(sessionId, render, {
    onStatus: showConnection,
  });
  try {
    const accepted = await client.inputs.submit({
      sessionId, inputId, text, delivery: 'immediate',
    });
    if (accepted.state !== 'submitted' || !accepted.runId) {
      throw new Error(`Input ${inputId} is ${accepted.state}; inspect its receipt before continuing.`);
    }
    return await client.runs.await(accepted.runId);
  } finally {
    observation.close(); // Detaches this observer; does not stop the Run.
  }
}
```

Keep `inputId`, original text and artifacts before calling this helper. After a
lost response query `inputs.read(sessionId, inputId)` on the same Host; never
silently create a new ID and resubmit. This helper handles only immediate
submission; queued, steer and redirect flows must follow their acceptance state.

Create/select sessions using `client.sessions.create({projectPath})` or
`list/read`. Use `client.sessions.updateSettings` for execution choices, then
submit input. On application disposal call `client.disconnect()`; use
`runs.stop` or `sessions.cancel` for explicit Stop, and `host.shutdown()` only
for an explicit request to close an idle Host. `phase: 'unknown'` from
`runs.await` is an uncertain outcome, not success, even on a healthy connection.

### Replace the consumption model

| Concern | Product surface | Consumer responsibility |
| --- | --- | --- |
| Current UI | `sessions.observe` | Replace each view; bounded items are not a complete transcript |
| Full display item | `sessions.readItem` | Keep the observed ID; validate paginated original text/input; image attachments use separate byte offsets and hashes |
| History/search | `readHistory`, `readHistoryEntry`, `searchHistory` | Keep page revision and distinct history IDs; no cross-revision splicing |
| Settings and discovery | `sessions.*Settings`, `config.*`, `catalog.*` | Distinguish saved overrides/defaults from effective settings |
| User questions and permissions | `interactions.list/respond`, `view.interactions` | Reply to the exact request; use only Host-provided grant suggestions |
| Commands/Skills/review | `commands.*`, `inputs.submit`, `review.start` | Host prepares trusted execution; returned Run IDs are followed, not resubmitted |
| Command feedback | `sessions.appendNotice` | Durable client-only notices; report failures without re-running commands |
| MCP/Agents/Memory/Learning/Workflow | `mcp`, `registrations`, `agents`, `memory`, `learning`, `workflows` | Use domain operations; keep executable modules and local owners out of UI code |

Observation connection errors, pending interactions and Run terminal outcomes
are separate facts. Workflow/Learning subscription `ready` confirms registration,
not snapshot synchronization; rebuild a failed subscription and read its current
snapshot. Reconnect does not authorize replaying mutations. See the complete
Client contract for nullable reads, revision conflicts, lifecycle error handling,
and feature-specific Host compatibility checks.

## Optional Artifact SDK

Install `@kodax-ai/artifacts` separately (ESM, Node >=20.16). Its root SDK/types
have no KodaX or renderer dependency; `/runtime` supplies an independently
authorized Node host. For a product UI sharing KodaX, register the `/kodax`
adapter once in the trusted Host and bind the SDK to the existing Client/Session:

```ts
import type { KodaXProductClient } from '@kodax-ai/kodax/client';
import { createArtifactSdk } from '@kodax-ai/artifacts';
import { createKodaXArtifactPort } from '@kodax-ai/artifacts/client';

export function artifactSdk(client: KodaXProductClient, sessionId: string) {
  return createArtifactSdk(createKodaXArtifactPort(client, sessionId));
}
```

The nine operations are `capabilities`, `prepare`, `create`, `open`, `edit`,
`export`, `render`, `capture` and `readEvidence`. PPTX supports authoring and
limited edits/export; PDF, PNG/JPEG/WebP/SVG, candidate DOCX pagination, local
HTML loaded viewports and SVG SMIL samples provide actual visual evidence.
DOCX page count belongs to rendered layout; Word/WPS fidelity remains unverified.
`capture` requires kind-matched locators, and `readEvidence` checks source,
dependencies, provenance, PNG hash and geometry before returning actual bytes.

The shared port uses existing tool Runs and bounded PNG attachment reads through
`sessions.readItem`; it adds no Client domain or local fallback renderer. Image
chunks use byte offsets, distinct from text offsets, and never appear in text
projections/logs. Cancellation stops only the admitted Run and awaits settlement;
busy/disconnected/unknown results are not replayed. Compatible Host support is
required. Core startup does not load renderers, and browser preparation is explicit.

Rendering is headless and can run on a terminal-only system. Automatic review
uses shared Agent guidance, available tools and a provider accepting real images,
without a user slash command. The SDK does not call a separate model judge;
`ready` and coverage checks do not certify quality. Full natural-task repair,
re-review and delivery have not passed all model smoke checks.

See [support, setup and examples](../../docs/ARTIFACT_SDK.md),
[pre-release contract migration](../../docs/SDK_MIGRATION.md#artifact-sdk-契约迁移2026-10-13)
and [E2E evidence/known schema gap](../../docs/research/automatic-visual-review-e2e-2026-10-13.md).
These additions ship in `v0.7.97-alpha.5`; an installed npm package from an
earlier version does not include them.

## Low-level reference and release history

The sections below describe independent libraries, trusted Host capabilities and
past release decisions. Their examples are scoped to those layers. Product UI
migrations follow the entry and lifecycle above; retained low-level exports do
not mean every low-level capability has a Product Client equivalent. Historical
capability versions and removed APIs must be read with the migration table.
This guide documents the SDK surfaces a host integrator needs that
are NOT obvious from inspecting the type definitions alone:

1. [MCP server management — `McpManager` runtime API](#1-mcp-server-management--mcpmanager-runtime-api)
2. [Skill `!`cmd`` dynamic-context resolution + `IVariableResolver`](#2-skill-cmd-dynamic-context-resolution--ivariableresolver)
3. [Per-app data directory namespacing — `getAppDataDir`](#3-per-app-data-directory-namespacing--getappdatadir)
4. [Cross-reference: other FEATURE_186 surfaces](#4-cross-reference-other-feature_186-surfaces)
5. [Consuming from a CommonJS context (Electron main, CJS bundles)](#5-consuming-from-a-commonjs-context-electron-main-cjs-bundles)
6. [Session persistence — wiring `runKodaX` to disk](#6-session-persistence--wiring-runkodax-to-disk)
7. [Local development via `npm link` (iterating against in-tree KodaX)](#7-local-development-via-npm-link-iterating-against-in-tree-kodax)
8. [User-authored agents — markdown loader + extension `registerAgent`](#8-user-authored-agents--markdown-loader--extension-registeragent-feature_191-v0743)
9. [Electron + `stdio: 'inherit'` on Windows — PowerShell input hijack](#9-electron--stdio-inherit-on-windows--powershell-input-hijack)
10. [Model capabilities — context window, reasoning, descriptors](#10-model-capabilities--context-window-reasoning-descriptors)
11. [Workflow process events and lifecycle controls](#11-workflow-process-events-and-lifecycle-controls-feature_229-v0750)
12. [Provider credential verification — `verifyProviderCredential`](#12-provider-credential-verification--verifyprovidercredential-feature_216-v0745)
13. [Inject your product's manual — `selfManual`](#13-inject-your-products-manual--selfmanual-feature_221-v0747)
14. [Media input artifacts — `@kodax-ai/kodax/media`](#14-media-input-artifacts--kodax-aikodaxmedia-feature_239-v0756)
15. [Space v0.7.57 follow-up ledger](#15-space-v0757-follow-up-ledger)
16. [SDK agent-profile surface — `KodaXAgentProfile`](#16-sdk-agent-profile-surface--kodaxagentprofile-feature_247-v0758)
17. [Runtime SDK and local daemon](#17-runtime-sdk-and-local-daemon-feature_253-feature_257)
18. [External-agent executor plane](#18-external-agent-executor-plane-feature_258-v0767)
19. [Session surface filtering and cursor pagination](#19-session-surface-filtering-and-cursor-pagination-feature_261-v0767)
20. [Cost-disciplined workflow routing and telemetry](#20-cost-disciplined-workflow-routing-and-telemetry-feature_259-v0767)
21. [Experimental governed memory — `/experimental-memory`](#21-experimental-governed-memory--experimental-memory-feature_260--feature_275-v0768v0777)
22. [Bidirectional A2A 1.0 — `/a2a`](#22-bidirectional-a2a-10--a2a-feature_267-v0769)
23. [Shared Coder daemon for Space and IDE hosts](#23-shared-coder-daemon-for-space-and-ide-hosts-feature_269-v0769)
24. [Runtime-owned permission routing and plan bridges](#24-runtime-owned-permission-routing-and-plan-bridges-v0796)
25. [Always-on context compaction and bounded transcript recovery](#25-always-on-context-compaction-and-bounded-transcript-recovery-v0774)
26. [Agent mailbox control versus SDK event telemetry](#26-agent-mailbox-control-versus-sdk-event-telemetry-v0774)
27. [Windows GUI background subprocess visibility](#27-windows-gui-background-subprocess-visibility-v0775)
28. [Host-configurable Shell Execution Contract](#28-host-configurable-shell-execution-contract-v0777)
29. [Evidence-gated background Skill learning](#29-evidence-gated-background-skill-learning-feature_263-v0778)
30. [Standalone sandbox SDK](#30-standalone-sandbox-sdk-v0778)
- [Learned Skill promotion reference](#learned-skill-promotion-reference-v0778)
- [Migrating to v0.7.97](#migrating-to-v0797)

§1–§3 (and the Phase-7/8 MCP-popout surface in §1) land in v0.7.42
under FEATURE_186 (see [ADR-032](../../docs/ADR.md#adr-032-sdk-embedder-surface-closure-feature_186-v0742)).
§5 documents the ESM-only packaging contract and the canonical
`await import(...)` recipe for CJS / Electron main consumers.

> **Code examples in §1–§4 use static ESM `import`** — that's the
> shape ESM consumers (Node `"type": "module"`, Vite, modern Electron
> renderer with `nodeIntegration: true`+ESM) want. **If your host
> compiles to CJS** (Electron main process, legacy Webpack CJS bundle,
> `tsc --module commonjs`), every static `import` example becomes
> `await import(...)` — see §5 for the full recipe and bundler
> configuration.

---

## 1. MCP server management — `McpManager` runtime API

> Independent MCP library reference. Product clients use `client.mcp` and
> `client.catalog`; they do not instantiate a manager or edit the Host's JSON.

### Why this exists

`@kodax-ai/kodax/mcp` re-exports `McpCapabilityProvider`, which is the
class KodaX uses internally to plug MCP into the agent runtime. Its
methods are capability-provider-shaped (`search` / `describe` /
`execute` / `read` / `getPrompt`) — that's the substrate-facing API,
not what a popout UI needs.

`McpManager` is a thin facade exposing the **popout-shape** API for
the lifecycle operations a host UI typically renders:

```
+- MCP Servers (popout) -+
| filesystem    [Ready]  | <- listServers row
| git           [Idle]   |
| sqlite        [Error]  |
+------------------------+
| [Start] [Stop] [Logs]  | <- startServer / stopServer / getServerLogs
| [View tools]           | <- listTools / getCatalog
+------------------------+
```

### Quick start

```ts
import { createMcpManager } from '@kodax-ai/kodax/mcp';
import { listMcpServers } from '@kodax-ai/kodax/repl';

// Build manager from the persisted ~/.kodax/config.json `mcpServers` section.
// listMcpServers reads the CRUD module's view of disk state.
const manager = createMcpManager(listMcpServers());

// Enumerate all configured servers (lazy + prewarm + disabled all included).
const rows = manager.listServers();
for (const row of rows) {
  console.log(`${row.serverId}: status=${row.status}, tools=${row.tools}`);
}

// Force connect + catalog refresh for a single server.
const started = await manager.startServer('filesystem');
console.log(`filesystem now: ${started.status}, ${started.tools} tools`);

// Tools-only view (popout's "tools" tab).
const toolList = await manager.listTools('filesystem');
for (const tool of toolList.tools) {
  console.log(`  - ${tool.name}: ${tool.description ?? '(no description)'}`);
}

// Full catalog (tools + resources + prompts) — popout's "all capabilities" tab.
const catalog = await manager.getCatalog('filesystem');
for (const descriptor of catalog.descriptors) {
  console.log(`  [${descriptor.kind}] ${descriptor.id}`);
}

// Last error + status for the "Logs" pane.
const logs = manager.getServerLogs('filesystem');
console.log(`status=${logs.status}, lastError=${logs.lastError ?? '(none)'}`);

// Disconnect transport (server stays in config; status flips to idle).
await manager.stopServer('filesystem');

// Tear down all runtimes when the popout closes / app exits.
await manager.dispose();
```

### Method reference

| Method | Returns | Purpose |
|---|---|---|
| `listServers()` | `McpServerStatus[]` | One row per configured server: `status`, `tools`/`resources`/`prompts` counts, `lastError`, `cachedAt`, deep-cloned `config`. Synchronous (uses cached diagnostics). |
| `startServer(id)` | `Promise<McpServerStatus>` | Force `refreshCatalog(true)`. Connects (or reconnects), re-lists tools/resources/prompts, writes the disk cache. Throws on unknown id. |
| `stopServer(id)` | `Promise<McpServerStatus>` | Dispose transport. Server stays in config so a subsequent `startServer` / `listTools` reconnects cleanly. |
| `getServerLogs(id)` | `McpServerLogs` | `{ status, connect, lastError?, cachedAt? }`. Designed as the data source for a "Logs" pane. **v0.7.42 is intentionally conservative** — only last error + status are exposed. Future iterations may add a ring buffer; the field shape will extend, never break. |
| `listTools(id, { forceRefresh? })` | `Promise<McpServerToolList>` | Tools-only filtered descriptors. Triggers lazy connect on cold cache. |
| `getCatalog(id, { forceRefresh? })` | `Promise<McpServerCatalog>` | Full catalog: `items` (lightweight) + `descriptors` (full) for tools, resources, and prompts. |
| `dispose()` | `Promise<void>` | Dispose all runtimes. After this, build a fresh `McpManager` to reuse. |
| `provider()` | `McpCapabilityProvider` | Escape hatch — the underlying capability-provider for advanced uses. |
| `execute(id, input)` | `Promise<CapabilityResult>` | Invoke a tool by capability id (`mcp:<serverId>:tool:<name>`). |
| `describe(id)` | `Promise<McpCapabilityDescriptor \| undefined>` | Resolve a single descriptor by capability id. |
| `search(query, options?)` | `Promise<readonly McpCatalogItem[]>` | Cross-server catalog search. |
| `read(id, options?)` | `Promise<CapabilityResult>` | Read a resource by capability id. |

### Server lifecycle states

`McpServerStatus.status` values:

| Status | Meaning |
|---|---|
| `idle` | Configured, not yet connected. Lazy default until first tool call. |
| `connecting` | Connection in progress (transient). |
| `ready` | Connected, catalog cached. |
| `error` | Last connect / refresh failed. `lastError` carries the message. |
| `disabled` | `connect: 'disabled'` in config — runtime exists but won't be used. |

### Adding / removing servers

For server **config** CRUD (write to `~/.kodax/config.json`), use the
`@kodax-ai/kodax/repl` subpath — kept separate from `/mcp` to keep
the latter dependency-free:

```ts
import { listMcpServers, upsertMcpServer, removeMcpServer } from '@kodax-ai/kodax/repl';

upsertMcpServer('filesystem', {
  type: 'stdio',
  command: 'mcp-server-filesystem',
  args: ['/repo'],
  connect: 'lazy',
});

// Remote servers: `type: 'streamable-http'` or `'sse'`. For ecosystem-config
// compatibility you may also use `type: 'http'` (v0.7.48+) — a config-layer
// alias that auto-detects Streamable HTTP first, then falls back to legacy
// HTTP+SSE. OAuth-protected servers are zero-config: omit `auth` endpoint
// fields and KodaX discovers + dynamically registers on the first 401.

// In-flight `McpManager` does NOT hot-pickup config changes. The
// standard pattern is: edit config, then construct a fresh manager
// (or call dispose() + createMcpManager again) before the next agent
// turn.
await manager.dispose();
const refreshed = createMcpManager(listMcpServers());
```

### Trust boundary

KodaX is a single-user CLI; the manager is last-write-wins. A popout
that swaps configs hot constructs a fresh manager — there is no
file-locking layer in v0.7.42. If your host needs multi-process
coordination (e.g. KodaX Space's popout window AND the main agent
both writing the same config), you mediate at your IPC layer.

---

## 2. Skill `!`cmd`` dynamic-context resolution + `IVariableResolver`

### Why this exists

Skills (`SKILL.md` files in `~/.kodax/skills/<name>/` etc.) support
**dynamic context** — markdown can embed `!`shell-command`` tokens
that are replaced with the command's stdout at resolution time:

```markdown
---
name: incident-report
description: Generate an incident summary from current repo state.
---

Current git status:
!`git status --short`

Recent commits:
!`git log --oneline -10`
```

Default behavior (no host hook): `VariableResolver` directly
`execSync`s each command with an internal allowlist. **For host
applications** (KodaX Space, IDE extensions, sandboxed substrates)
this is rarely the right behavior — the host typically wants to
mediate every shell execution through its own permission broker,
audit trail, or policy gate.

v0.7.42 (FEATURE_186 Phase 3) added a host hook on `SkillContext`
that intercepts every `!`cmd`` execution.

### Invocation ownership: explicit user vs model

Skill discovery and explicit invocation are intentionally separate:

- Model invocation sees only the name/description catalog for Skills whose
  `disableModelInvocation` value is false. The coding `skill` tool enforces the
  same gate before loading full content.
- Every enabled Skill remains explicitly user-invocable. `/<name>` and
  `/skill:<name>` may appear at the head or middle of a user query; text after
  the selected token is the argument string. A request may activate only one
  known Skill; multiple references return a user-visible diagnostic and do not
  execute the first one partially.
- `SkillRegistry.invoke()` is an explicit SDK primitive. It is not blocked by
  `disable-model-invocation: true`; an embedder exposing it to a model must add
  its own model-tool admission instead of treating the registry as that gate.
- The legacy `user-invocable` frontmatter field and Runtime DTO field are kept
  for compatibility. Enabled Skills report `userInvocable: true`.

```ts
import { SkillRegistry } from '@kodax-ai/kodax/skills';

const registry = new SkillRegistry(process.cwd());
await registry.discover();

const modelCatalog = registry.getSystemPromptSnippet(); // model-visible only
const explicit = await registry.invoke('manual-only-skill', 'src/', {
  workingDirectory: process.cwd(),
  projectRoot: process.cwd(),
  disableDynamicContext: true,
});
```

Terminal embedders accepting raw user text can reuse
`resolveUserSkillInvocation` and `prepareInvocationExecution` from
`@kodax-ai/kodax/repl`. The first resolves trusted registry membership and
builds structured `skillInvocation`; the second owns hooks, permission policy,
fork context, and finalization. Expanded Skill content belongs in structured
system context exactly once, not in both the user prompt and system prompt.
`prepareInvocationExecution()` preserves the exact submitted text in
`context.rawUserInput`; canonical transcripts and titles use that field, while
generated Skill wording, lifecycle-hook context, and command expansion remain
execution-only overlays. Hosts must persist/display the raw request, not the
prepared provider prompt. A malformed or failed `PreToolUse` hook denies the
guarded tool; `PostToolUse` failures remain diagnostic because the completed
tool effect cannot be undone.

That structured field is also the delegation provenance boundary. Workflow and
child runs inherit an active explicit Skill. A slash token written only inside
a model-authored child objective is a new model invocation and must pass the
governed `skill` tool; it cannot bypass `disable-model-invocation`.

### Quick start

```ts
import { createResolver, resolveSkillContent } from '@kodax-ai/kodax/skills';
import type { SkillContext } from '@kodax-ai/kodax/skills';

const context: SkillContext = {
  workingDirectory: '/repo',
  projectRoot: '/repo',
  sessionId: 'session-1',
  environment: process.env as Record<string, string>,

  // v0.7.42 — host hook for !`cmd` execution.
  executeDynamicContext: async (command, cwd) => {
    // Route through the host's permission broker.
    const approved = await brokerAskUser({
      kind: 'skill-shell-command',
      command,
      cwd,
    });
    if (!approved) {
      throw new Error('User denied shell command execution');
    }
    // Run via the host's audited shell wrapper.
    const { stdout } = await brokerExecute(command, { cwd });
    return stdout;
  },
};

const resolved = await resolveSkillContent(skill.content, '', context);
// resolved.content has !`cmd` tokens replaced with stdout (or the
// command was rejected and the resolver substituted an error
// banner — depending on your hook's throw behavior).
```

### Disabling dynamic context entirely

For maximum-safety hosts (e.g. a security-audit popout), set
`disableDynamicContext: true` — every `!`cmd`` token is replaced with
a refusal banner regardless of any hook:

```ts
const context: SkillContext = {
  workingDirectory: '/repo',
  projectRoot: '/repo',
  sessionId: 'session-1',
  environment: {},
  disableDynamicContext: true,
};
```

### Resolution priority (3-tier dispatch)

```
+- VariableResolver.executeDynamicCommand ------+
|                                                |
|  1. context.disableDynamicContext === true    |
|     -> throw "Dynamic context disabled"       |
|                                                |
|  2. context.executeDynamicContext is set      |
|     -> await hook(command, cwd)               |
|                                                |
|  3. (legacy fallback)                         |
|     -> isSafeDynamicContextCommand allowlist  |
|     -> execSync (with built-in restrictions)  |
|                                                |
+------------------------------------------------+
```

**Hosts should always set `executeDynamicContext`** — the legacy
fallback exists for the standalone `kodax` CLI use case where the
end-user implicitly trusts their own machine's shell. Embedded
hosts have a different trust boundary (user trusts the host UI,
host UI mediates everything else).

### The LLM-triggered `skill` tool path — `KodaXOptions.skillDynamicContext` (v0.7.58)

The `SkillContext` hook above covers Skills your host explicitly expands via
`resolveSkillContent` or `SkillRegistry.invoke()`. A model-visible Skill can
also be **auto-triggered by the model** through the built-in `skill` tool — and
that path builds its own `SkillContext`
internally, so it does not see your `resolveSkillContent` hook. Without wiring,
an auto-triggered `SKILL.md` (including a cloned project-level
`.kodax/skills/*`) would run its `` !`cmd` `` blocks through the built-in
`execSync` allowlist, bypassing your permission broker.

Thread the same policy into the tool path via `runKodaX`/`startKodaX` options:

```ts
import { runKodaX } from '@kodax-ai/kodax/coding';

await runKodaX(
  {
    provider: 'anthropic',
    skillDynamicContext: {
      // Same shape as SkillContext.executeDynamicContext — route through your broker.
      execute: async (command, cwd) => brokerExecute(command, cwd),
      // …or refuse all dynamic-context commands outright:
      // disable: true,
    },
  },
  prompt,
);
```

Absent this option the tool path keeps the trusted-CLI `execSync` fallback
(unchanged), so setting `skillDynamicContext.execute` (or `disable: true`) is the
supported way for an embedder to bring the auto-triggered path under the same
policy as the manual one.

### `IVariableResolver` entry points

| Symbol | Purpose | Source |
|---|---|---|
| `IVariableResolver` (interface) | Type contract — `resolve(content): Promise<string>` | `@kodax-ai/kodax/skills` |
| `VariableResolver` (class) | Stock implementation; reads `context.executeDynamicContext` if present, otherwise legacy `execSync` | `@kodax-ai/kodax/skills` |
| `createResolver(context)` (factory) | Returns a fresh `IVariableResolver` bound to the given context | `@kodax-ai/kodax/skills` |
| `resolveSkillContent(content, args, context)` (top-level) | High-level convenience — constructs resolver internally + resolves a single skill body | `@kodax-ai/kodax/skills` |

Hosts that want to ship a fully custom resolver (e.g. replace the
default with a JS-only sandbox) can implement `IVariableResolver`
directly and call `resolver.resolve(content)` themselves — KodaX's
own skill execution path calls through this interface.

### Argument parsing

`parseArguments(args: string): string[]` is exported alongside the
resolver. Use it to convert the raw `$ARGS` string into a parsed
positional array matching the skill's `argumentHint`.

---

## 3. Per-app data directory namespacing — `getAppDataDir`

### Why this exists

`~/.kodax/` is KodaX's own state directory — sessions, custom
providers, MCP servers, instances heartbeat, etc. all live under it.
Embedder hosts often need their **own** state directory adjacent to
KodaX's:

- IDE extension: store extension-local cache (`recents`, layout
  prefs, popout snapshot).
- KodaX Space: store desktop-app preferences (window position,
  theme, last-opened project).

Letting every host pick its own dir leads to multi-app conflict
(two extensions both writing `~/.kodax/cache/`) — and writing
inside `~/.kodax/` itself risks collision with KodaX's own keys.

`getAppDataDir(appId)` carves out a namespaced subdirectory under
`<KODAX_HOME>/apps/<appId>/` with reserved-name guards.

### Quick start

```ts
import { getAppDataDir } from '@kodax-ai/kodax/coding';

// Returns <KODAX_HOME>/apps/space/  (default: ~/.kodax/apps/space/)
// mkdirSync({recursive:true}) is called for you.
const spaceDir = getAppDataDir('space');

// Persist host-specific state inside that dir.
writeFileSync(path.join(spaceDir, 'window-state.json'), JSON.stringify(state));
```

### Namespace rules

`appId` is validated against `^[a-z][a-z0-9-]{1,31}$`:

- Must start with a lowercase letter.
- May contain lowercase letters, digits, `-`.
- 2-32 characters total.
- Reserved prefix: `kodax-*` (and the bare string `kodax`) — rejected
  to prevent host apps from squatting on names that look like KodaX's
  own subsystems.

| `appId` | Result |
|---|---|
| `space` | ✓ `<KODAX_HOME>/apps/space/` |
| `kodax-space-helper` | ✗ `Error: reserved appId prefix 'kodax-*'` |
| `MyApp` | ✗ `Error: appId must match /^[a-z][a-z0-9-]{1,31}$/` |
| `a` | ✗ `Error: appId must be 2-32 chars` |

### Interaction with `setAgentConfigHome`

`getAppDataDir` resolves `<KODAX_HOME>` via `getAgentConfigHome()` on
every call — so a host that called `setAgentConfigHome('/custom')`
before the first `getAppDataDir('space')` lands at
`/custom/apps/space/`. Useful for:

- **Tests**: per-test temp dir override.
- **Multi-tenant**: route different tenants to different home dirs.

```ts
import { setAgentConfigHome, getAppDataDir } from '@kodax-ai/kodax/coding';

setAgentConfigHome('/srv/tenant-42/.kodax');
const dir = getAppDataDir('space');
// dir === '/srv/tenant-42/.kodax/apps/space/'
```

---

## 4. Cross-reference: other FEATURE_186 surfaces

The three surfaces above are the most "needs-a-guide" pieces.
FEATURE_186 ships several additional SDK exports that are self-
documenting from type signatures but are worth knowing:

| Subpath | Symbol | Purpose |
|---|---|---|
| `@kodax-ai/kodax` | `runKodaX(opts, prompt)` | Blocking `Promise<KodaXResult>` — the original entry. |
| `@kodax-ai/kodax/coding` | `startKodaX(opts, prompt): RunningSession` | Non-blocking handle. See [RunningSession docs](#running-session-quick-reference). |
| `@kodax-ai/kodax/coding` | `createSessionControl()` | Bare `KodaXSessionControl` for advanced wiring. |
| `@kodax-ai/kodax/coding` | `getAgentConfigPath(name)` | Resolves `<KODAX_HOME>/<name>` dynamically. |
| `@kodax-ai/kodax/coding` | `setAgentConfigHome(path \| undefined)` | Override KODAX_HOME for tests / multi-tenant. |
| `@kodax-ai/kodax/coding` | `validateCustomProviderConfig(config)` | Same validator the SDK uses internally — no parallel schemas. |
| `@kodax-ai/kodax/coding` | `ToolSideEffect` + 4 helpers | Tool metadata (`readonly` / `mutates-fs` / `mutates-shell` / `mutates-network` / `mutates-state`) for plan-mode gates + custom permission UIs. |
| `@kodax-ai/kodax/coding` | `loadAgentsFiles(opts?)` | Load `AGENTS.md` cascade (project + user + global) for prompt assembly. |
| `@kodax-ai/kodax/repl` | `bootstrapAutoMode(...)` | Compatibility bootstrap for a standalone Auto reviewer; Runtime hosts own normal host-boundary review. |
| `@kodax-ai/kodax/repl` | `loadCommands(...)` / `KODAX_COMMANDS_DIR` | Discover user-defined slash commands. |
| `@kodax-ai/kodax/repl` | `listCustomProviders` / `upsertCustomProvider` / `removeCustomProvider` | Custom LLM provider CRUD. |
| `@kodax-ai/kodax/repl` | `listMcpServers` / `upsertMcpServer` / `removeMcpServer` / `validateMcpServerConfig` | MCP server config CRUD. |
| `@kodax-ai/kodax/skills` | `IVariableResolver` / `VariableResolver` / `createResolver` | See [section 2](#2-skill-cmd-dynamic-context-resolution--ivariableresolver). |

### RunningSession quick reference

```ts
import { startKodaX } from '@kodax-ai/kodax/coding';

const session = startKodaX({ provider: 'anthropic', model: 'claude-sonnet-4-6' }, 'review this PR');
console.log(session.id);                // freshly minted or echoes opts.session.id

// Mid-run mutators — applied on the next turn (CAP-055 per-turn re-resolution).
session.setProvider('zhipu');
session.setModel('glm-4.6');
session.setReasoning('balanced');       // KodaXReasoningMode: 'off' | 'auto' | 'quick' | 'balanced' | 'deep'

// Cooperative abort.
setTimeout(() => session.abort('user cancelled'), 30_000);

// Await the eventual result.
const result = await session.result;
console.log(result.finalMessage);
```

Constructor-supplied `options.abortSignal` is forwarded into the
internal `AbortController`; calling either signal aborts the run.

---

## 5. Consuming from a CommonJS context (Electron main, CJS bundles)

### TL;DR

`@kodax-ai/kodax` and **all** its subpaths are published **ESM-only**.
In a CommonJS context — Electron's main process (`vm.mainModule` runs
as CJS by default), legacy Webpack/esbuild configs with
`format: 'cjs'`, or any code path that ends up calling `require()` —
you must use dynamic `import()` instead of static `import` /
`require`. Both Node 22+ and Node 20.19+ support dynamic-importing
ESM from CJS without flags.

```ts
// ❌ This breaks in CJS — esbuild / tsc transforms static `import`
//    into `require('@kodax-ai/kodax/mcp')`, which Node then rejects
//    with ERR_PACKAGE_PATH_NOT_EXPORTED because our `exports` only
//    declares the `import` condition.
import { McpManager } from '@kodax-ai/kodax/mcp';

// ✅ Use dynamic import — Node resolves it via the ESM loader and
//    matches our `import` condition.
const { McpManager } = await import('@kodax-ai/kodax/mcp');
```

`import type { ... }` is **fine in CJS** — TypeScript / esbuild strip
type-only imports at compile time, so they never become runtime
`require()` calls:

```ts
import type { McpManager, McpServerStatus } from '@kodax-ai/kodax/mcp';
// ↑ compiles to nothing at runtime
```

### Why we don't ship dual ESM/CJS bundles

The natural fix would be to add `"require": "./dist/sdk-*.cjs"` next
to the existing `"import"` condition in `package.json#exports`. We
investigated this for v0.7.42 and the technical reality blocks all
the subpaths embedders typically reach for:

| Subpath | ESM-only third-party deps inlined | Dual feasible? |
|---|---|---|
| `/agent` | 0 | ✅ feasible (no UI deps) |
| `/mcp` | 0 | ✅ feasible (no UI deps) |
| `/skills` | 1 (`yaml`) | ❌ |
| `/llm` | 2 (`@agentclientprotocol/sdk`, `partial-json`) | ❌ |
| `/coding` | 4 (`yaml`, `tsx`, …) | ❌ |
| `/repl` | **21** (`ink`, `chalk`, `react`, `ansi-escapes`, …) | ❌ |
| root | 21 (same as `/repl`) | ❌ |

Once a bundle inlines any ESM-only dependency, the bundle itself
cannot be a valid CJS module — `require()`ing it would synchronously
import an ESM dep, which Node refuses. `ink`, `chalk`, and most of
the modern terminal-UI ecosystem are ESM-only as of 2024–2026, with
no plans to dual-publish.

**Dynamic `import()` is the canonical fix**, not a workaround. It
is part of the ECMAScript standard, supported in CJS contexts by
spec, and is how Node itself recommends consuming ESM from CJS today.

### Electron main process recipe

Electron's main process is CJS by default (`require('electron')`
works because main runs without `"type": "module"`). The pattern
that drops cleanly into existing Electron code:

```ts
// main.ts (or main.cjs) — Electron main process
import type { McpManager } from '@kodax-ai/kodax/mcp';            // compile-time only
import type { RunningSession } from '@kodax-ai/kodax/coding';     // compile-time only

let mcpManager: McpManager | null = null;
let kodax: typeof import('@kodax-ai/kodax/coding') | null = null;

async function bootKodaX() {
  // Bundle these dynamic imports as runtime-resolved (don't let
  // esbuild rewrite them — see "Bundler config" below).
  const { createMcpManager } = await import('@kodax-ai/kodax/mcp');
  const { listMcpServers } = await import('@kodax-ai/kodax/repl');

  kodax = await import('@kodax-ai/kodax/coding');
  mcpManager = createMcpManager(listMcpServers());
}

app.whenReady().then(bootKodaX);

// Wire to IPC handlers — your popout UI calls these.
ipcMain.handle('mcp:listServers', () => mcpManager!.listServers());
ipcMain.handle('mcp:startServer', (_, id: string) => mcpManager!.startServer(id));
ipcMain.handle('mcp:listTools', (_, id: string) => mcpManager!.listTools(id));
ipcMain.handle('mcp:getServerLogs', (_, id: string) => mcpManager!.getServerLogs(id));

ipcMain.handle('kodax:run', async (_, prompt: string) => {
  const session = kodax!.startKodaX({ provider: 'anthropic', model: 'claude-sonnet-4-6' }, prompt);
  return session.result;
});
```

### Bundler configuration

Most bundlers (esbuild, Webpack, Vite, Rollup) will, by default,
transform `await import(x)` into `require(x)` when targeting CJS.
You must tell the bundler to **preserve** the dynamic import:

**esbuild**:

```js
build({
  format: 'cjs',
  platform: 'node',
  // Keep dynamic imports as-is so they resolve to the ESM bundle at runtime.
  external: ['@kodax-ai/kodax', '@kodax-ai/kodax/*'],
})
```

Alternatively, mark only `@kodax-ai/kodax` as external — bundlers
that respect `external` will not rewrite dynamic imports of external
modules.

**Webpack**: add `@kodax-ai/kodax` (and any subpaths you use) to
`externals`, e.g. `{ '@kodax-ai/kodax/mcp': 'commonjs2 @kodax-ai/kodax/mcp' }`.

**Vite**: in `vite.config.ts` SSR / Electron-main builds, add
`@kodax-ai/kodax` and subpaths to `ssr.external`.

If the bundler still rewrites the dynamic import, the symptom is a
synchronous `Error: ERR_REQUIRE_ESM` (Node ≤ 20) or
`ERR_PACKAGE_PATH_NOT_EXPORTED` (Node 22+). Fix the bundler config
before suspecting our package.

### When you really need synchronous CJS

If your host environment cannot adopt `await import(...)` (rare —
even old Webpack supports it via `import()` syntax preserved through
to runtime), the two subpaths with zero ESM-only deps (`/agent` and
`/mcp`) are the **only** ones that could in principle ship a CJS
build. We have not productized this yet — file an issue with your
concrete blocker (sync popout startup, specific bundler limitation,
etc.) and we'll evaluate adding a partial-dual emit for those two
subpaths in a follow-up release.

### Quick checklist before reporting "it doesn't work in CJS"

- [ ] `package.json#type` in **your** project — if it's `"module"`,
      static `import` works; if absent / `"commonjs"`, you need
      dynamic `await import()`.
- [ ] Your bundler emit format — `format: 'cjs'` + static `import`
      from KodaX subpaths will always fail.
- [ ] You used `import type { ... }` not `import { ... }` for
      type-only references (otherwise they survive as runtime
      `require`).
- [ ] Bundler is set to **external** `@kodax-ai/kodax` (or skip
      bundling subpath imports entirely).
- [ ] Node version ≥ 20.19 (or ≥ 22 for the more permissive
      `--experimental-require-module` default).

---

## 6. Session persistence — wiring `runKodaX` to disk

> Independent in-process library ownership only. Product clients use
> `client.sessions` and never attach a `SessionStorage` to a shared Host.

### The trap

```ts
import { runKodaX } from '@kodax-ai/kodax/coding';

await runKodaX(
  {
    provider: 'zhipu-coding',
    session: { id: 's_my_chat', scope: 'user' },  // ← session.id set
  },
  'reply with: ok',
);
// ✗ Run completes, LLM streams, events fire — but
// ~/.kodax/sessions/s_my_chat.jsonl does NOT exist.
```

`session.id` alone is **not** enough. The SDK's snapshot path is
gated on `options.session.storage`:

```ts
// packages/coding/src/agent-runtime/middleware/session-snapshot.ts
if (!options.session?.storage) {
  return;   // silent no-op
}
```

This is by design — the CLI ships its own storage wiring, and the
SDK doesn't want to force a disk-write side-effect onto every
embedder (some hosts persist to a DB / cloud / IndexedDB instead).
But the contract was previously **undocumented**, so SDK consumers
typically hit this once before learning the rule.

**v0.7.43 added a one-shot `console.warn` when `session.id` is set
but `session.storage` is missing** — it points at this section.

**v0.7.63 narrows that warning to caller-provided session IDs.** The
`startKodaX()` convenience wrapper may generate a handle ID for the returned
running-session object; that generated ID is threaded into the run only when it
will not override auto-resume/resume discovery, and it no longer triggers the
missing-storage warning by itself.

### The canonical fix

```ts
import { runKodaX } from '@kodax-ai/kodax/coding';
import {
  createSessionManager,
  exportSessionBundle,
} from '@kodax-ai/kodax/session';

// One manager per host process; reuse across runs so the
// per-session write queue + append-watermark caches stay coherent.
const {
  storage,
  listSessions,
  loadSession,
  loadFullTranscript,
  readFullTranscript,
  readSessionCapture,
  appendClientNotice,
  compactSession,
} = createSessionManager();

await runKodaX(
  {
    provider: 'zhipu-coding',
    session: {
      id: 's_my_chat',
      scope: 'user',
      storage,                  // ← key — wire the storage instance
    },
  },
  'reply with: ok',
);
// ✓ ~/.kodax/sessions/s_my_chat.jsonl now exists after the run.

// Same `storage` instance reads back through SessionManager:
const recent = await listSessions({
  scope: 'user',
  surface: 'acp',
  limit: 50,
});
const nextPage = recent.at(-1)?.cursor
  ? await listSessions({
      scope: 'user',
      surface: 'acp',
      limit: 50,
      cursor: recent.at(-1)?.cursor,
    })
  : [];
const replay = await loadSession('s_my_chat');
const scrollback = await loadFullTranscript('s_my_chat');
const historyAbort = new AbortController();
const strictScrollback = await readFullTranscript('s_my_chat', {
  timeoutMs: 15_000,
  signal: historyAbort.signal,
});
const capture = await readSessionCapture('s_my_chat', {
  timeoutMs: 15_000,
});
const bundle = await exportSessionBundle('s_my_chat', {
  timeoutMs: 15_000,
});
const compacted = await compactSession('s_my_chat', { dryRun: true });

await appendClientNotice('s_my_chat', {
  source: 'space',
  content: '/doctor ok',
});
```

`readSessionCapture()` returns the active `data` and full `transcript` from one
immutable storage boundary. `readFullTranscript()` and
`readSessionCapture()` are strict read-only APIs: timeout/cancellation,
corruption, version drift, or resync fail explicitly and never trigger legacy
Session migration or recovery. `exportSessionBundle()` preserves the exact
main/sidecar bytes with hashes and compatibility diagnostics; use it for a
support or recovery bundle, not as proof that a Session can resume.

### Auto-resume selection in v0.7.74

With `session.autoResume: true` (or `resume: true`) and no explicit ID, KodaX
calls `storage.list(context.gitRoot, { limit: 1000 })` and chooses the first
newest-first summary whose `msgCount > 0`. This prevents newer zero-message
ACP/bootstrap placeholders from shadowing a real conversation. An explicit
`session.id` always wins. Custom `KodaXSessionStorage` implementations should
therefore honor the optional `limit` argument and return `msgCount` accurately;
they may return fewer than 1000 records.

The standalone interactive CLI additionally restores the persisted
workspace/runtime identity before the next turn. SDK embedders still own
`context.gitRoot`, `context.executionCwd`, and storage construction; do not rely
on process cwd as a substitute for host-owned runtime context.

### What `createSessionManager()` returns (v0.7.43+)

```ts
interface SessionManager {
  // Read side (FEATURE_173 v0.7.42)
  listSessions(...): Promise<SessionSummary[]>;
  loadSession(id): Promise<...>;
  loadFullTranscript(id): Promise<...>;
  readFullTranscript(id, options?): Promise<...>;
  readConversationHistory(id, options?): Promise<...>;
  readSessionCapture(id, options?): Promise<SessionReadCapture | null>;
  appendClientNotice(id, opts): Promise<SessionTranscriptEntry | null>;
  compactSession(id, opts?): Promise<CompactSessionResult>;
  forkSession(id, opts?): Promise<...>;
  rewindSession(id, opts?): Promise<...>;
  setActiveEntry(id, selector): Promise<void>;
  deleteSession(id): Promise<void>;
  listRunningSessions(): Promise<RunningSessionInfo[]>;
  watchSessions(cb): () => void;
  // Write side (v0.7.43 follow-up)
  storage: FileSessionStorage;     // ← NEW — pass into runKodaX
}
```

`surface` is an exact filter applied before `limit`. Each returned summary may
include an opaque `cursor`; pass the last summary's cursor back unchanged.
Lists sort by `lastMessageAt` (latest genuine user/assistant conversation),
falling back to `createdAt`, then creation time and ID descending. The optional
`lastMessageAt` is carried by Session summaries, loaded product Sessions, and
the shared Host Client. Actor/settings/title writes, synthetic wakes, and
compaction do not create new conversation activity; copied history keeps its
source time. Legacy data without a reliable message time falls back to creation,
never filesystem mtime. These times are display facts, not event sequence IDs.

Filtering and ordering precede `limit`; `before` still filters **creation** time.
New cursors retain the returned ordering boundary even if the anchor is deleted
or becomes active. Pagination is a live listing, not a cross-page snapshot:
newly active Sessions may move before the boundary; refresh the first page to
see them. Do not parse or construct cursors. Bare `kodax -r` uses the same order
and displays message time, without starting a Host or writing an index.

### Active context vs full transcript vs UI replay

Session persistence exposes three related but different layers:

| Need | Use | Meaning |
|---|---|---|
| Continue a model turn | `loadSession(id)` | Active branch only. This is the context KodaX would resume from. |
| Render the ordinary conversation | `readConversationHistory(id)` | SDK-resolved conversation order with proven compaction copies folded and ambiguity reported. |
| Render audit / raw scrollback | `readFullTranscript(id)` or `loadFullTranscript(id)` | Append-order physical entries, including archived islands and non-active branches. |
| Reuse TUI display projection | `SessionData.uiHistory` | Optional bounded replay cache. Interactive REPL sessions may write it; headless SDK sessions may not. |

For product UI, use `readConversationHistory(id)` for the ordinary chat and
keep `readFullTranscript(id)` available for an audit/details view.
`loadSession(id)` remains the model-context API. Do not assume `uiHistory`
exists; it is intentionally a small, lossy replay cache.

`loadSession(id)` and Runtime `sessions.load(id)` are pure snapshot reads. They
do not emit `session.loaded`; a host that explicitly loads a snapshot should
update its own selected/loaded UI state from the resolved promise. The
compatibility `session.loaded` event (and the CLI bridge's `onSessionStart`)
remains bound to the Provider Run execution boundary, where a Session actually
becomes active. Do not use that Run-lifecycle event as a generic data-load
notification.

`loadFullTranscript(id).transcriptEntries` is the structured host-facing
scrollback. Each entry has stable ownership and ordering fields:

```ts
interface SessionTranscriptEntry {
  entryId: string;
  parentId: string | null;
  logicalId: string;
  sourceEntryId?: string;
  timestamp: string;
  type: 'message' | 'compaction' | 'branch_summary' | 'rewind_marker' | 'client_notice' | 'task_result';
  source?: 'user' | 'assistant' | 'workflow' | 'child_task' | 'system' | 'client';
  turnId?: string;
  active: boolean;
  message: KodaXMessage;
  payload?: unknown;
  taskResults?: readonly KodaXTaskResultMetadata[];
}
```

`entryId` is the physical lineage node id. `logicalId` is stable across
forked/cloned copies of the same transcript item, and `sourceEntryId` is present
on cloned entries to point back to the direct physical predecessor copy — the
immediate source the clone was materialized from (until v0.7.89 it addressed
the transitive root source; hosts must not assume root semantics). These fields
support audit inspection, but a host must not infer the complete ordinary-chat
fold merely by grouping them: legacy omissions and conflicting metadata require
lineage validation. Use `readConversationHistory()` instead of implementing
host-side folding, and never guess from `message.role`, content, timestamp,
`turnId`, or `[compacted]` placeholders.
Legacy entries without persisted provenance use `logicalId === entryId` and omit
`sourceEntryId`; treat that as "unknown/not cloned", not as content-based proof
that no older clone exists.
`loadFullTranscript()` still returns raw append-order scrollback; it does not
hide archived islands or non-active branches, and it does not silently merge
branches. The host owns branch visibility, folding, and main-chat presentation.

`readConversationHistory()` is the supported folding boundary. Every returned
entry has a physical `boundaryId` and `auditEntryIds` naming all copies that the
SDK could prove represent the same interaction. Modern Sessions use
`logicalId` / `sourceEntryId`; legacy copies are folded only when a persisted
compaction boundary and one unique lineage suffix prove the relationship.
An inactive compaction epoch or non-leaf ancestor is crossed only when a
contiguous retained prefix has exact provenance and its complete parent path
predates the compaction in append order. Content-only legacy matching never
authorizes that fallback.
KodaX never globally sorts or deduplicates by content, timestamp, or `turnId`.

The result status is part of the contract:

- `resolved`: every fold and branch predecessor used by the projection was
  proven. A persisted Session with no conversation records is also resolved
  with empty `entries` and `issues`, including the normal interval after a Run
  is accepted but before its body enters canonical history.
- `partial`: persisted lineage or transcript identity needed for a complete
  projection of one or more existing conversation records is unavailable.
  When newer compaction epochs are proven but an older boundary is not, the
  projection returns those proven epochs and omits the unprovable older region,
  with `compaction_history_truncated` naming its boundary. Available physical
  records are retained in the fallback where the active path is missing or
  incomplete, or no epoch can be proven.
  Actor/Run state by itself does not make an otherwise empty persisted
  conversation partial.
- `ambiguous`: multiple legacy interpretations remain. All candidates are
  retained in the physical-record fallback and `issues[]` explains why; the
  host must not present the result as confidently deduplicated. A proven newer
  region with an unprovable older boundary instead uses the `partial` truncation
  contract above.

The unreleased Issue 340 repair can restore legacy tool-call/result pairs only
when one retained sibling chain exactly reproduces the old cleanup damage.
It is read-only and does not rewrite the Session. Re-compacted copies follow
proven logical identity and content through at most eight predecessor hops.
Derived page cache v9 invalidates older generations once; direct and paged
reads use the same restored entries, status, issues, and revision. A truncated
conversation is not proof that the omitted physical history was empty; hosts
can retain `loadFullTranscript()` as a separate raw audit view.

Issues are bounded diagnostic summaries: `occurrenceCount` is the number of
diagnostics represented, `entryCount` is the pre-bounding evidence-reference
count, and `entryIds` is a bounded exact sample. Conversation entries themselves
are never removed to make diagnostic metadata fit a transport page.

Runtime exposes the identical projection in embedded and daemon modes through
`sessions.conversation()`, `sessions.conversationPage()`, and
`sessions.conversationEntryChunk()`. Modern Session writes prepare a bounded
on-disk page index, so the first finite page reads only its metadata, fixed-size
index records, and requested inline bodies instead of materializing all history.
A source-boundary-fenced copy of the Session's minimal admission identity lets
the shared daemon authorize that bounded read before checking cursors, capacity,
or entry metadata; it does not perform a full Session `peek()` on a cache hit.
A cache-less older Session is upgraded by one canonical fallback read. Direct
and paged reads share the same `revision`, `sourceRevision`, status, issues, and
logical entry order. Page and chunk cursors are revision-fenced: if the Session
changes, the Runtime returns `resync_required` and the host must request a fresh
first page. Derived manifest, descriptor, and chunk reads have fixed allocation
ceilings; a corrupt or concurrently replaced generation is rejected rather
than trusted. Pages are fetched newest-tail-first while each page is internally in
forward order, so prepend each fetched page to reconstruct `conversation().entries`;
do not append pages in fetch order.
Request `requirements: { conversationHistory: 2 }` when connecting to a daemon
that must keep this projection topology-transparent across managed context and
preserve direct clone provenance. `conversationHistory: 1` is only the older
folding and paging floor. Inspect
`KODAX_RUNTIME_SDK_CAPABILITIES.conversationHistory` before auto-start so an
idle daemon that still exposes the legacy projection can be replaced.

For write-side hosts that already own a newly produced append tail,
`await FileSessionStorage.prepareSessionAppend(id)` returns an authenticated
one-shot boundary or `null` when no canonical cache witness is available.
`appendPreparedSessionTail(id, delta)` appends only the supplied new linear
lineage, artifact, and extension records. The delta deliberately has no
historical-array field: its read and compute cost is bounded by the new tail,
and a stale boundary, prefix/sidecar change, duplicate identity, non-linear
lineage tail, or concurrent durable write fails with
`SessionReadError.code === 'data_changed'`. Reload, obtain a fresh boundary,
and rebuild the tail before retrying.

Standalone Session owners follow the same rule: the prepared-tail persistence helper
falls back to `appendSessionDelta(id, data)` after `data_changed`, so the
authoritative full snapshot merges the newest UI/session state. Background
write failures are emitted as structured diagnostics; they are not swallowed
and a stale tail is never retried unchanged.
Product Ink sessions use the Host Client API and never save a competing local
transcript or lineage; see [transcript ownership](#unreleased-interrupted-run-recovery-and-transcript-ownership).

A non-null fulfilled append result is the reusable successor boundary. A
fulfilled `null` means the tail did commit exactly once, but the successor
could not be witnessed; reload before another append and do not retry that
tail. Use `appendSessionDelta(id, data)` for a full mutable snapshot, a `null`
prepared boundary, or any historical rewrite; that API performs the exact
canonical merge and persists index, nested-object, and post-helper mutations.
Data returned by `storage.load()` remains an ordinary mutable,
`structuredClone()`-compatible `KodaXSessionData` object. The derived page
cache is only a recoverable acceleration structure: its fixed-size identity
filter is accepted for appends only when its exact bundle revision and hash
match canonical metadata in the Session main file.

```ts
const baseline = await storage.prepareSessionAppend(sessionId);
if (baseline === null) {
  await storage.appendSessionDelta(sessionId, completeMutableSnapshot);
} else {
  const successor = await storage.appendPreparedSessionTail(sessionId, {
    baseline,
    title,
    activeEntryId: newEntry.id,
    lineageEntries: [newEntry],
  });
  if (successor === null) {
    await storage.load(sessionId); // committed; resync before the next tail
  }
}
```

Use a returned entry as a revision-fenced fork or rewind boundary instead of
guessing from content or a historical `turnId`:

```ts
const history = await runtime.sessions.conversation(sessionId);
const item = history?.entries.find((entry) => entry.boundaryId !== undefined);
if (history && item?.boundaryId) {
  await runtime.sessions.fork({
    sessionId,
    historyBoundary: {
      entryId: item.boundaryId,
      sourceRevision: history.sourceRevision,
    },
  });
}
```

If the Session changes before the mutation, the Runtime returns
`resync_required`; an unknown boundary returns `null` and never falls back to a
different point.

The standalone session API accepts the same boundary (named `boundaryId` on
that surface) and fails closed with `null`:

```ts
const history = await manager.readConversationHistory(sessionId);
const item = history?.entries.at(-1);
if (history && item?.boundaryId) {
  await manager.forkSession(sessionId, {
    historyBoundary: {
      boundaryId: item.boundaryId,
      sourceRevision: history.sourceRevision,
    },
  });
}
```

Since v0.7.63, rewind audit markers are represented as
`type: 'rewind_marker'`. They are useful for host scrollback and audit UI, but
they do not enter model context: `loadSession()` omits them, and
`loadFullTranscript().messages` filters them out while
`loadFullTranscript().transcriptEntries` keeps the structured marker.

Use `type` / `source` / `timestamp` / `active` instead of parsing
`message.role`, synthetic wrapper text, or filesystem side stores. In
particular, workflow and child-task completions surface as
`type: 'task_result'` with `taskResults[]`:

```ts
const full = await loadFullTranscript(sessionId);
for (const entry of full?.transcriptEntries ?? []) {
  if (entry.type === 'task_result') {
    for (const result of entry.taskResults ?? []) {
      // result.source is 'workflow' or 'child_task'
      // result.taskId / runId / status / title / summary are structured.
    }
  }
}
```

For host-local output that should be visible in the transcript but must not
enter model context, call `appendClientNotice()`:

```ts
await appendClientNotice(sessionId, {
  source: 'space',
  content: '/mcp status: 3 servers connected',
  timestamp: new Date().toISOString(),
  payload: { command: '/mcp status' },
});

const active = await loadSession(sessionId);         // no client notice
const full = await loadFullTranscript(sessionId);    // includes client_notice
```

Client notices are persisted as lineage entries, not model messages. They are
returned from `loadFullTranscript()` with `type: 'client_notice'`,
`source: 'client'`, and `payload.entersModelContext === false`.

v0.7.51 extends the `uiHistory` schema so interactive sessions can persist
sanitized terminal tool cards. Text items may set `presentationOnly: true` when
their rendered content is authoritative even without a canonical message anchor;
this is how failed managed turns retain the final Assistant summary, Sidecar
Verifier verdict, and terminal error across `kodax -r`. Headless SDK sessions can still reconstruct
tool-call display from canonical assistant `tool_use` and user `tool_result`
messages when no TUI replay cache exists. Workflow progress remains on the
`WorkflowProcessSnapshot` / lifecycle-controller surfaces from v0.7.50; session
history should replay durable child digests and final answers, not workflow live
process state. The neutral replay types live with the session data model and are
exported from both `@kodax-ai/kodax/agent` and `@kodax-ai/kodax/session`; use
`KodaXSessionUiHistoryItem` / `KodaXSessionUiToolCall` when a host needs to
type-check `SessionData.uiHistory`.

SDK hosts that want the same neutral replay projection as the TUI can call the
session helper directly without importing Ink/React:

```ts
import {
  loadSession,
  restoreHistoryItemsFromSession,
  type CreatableHistoryItem,
} from '@kodax-ai/kodax/session';

const session = await loadSession(sessionId);
const replayItems: CreatableHistoryItem[] = session
  ? restoreHistoryItemsFromSession({
      messages: session.messages,
      uiHistory: session.uiHistory,
    })
  : [];
```

`restoreHistoryItemsFromSession()` always derives the ordinary transcript from
canonical `messages` and trims that window first. Persisted `uiHistory` may
overlay timestamps, compact labels, icons, and sanitized `tool_group` output by
tool ID, or append display-only entries such as `/quit`. A non-empty, sparse,
or stale cache cannot hide user/assistant history. Presentation-only
`agent-completed` and legacy `task-completed` events stay host-owned when a
non-empty CLI `uiHistory` exists; headless/no-cache restore still derives them
from messages. The lower-level
`extractHistorySeedsFromMessages()` helper is also exported from
`@kodax-ai/kodax/session` for hosts that want to apply their own projection.

### Custom sessions directory (multi-tenant / tests)

```ts
const { storage } = createSessionManager({
  sessionsDir: '/srv/tenant-42/.kodax/sessions',
});
// `storage` writes there; matching listSessions/loadSession on the
// same manager read from the same dir.
```

This is equivalent to constructing `FileSessionStorage` directly
but keeps read + write sharing one instance (so append-watermark
caches stay warm across mixed list / run operations).

### Bring-your-own storage (database / cloud / IndexedDB)

`FileSessionStorage` implements `KodaXSessionStorage`. Any class
implementing the same interface can be passed in. Minimal contract:

```ts
import type { KodaXSessionStorage, SessionData } from '@kodax-ai/kodax/coding';

class MyDbSessionStorage implements KodaXSessionStorage {
  async save(id: string, data: SessionData): Promise<void> { /* ... */ }
  async load(id: string): Promise<SessionData | null> { /* ... */ }
  async list(opts?: ...): Promise<SessionSummary[]> { /* ... */ }
  async delete(id: string): Promise<void> { /* ... */ }
  // (other methods — see the @kodax-ai/kodax/coding type for the full surface)
}

const storage = new MyDbSessionStorage();
await runKodaX({ session: { id, storage }, ... }, prompt);
```

`mutateRuntimeInfo()` is an optional low-level seam used by the Runtime-owned
`FileSessionStorage`; `createKodaXRuntime()` currently owns that storage. A
custom storage passed directly to `runKodaX()` remains transcript storage.
Adding this method alone does not install the Runtime workspace-root registry
or its shell/text sandbox policy. Use the Runtime service when depending on the
dynamic linked-worktree correction.

The SA / AMA loops are storage-implementation-agnostic — they just
call `storage.save(...)` at the terminal sites (success / error /
mid-flow / limit-reached). Storage failures are swallowed locally
with a `[SessionSnapshot] storage.save failed` `console.error` —
they never propagate to the `runKodaX` caller.

### Why isn't `storage` defaulted automatically?

Three reasons we **don't** auto-construct `FileSessionStorage` when
`session.id` is supplied:

1. **Package boundary**: `FileSessionStorage` is implemented in
   `@kodax-ai/repl` (it's >500 LoC of write-queue + watermark +
   JSONL streaming logic). `@kodax-ai/coding` does not depend on
   `/repl`, and reversing that direction breaks ADR-001 package
   independence (you'd no longer be able to consume `/coding`
   without dragging the Ink REPL bundle).
2. **Pluggability**: hosts often want non-filesystem storage
   (Electron IndexedDB, web app S3 bucket, server-side Postgres).
   Defaulting to `FileSessionStorage` would force a `fs/promises`
   side-effect on every embedder.
3. **Explicit > implicit**: a silent default would hide the wiring
   from new SDK consumers; the v0.7.43 `console.warn` makes the
   missing wiring loud the first time it bites.

### When to construct `FileSessionStorage` directly vs go through `createSessionManager`

| Use case | Construct directly | Use `createSessionManager` |
|---|---|---|
| Only need to save runs, no listing / reading UI | ✓ | (also fine — `storage` field gives you the same instance) |
| Need a popout / sidebar showing past sessions | | ✓ — pairs read + write through one instance |
| Custom sessions dir for tests / tenants | (works, but you must repeat the dir option for each call) | ✓ — `{ sessionsDir }` once, both sides honor it |
| Want to mock storage for unit tests | ✓ (inject mock implementing `KodaXSessionStorage`) | — |

### Quick checklist before reporting "session.jsonl not appearing"

- [ ] Did you set `session.storage`? (Not just `session.id`.)
- [ ] Is the run actually reaching a terminal site?
      `saveSessionSnapshot` fires from success / error / mid-flow /
      limit-reached. A run that throws synchronously before
      `runKodaX` enters the loop never saves.
- [ ] Did `storage.save` throw? Check `console.error` for
      `[SessionSnapshot] storage.save failed`. Storage errors are
      isolated by design (don't fail the run), but they leave the
      session file unwritten.
- [ ] Is the `sessionsDir` the one you expect? Default is
      `<KODAX_HOME>/sessions`; override via `setAgentConfigHome` or
      `createSessionManager({ sessionsDir })`.
- [ ] Is the `session.id` filesystem-safe? KodaX accepts any string
      but writes `<id>.jsonl` literally — IDs with `/`, `\`, or
      control chars will be rejected by the OS.

---

## 7. Local development via `npm link` (iterating against in-tree KodaX)

If you maintain an SDK consumer (KodaX Space, an IDE extension, a custom
bundler integration) and need to iterate against an unreleased KodaX
build — verifying a bugfix, prototyping against an in-progress feature,
running your project's test suite against `main` — you can `npm link`
the in-tree KodaX checkout instead of waiting for a published version.

As of v0.7.43 the root `package.json` is in **already-published shape**:
`"name": "@kodax-ai/kodax"` is baked in along with all 10 SDK subpath
exports. `npm link` "just works" — no need to run `scripts/release.mjs`
first.

### Recipe

```bash
# In your local KodaX checkout
cd /path/to/KodaX
npm install                                    # one-time (sets up workspaces)
npm run build                                  # required — npm link resolves to dist/
npm link                                       # exposes the dir as @kodax-ai/kodax globally

# In your SDK consumer project (e.g. KodaX Space)
cd /path/to/my-host-app
npm link @kodax-ai/kodax                       # consume the linked checkout
```

After this, `import { ... } from '@kodax-ai/kodax/repl'` in your host
app resolves to `/path/to/KodaX/dist/sdk-repl.js`. Subsequent edits inside KodaX
require **re-running `npm run build`** — the link points at the bundled output,
not source. Builds replace mutable `dist` files, but an already running process retains
the embedded Windows native manifest it loaded. KodaX resolves that manifest's
exact content-addressed protected-cache generation before the rebuilt source,
so overlapping old/new SDK processes do not mix native protocol evidence. Start
a new host process to consume the new build; no manual cache deletion is needed.

### Tearing down the link

```bash
# In your SDK consumer project
npm unlink @kodax-ai/kodax       # restore the published version (npm install runs again)

# In KodaX
npm unlink -g @kodax-ai/kodax    # remove the global symlink
```

### Why root stays `"private": true`

The dev `package.json` carries `"private": true` so a bare `npm publish`
from the repo refuses — `scripts/release.mjs` is the only sanctioned
publish path. As of v0.7.96 the package embeds prebuilt native authorities
for five platforms, which only the Release workflow's cross-platform matrix
can assemble; `node scripts/release.mjs` therefore downloads the CI-built
universal tarball from the GitHub Release (sha256-verified) and publishes
those exact bytes — the local dev manifest is never toggled. `"private"`
does **not** block `npm link` — it only gates `npm publish` — so the
linked-build flow is unaffected.

### Alternative: tarball install

If you want a one-shot snapshot rather than a live symlink (e.g. for CI
or for a teammate without write access to the KodaX checkout):

```bash
# In KodaX
node scripts/release.mjs --pack-only           # produces kodax-ai-kodax-<v>.tgz

# In your host app
npm install /path/to/KodaX/kodax-ai-kodax-<version>.tgz
```

A locally packed tarball is a LOCAL TEST TARBALL: it keeps
`"private": true` (npm refuses to publish it) and embeds only the native
authority for the machine that packed it — sufficient to exercise the
published package shape and SDK subpaths on that platform. The
npm-published universal tarball (all five authorities, `private: false`)
is assembled by the Release workflow's `npm-package` job.

---

## 8. User-authored agents — markdown loader + extension `registerAgent` (FEATURE_191, v0.7.43)

### Why this exists

KodaX's Self-Construction substrate (FEATURE_087-090 / 101) lets the
LLM author + admit constructed agents at runtime. FEATURE_191 closes
the loop for **human authors** and **SDK embedders**: ship an `<name>.md`
file under `~/.kodax/agents/` (user-level) or `<repo>/.kodax/agents/`
(project-level), or have an extension call `api.registerAgent(name, content)`
at activate time. All three paths feed the same admission pipeline as
the LLM-generation route and surface in the Worker SP's
`=== Available specialist agents ===` block.

### Markdown shape

```markdown
---
name: db-reviewer
description: Reviews DB migrations for safety and best practices
tools: [read, grep]
model: claude-sonnet-4-6
---
You are a DB migration reviewer. Focus on:
- Locking behavior under concurrent writes
- Default value backfill cost on large tables
```

`name` and `description` are required; missing/invalid `name` is a
silent skip (claudecode-compatible: treats the file as a reference doc).
`tools` accepts either a YAML array (`[read, grep]`) or a
comma-separated string (`"read, grep"`); each entry maps to
`builtin:<name>`. `mcpServers` / `hooks` / `memory` / `isolation` /
`permissionMode` / `maxTurns` / `skills` frontmatter fields are
silently ignored in v0.7.43 (forward-compat with future features).

Project agents (`<repo>/.kodax/agents/*.md`) shadow user-level agents
of the same name (last-write-wins).

### SDK API for extensions

```ts
// In an extension's activate function:
export default async function activate(api: KodaXExtensionAPI) {
  const dispose = await api.registerAgent('python-reviewer', {
    instructions: 'You review Python code for PEP-8 + type hints.',
    description: 'Python code reviewer (PEP-8 + type hints)',
    tools: [{ ref: 'builtin:read' }, { ref: 'builtin:grep' }],
  });

  // The returned dispose is auto-pushed onto the extension's
  // disposables list, so manual disposal is optional. Call it only
  // if you need to unregister the agent mid-session.
  return () => dispose();
}
```

`api.registerAgent(name, content)` throws on admission rejection with
the extension id + agent name + verdict reason — the embedder sees
failures at activate time rather than silently dropped registrations.

### Reading the agent registry (host code)

```ts
import {
  listConstructedAgents,
  resolveConstructedAgent,
} from '@kodax-ai/kodax';

// All registered constructed agents (markdown + extension + LLM + CLI).
const agents = listConstructedAgents();

// Resolve a specific agent by name.
const agent = resolveConstructedAgent('db-reviewer');
```

> **Source-aware variants** — `listConstructedAgentsWithSource()` /
> `resolveConstructedAgentSource(name)` expose the in-memory source
> tag (`'built-in' | 'extension' | 'markdown:user' | 'markdown:project'
> | 'constructed:cli' | 'constructed:llm'`). These are marked
> `@internal` in v0.7.43 and exposed only via the construction
> sub-barrel — they will be promoted to the top-level SDK entry when
> the v0.7.46+ REPL `/agents list` command lands as their third
> production consumer (current consumers: source-tag round-trip tests
> + planned REPL). Embedders that need provenance today can read the
> source via the existing `listConstructedAgents()` Agent shape and
> cross-reference their own registration calls.

### Wiring dispatch

Workers automatically see a registered agent through the SP block.
Programmatic dispatch (e.g. in `runKodaX` SDK consumers) goes through
the standard tool surface — pass `subagent_type` to
`dispatch_child_task`:

```ts
// Inside a tool handler or eval driver:
const result = await dispatchChildTask({
  id: 'child-1',
  objective: 'Review the migration in this PR',
  readOnly: true,
  subagent_type: 'db-reviewer',
});
```

Unknown `subagent_type` returns a tool-result error listing available
names (does NOT throw); write-capable specialists dispatched outside the
Worker path are rejected at the dispatch layer. Older V1 docs may phrase
this as "non-Worker/Generator"; Generator is historical after FEATURE_193.

### See also

- [docs/test-guides/FEATURE_191_v0.7.43_TEST_GUIDE.md](../../docs/test-guides/FEATURE_191_v0.7.43_TEST_GUIDE.md) — manual test recipes
- [docs/features/v0.7.43.md FEATURE_191](../../docs/features/v0.7.43.md#feature_191-user-authored-custom-agents--markdown-loader--extension-registeragent--dispatch_child_task-bridge) — design + acceptance gates
- [docs/ADR.md ADR-035](../../docs/ADR.md#adr-035-user-authored-custom-agents--markdown-loader--extension-registeragent--dispatch_child_task-bridge-feature_191-v0743) — architectural rationale

---

## 9. Electron + `stdio: 'inherit'` on Windows — PowerShell input hijack

### Symptom

A host process (e.g. `scripts/dev.mjs`) spawns Electron with
`stdio: 'inherit'`. After Electron's main process starts up and loads
the KodaX SDK, the parent terminal (PowerShell, Windows Terminal,
cmd.exe) stops responding to keyboard input — characters don't echo,
Enter doesn't dispatch, Ctrl-C may not register.

### What's actually happening

This is **not caused by KodaX hooking stdin**. The SDK has no
module-level `process.stdin.on/setRawMode/resume/setEncoding` anywhere
in the published code path. We verified this empirically with the
following probe (Node 24, Windows, v0.7.43 dist):

| Probe step | stdin listeners delta | raw mode delta | signal listeners delta |
|---|---|---|---|
| `import('@kodax-ai/kodax')` (root) | 0 | none | 0 |
| `import('@kodax-ai/kodax/agent')` | 0 | none | 0 |
| `import('@kodax-ai/kodax/llm')` | 0 | none | 0 |
| `import('@kodax-ai/kodax/coding')` | 0 | none | 0 |
| `import('@kodax-ai/kodax/mcp')` | 0 | none | 0 |
| `import('@kodax-ai/kodax/session')` | 0 | none | 0 |
| `import('@kodax-ai/kodax/skills')` | 0 | none | 0 |
| `import('@kodax-ai/kodax/repl')` | 0 | none | 0 |
| `hydrateProcessEnvFromShell()` (Windows) | 0 (early return) | none | 0 |
| `loadConfig()` + `listMcpServers()` | 0 | none | 0 |

`hydrateProcessEnvFromShell()` on Windows specifically returns `false`
at [packages/repl/src/common/utils.ts](../../packages/repl/src/common/utils.ts)
line 151 **before** any `spawnSync`. Even on non-Windows where the
spawn happens, it explicitly passes `stdio: ['ignore', 'pipe', 'pipe']`
— the child shell never sees the parent stdin.

The root cause is an Electron + Windows ConPTY interaction: spawning
an Electron child with `stdio: 'inherit'` from a Windows terminal
makes the child process inherit a live handle to the parent's input
stream. Even though nobody inside Electron's main process reads from
it, the open handle alters how PowerShell / Windows Terminal route
keystrokes — they cannot tell whether the upstream child has
"consumed" them. This is a known Windows console quirk independent
of any code Electron's main module runs.

### Canonical fix (host-side)

Detach Electron's stdin in the spawn config:

```js
// scripts/dev.mjs
import { spawn } from 'node:child_process';

const electron = spawn(electronBin, [appEntry], {
  stdio: ['ignore', 'inherit', 'inherit'], // ← stdin: 'ignore', NOT 'inherit'
  shell: false,
});
```

`stdio: ['ignore', 'inherit', 'inherit']` keeps stdout/stderr piped
to the host terminal for log visibility but prevents Electron from
holding the parent's stdin. PowerShell / Windows Terminal regain
full control of keyboard input. This is the canonical workaround
Electron itself documents (the `electron/dev-tools` examples ship
with this exact pattern).

### Why we don't ship a SDK-side mitigation

There is nothing the SDK can do to release a stdin handle it never
opened. Some hosts (CLI runners, headless servers) may legitimately
want to pipe data into the Electron main process via stdin; pre-emptively
closing or redirecting it from inside the SDK would break those.
The spawn-time decision belongs to the host.

### How to confirm whether your symptom matches this

Run [`scripts/probe-sdk-stdin.mjs`](../../scripts/probe-sdk-stdin.mjs)
against your in-tree or installed SDK dist:

```bash
# In-tree (this repo):
node scripts/probe-sdk-stdin.mjs

# Against an installed @kodax-ai/kodax:
node scripts/probe-sdk-stdin.mjs ./node_modules/@kodax-ai/kodax/dist
```

The probe imports every SDK subpath and runs the Space startup sequence
(`hydrateProcessEnvFromShell` / typeof reads / `loadConfig` /
`listMcpServers` / provider snapshots), reporting stdin listener delta /
raw-mode delta / signal-handler delta at each step. If every step shows
"no state change ✓", the issue is in your spawn config — not in KodaX.
If any step shows a non-zero delta, file an issue with the probe output
and your Node / OS / SDK version.

---

## 10. Model capabilities — context window, reasoning, descriptors

> Product consumers query `client.catalog` and effective Host settings. Direct
> provider construction and credential access below belong to library/Host code.

### Why this exists

A popout-style UI typically wants to list every provider/model KodaX
supports, with at minimum `context window` and `reasoning capability`
shown next to each model — so the user can pick informed. Pre-v0.7.43,
this metadata lived inside each `Provider` class's `config` field and
was only readable via `provider.getContextWindow()` / `getModelDescriptor()`
on an instantiated Provider. `getProvider(name)` instantiates which
throws if the relevant API key env var is unset — meaning a UI couldn't
show "Anthropic Sonnet 4.6 / 200K context" until the user had set
`ANTHROPIC_API_KEY`. Capability metadata is **KodaX-maintained static
data** (we know what context windows the upstream models advertise),
so gating it on credentials is wrong.

v0.7.43 promoted this metadata into registry-layer snapshots and getters; the
current implementation backs `KODAX_PROVIDER_SNAPSHOTS` with
`provider-capabilities.json`. The getters still read without a provider
instance, API key, or env var.

### The new surface

All exports below come from `@kodax-ai/kodax/llm` (preferred) — also
re-exported through `@kodax-ai/kodax` (root), `@kodax-ai/kodax/coding`,
and `@kodax-ai/kodax/agent` for convenience.

```ts
import {
  // Built-in providers (anthropic / kimi / zhipu / deepseek / ark-coding / ...):
  getProviderModelDescriptors,           // (name) => KodaXModelDescriptor[]
  getModelCapabilities,                  // (name, model) => KodaXModelCapabilities | undefined
  listBuiltinModelCapabilities,          // () => KodaXModelCapabilities[]   (all built-ins, default-first per provider)

  // Custom providers (registered via `registerConfiguredCustomProviders`
  // from `~/.kodax/config.json#customProviders`):
  getCustomProviderModelDescriptors,     // (name) => KodaXModelDescriptor[] | undefined
  getCustomModelCapabilities,            // (name, model) => KodaXModelCapabilities | undefined
  listCustomProviderModelCapabilities,   // () => KodaXModelCapabilities[]

  // Unified dispatchers — built-in OR custom, transparent routing:
  resolveProviderModelDescriptors,       // (name) => KodaXModelDescriptor[]   (empty if unknown)
  resolveModelCapabilities,              // (name, model) => KodaXModelCapabilities | undefined
  listAllModelCapabilities,              // () => KodaXModelCapabilities[]   (built-in + custom merged)

  // Types:
  type KodaXModelCapabilities,
  type KodaXModelDescriptor,
} from '@kodax-ai/kodax/llm';
```

### Shape

```ts
interface KodaXModelCapabilities {
  provider: string;                 // 'anthropic' | 'kimi' | 'ark-coding' | <custom-name>
  model: string;                    // model id (e.g. 'claude-sonnet-4-6', 'kimi-k2.7-code')
  displayName: string;              // human label — falls back to model id
  supportsThinking: boolean;        // native reasoning is available?
  reasoningCapability: 'native-budget' | 'native-effort' | 'native-toggle' | 'prompt-only' | 'none' | 'unknown'; // legacy mechanism label
  reasoningProfile?: {
    defaultEffort?: string;
    supportedEfforts?: Array<{ value: string; isDefault?: boolean; isUserVisible?: boolean }>;
  };
  contextWindow?: number;           // input tokens (provider default + per-model override cascade)
  maxOutputTokens?: number;         // per-turn output limit KodaX requests — see note below
  maxOutputTokensField?: 'max_tokens' | 'max_completion_tokens';
  thinkingBudgetCap?: number;       // tokens (native-budget providers only)
  isDefault: boolean;               // true for the provider's default model
}
```

### Recipes

**List every model KodaX supports (built-in + custom):**

```ts
import { listAllModelCapabilities } from '@kodax-ai/kodax/llm';

for (const caps of listAllModelCapabilities()) {
  console.log(`${caps.provider}/${caps.model}: ${caps.contextWindow ?? 'unknown'} tokens`);
}
```

**Look up a single model:**

```ts
import { resolveModelCapabilities } from '@kodax-ai/kodax/llm';

const caps = resolveModelCapabilities('kimi', 'kimi-k2.7-code');
// => { contextWindow: 262_144, supportsThinking: true, reasoningProfile: { defaultEffort: 'high', ... }, ... }
```

For picker/status UIs, use `reasoningProfile.supportedEfforts` and
`defaultEffort`. The legacy `reasoningCapability` field describes the provider
wire mechanism, not user-facing reasoning depth.

> **v0.7.58 fix — per-model overrides on a provider's DEFAULT model.**
> `resolveModelCapabilities(provider, model)` previously dropped a model's own
> `contextWindow` / `maxOutputTokens` / `reasoningProfile` override when that
> model happened to be the provider's default (for v0.7.87,
> `zhipu-coding/glm-5.3` and `zai-coding/glm-5.2` each declare a 1M window — the resolver returned the
> 200K provider default). It now merges the `models[]` override regardless of
> default-model status, so `resolveModelCapabilities` agrees with the runtime
> `provider.getEffectiveContextWindow()` / `getEffectiveMaxOutputTokens()`.

### Resolving a wire-legal reasoning effort — `resolveWireEffort` (v0.7.58)

Mapping a user's desired reasoning strength to the actual wire `effort` value
means composing the model's profile with its alias / disabled / ceiling / default
rules AND any learned hard-rejections. `resolveWireEffort` (from
`@kodax-ai/kodax/llm`) is the single host-facing entry so you don't re-assemble
(and drift from) that logic:

```ts
import { resolveWireEffort } from '@kodax-ai/kodax/llm';

const { effort, adjusted } = resolveWireEffort({
  provider: 'zhipu-coding',
  model: 'glm-5.3',
  desiredEffort: 'minimal', // GLM-5.3 aliases minimal → low
});
// effort === 'low', adjusted === true
```

GLM-5.2 keeps its independent mapping, including low → high. For GLM-5.3,
none/minimal/light/low → low, medium/high → high, and xhigh/max/ultra → max.
Because GLM-5.3 cannot disable thinking, a disabled or `none` intent is emitted
as enabled low-effort thinking.

`effort` is `undefined` when the model omits a wire effort (e.g. anthropic
adaptive) — send no `reasoning_effort` in that case; do **not** substitute a
value. Pass `rejectedEfforts` (e.g. from the agent layer's
`getCachedRejectedEfforts`) to fold learned rejections into the resolution.

### Reasoning-effort rejection is self-healing at the runtime layer (v0.7.58)

When a provider hard-rejects a `reasoning_effort` (400/422), the coding runtime
now **records** the rejection in the capability cache and **consults** it before
building each subsequent turn's request — so the same rejected effort is not
re-sent turn after turn. This happens whether or not a host wires
`events.onReasoningEffortRejected` (that event is still delivered for hosts that
want to surface it). Previously only the built-in REPL recorded rejections, so a
headless SDK host silently re-issued a failing request every turn.

### Passive effort capability learning

KodaX v0.7.57 treats `effort` as the primary reasoning-depth input. When a
provider hard-rejects a requested effort value, the SDK emits
`KodaXEvents.onReasoningEffortRejected` with provider/model/effort metadata.
The LLM layer owns the pure learning semantics (`narrowReasoningProfile` and
cache record helpers), while the agent layer provides the default
`~/.kodax/capability-cache.json` store (`recordRejectedEffort`,
`getCachedRejectedEfforts`, `clearCapabilityCache`). The built-in REPL is just
one consumer: it records the event through the agent store and narrows future
effort choices for the same provider/model.

Headless SDK hosts can use the same agent store, provide their own store around
the LLM pure helpers, or ignore the event for deterministic no-learning runs.
This keeps the mechanism reusable without forcing a cross-session disk cache on
every embedded runtime.

**Group by provider for a picker UI:**

```ts
import {
  KODAX_PROVIDER_SNAPSHOTS,
  resolveProviderModelDescriptors,
} from '@kodax-ai/kodax/llm';

for (const providerName of Object.keys(KODAX_PROVIDER_SNAPSHOTS)) {
  const descriptors = resolveProviderModelDescriptors(providerName);
  // descriptors[0] is the default model; descriptors.slice(1) are alternatives.
}
```

### A note on `maxOutputTokens`

`KodaXModelCapabilities.maxOutputTokens` is the **per-turn output-token limit
KodaX requests**, NOT the upstream "theoretical maximum". For OpenAI-compatible
routes, `maxOutputTokensField` reports whether that limit is serialized as
`max_tokens` or `max_completion_tokens`. The two size concepts diverge because:

- **What upstream advertises is often unreliable.** A 2026-05 probe
  against `zhipu-coding` / `kimi-code` / `minimax-coding` / `ark-coding`
  (Coding-Plan endpoint) / `deepseek` showed their `/v1/models`
  endpoints return only `{id, object, owned_by, created}` — no
  context-window, no max-output, no capabilities at all. Ark's
  pay-as-you-go `/v3/models` returns rich `token_limits` but none of
  the Coding-Plan models KodaX actually uses appear in that catalog.
  Even when upstream does advertise a number, stream behavior often
  deviates (the LLM stops early at unrelated stop conditions, or the
  server enforces a tighter kill window). Upstream `/models` data is
  not a substitute for KodaX-maintained metadata.
- **What KodaX requests is the trustworthy number.** Values in
  `KODAX_PROVIDER_SNAPSHOTS` are bench-validated against each provider
  (kill-windows, decode-rate, cost-per-turn predictability). Examples:
  - DeepSeek V4 *advertises* 384K max output; KodaX requests
    `KODAX_ESCALATED_MAX_OUTPUT_TOKENS` (~32K) per turn so streams
    finish under server-side timeouts. Long generation flows through
    the L5 continuation meta path instead.
  - `zhipu-coding` has a ~308s server-side kill window; KodaX caps at
    16K so typical tool_use turns complete within the window.

For a popout UI showing "expected output size for this model", use
the KodaX value (`caps.maxOutputTokens`). It's exactly what KodaX
asks the model for — i.e. the actual size budget your turn gets. If
you also want to expose the model's *theoretical* max output, that
comes from the upstream provider's own documentation; KodaX doesn't
certify that number because we don't request it.

### Why no instance methods touch this

The existing `provider.getContextWindow()` / `getEffectiveContextWindow()`
/ `getModelDescriptor()` instance methods still work — they're the
runtime path the agent loop itself uses. The new getters layer above
them at the **registry** layer so they don't need a Provider instance.
A consumer that has a configured Provider and wants effective values
in the four-step cascade (compactionConfig override → per-model →
provider default → 200K fallback) should still use
`resolveContextWindow(compactionConfig, provider, model)` from
`@kodax-ai/kodax/agent`. The new registry-layer getters are for the
*"list everything KodaX knows"* case — for picker UIs, comparison
tables, capability-aware routing.

### Confirming snapshot accuracy

Snapshot values are sourced from
[`packages/llm/src/providers/provider-capabilities.json`](../../packages/llm/src/providers/provider-capabilities.json)
and loaded into the in-memory `KODAX_PROVIDER_SNAPSHOTS` export. When upstream
providers publish a new model or change a context-window cap, the JSON file is
the patch site — the new value flows to runtime (via `buildProviderConfig`) AND
to SDK consumers (via the getters) in a single edit. The current snapshot is
dated 2026-07-16 and includes the GPT-5.4, Kimi K2.7 Code / HighSpeed, GLM-5.2, MiniMax
M3/M2.7, DeepSeek V4, and Doubao Seed 2.0 route refreshes where supported. The
test suite at
[`packages/llm/src/providers/model-capabilities.test.ts`](../../packages/llm/src/providers/model-capabilities.test.ts)
locks in specific values (e.g. the public Kimi lineup at 262,144 tokens, deepseek-v4-pro at 1M)
so accidental drift is caught at PR time.

The probe scripts that surveyed upstream APIs live at
[`scripts/probe-upstream-model-metadata.mjs`](../../scripts/probe-upstream-model-metadata.mjs)
and [`scripts/probe-ark-tokens.mjs`](../../scripts/probe-ark-tokens.mjs) —
re-run them periodically; if a provider starts returning richer model
metadata, we can promote the snapshot to derive from it.

---

## 11. Workflow process events and lifecycle controls (FEATURE_229, v0.7.50)

> Product consumers use `client.workflows` with declarative inputs. The lower
> level runner/module interfaces below remain Host integration mechanisms.

FEATURE_229 makes dynamic workflow progress a reusable SDK process surface
instead of terminal-only text. Hosts can observe and control workflows without
parsing `/workflow` output, replaying slash commands, or depending on Ink view
models.

Use the Agent subpath for neutral process types:

```ts
import type {
  WorkflowProcessEvent,
  WorkflowProcessSnapshot,
} from '@kodax-ai/kodax/agent';
```

Use the Coding subpath for workflow execution, process subscription, and
lifecycle control:

```ts
import {
  createWorkflowLifecycleController,
  createWorkflowRunManager,
  generateWorkflowFromOptions,
} from '@kodax-ai/kodax/coding';

const runManager = createWorkflowRunManager();
const unsubscribe = runManager.subscribeWorkflowProcess((event) => {
  renderWorkflowPanel(event.snapshot);
});

const controller = createWorkflowLifecycleController({
  runManager,
  runBaseDir: '.kodax/workflows/runs',
});

const generated = await generateWorkflowFromOptions({
  options,
  request: 'Review the payment flow',
});

if (generated.kind !== 'generated') throw new Error(generated.reason);

const runId = makeRunId();
const runDir = makeRunDir(runId);
const run = runManager.startFromOptions({
  module: generated.module,
  args: { request: 'Review the payment flow' },
  options,
  runId,
  runDir,
  scriptSnapshot: generated.scriptSnapshot,
  onWorkflowProcessEvent: (event) => auditWorkflow(event.snapshot),
});

await run.done;
const snapshot = controller.getWorkflowProcessSnapshot(runId);
const result = await controller.readWorkflowResult(runId);
```

`KodaXOptions.events.onWorkflowProcessEvent` receives the same events when a
host runs normal coding tasks that enter workflow mode. `WorkflowProcessSnapshot`
is intentionally ANSI-free and UI-neutral. It carries workflow status, phases,
child item status, result-bearing child summaries, provider/model routing hints,
and final `resultSummary`.

### Two ways to author a workflow (v0.7.58)

There are two host-facing ways to turn a natural-language request into a workflow
run — pick by whether you want the SDK to *orchestrate generation for you* or the
*Worker to investigate and author it itself*:

| | `generateWorkflowFromOptions` (shown above) | `authorWorkflowViaWorker` |
|---|---|---|
| Who authors | A context-**blind** one-shot LLM call (`tools:[]`) | The **Worker agent** — scouts the repo with its own tools, then authors + runs `run_workflow` (ADR-047 scout-then-author) |
| Host role | You call it, get a `module`, then `startFromOptions` | You submit one turn; the Worker does everything; you subscribe |
| Quality | Generic (no repo investigation) | Grounded (real paths / sub-problems / `outputSchema` baked into child prompts) |
| Use when | Non-interactive / CI / low-capability host, or you want to inspect the module before running | You want the same intelligence the REPL's `/workflow create` gets (recommended for interactive GUI hosts) |

`authorWorkflowViaWorker` is exactly what the REPL's `/workflow create` does
internally (elevate one turn to `agentMode:'amaw'` so the Worker has
`run_workflow`), exposed as a single call so a GUI host doesn't reimplement the
turn-submission glue:

```ts
import { authorWorkflowViaWorker } from '@kodax-ai/kodax/coding';

const { session, workflowRunId } = authorWorkflowViaWorker({
  request: 'Review the payment flow end-to-end and fix any bugs you find',
  options: {
    provider: 'anthropic',
    workflowRunsBaseDir: '<your app data>/workflow-runs', // REQUIRED — else run_workflow can't wire (throws)
    events: {
      // Numeric, UI-neutral progress — same surface as everything else in §11.
      onWorkflowProcessEvent: (event) => renderWorkflowPanel(event.snapshot),
    },
  },
});

// Resolves once the Worker actually launches a workflow (the run_workflow task),
// or `undefined` if it judged a workflow unnecessary and answered inline.
const runId = await workflowRunId;

// `session` is a normal RunningSession — await session.result, or session.abort().
await session.result;
```

Notes:
- `agentMode` is forced to `'amaw'` for the turn; the base `options.agentMode`
  is otherwise irrelevant here.
- `workflowRunsBaseDir` is **mandatory** for this call (it gates `ctx.workflowHost`
  → the `run_workflow` tool). Omitting it throws immediately rather than silently
  producing a Worker that can't author.
- The Worker retains judgment: for a request that doesn't warrant a multi-agent
  workflow it may just answer inline, in which case `workflowRunId` resolves
  `undefined`. There is no forced-tool guarantee (that would trade away the
  scout-then-author intelligence).

### Resume replay telemetry (v0.7.58)

When a workflow run resumes a prior run (`run_workflow`'s `resumeFromRunId`),
unchanged child agents replay instantly from the prior run's content-addressed
cache. Three read-only fields let a host render "resumed, N/M replayed from
cache" without changing any execution semantics:

- `WorkflowProcessSnapshot.resumedFromRunId?` — the prior run id this run resumed
  from (absent on a fresh run).
- `WorkflowProcessItem.origin?` — `'ran'` (executed live this run) or
  `'replayed-from-cache'` (returned from the prior run's cache). Populated only
  on resumed runs; on a fresh run every item omits it (treat absent as `'ran'`).
- `WorkflowProcessProgress.replayedAgents?` — count of replayed agents; present
  only when `> 0`. `spawnedAgents`/`finishedAgents` continue to count only agents
  that actually ran this turn.

All three are additive and absent on non-resumed runs, so existing renderers are
unaffected. A resumed agent item is emitted with `status:'completed'` (a replay
is instantaneous) and `origin:'replayed-from-cache'`.

### Timeout configuration

SDK hosts can configure user-facing timeout budgets with seconds-based fields:

```ts
const options = {
  provider: 'anthropic',
  timeouts: {
    workflow: {
      generationTimeoutSec: 300,
    },
    llm: {
      requestTimeoutSec: 900,
      streamIdleTimeoutSec: 0,
      chunkTimeoutSec: 45,
      maxRetryDelaySec: 90,
    },
  },
};
```

`timeouts.workflow.generationTimeoutSec` controls dynamic workflow harness
generation. It replaces the legacy millisecond-only environment override for
SDK callers while keeping `KODAX_WORKFLOW_GENERATION_TIMEOUT_MS` compatible.
`timeouts.llm.*Sec` is normalized by the LLM-layer helper
`resolveLlmTimeoutConfig()` from `@kodax-ai/kodax/llm`; the coding runtime then
adapts the resolved millisecond values into provider resilience settings. Use
the LLM helper directly when building a non-coding runner that still needs the
same request/stream timeout semantics.

The public timeout config intentionally does not control internal cleanup or
resource-protection watchdogs such as process kill probes, workflow stop
cleanup, VM smoke checks, or daemon readiness checks.

### Workflow run host attribution (v0.7.51)

Hosts that need to attach a workflow run back to an external session, surface,
or tab can stamp an opaque string map on the run:

```ts
const run = runManager.startFromOptions({
  module: generated.module,
  args: { request: 'Review the payment flow' },
  options,
  runId,
  runDir,
  scriptSnapshot: generated.scriptSnapshot,
  processMetadata: {
    source: 'sdk',
    hostMetadata: {
      sessionId: 'space-session-123',
      tag: 'coder',
    },
  },
});

runManager.subscribeWorkflowProcess((event) => {
  const owner = event.snapshot.hostMetadata;
  if (owner?.sessionId === 'space-session-123') {
    renderSessionWorkflow(event.snapshot);
  }
});
```

`hostMetadata` is host-owned and KodaX does not interpret its keys. It is
normalized as a small string-only map, persisted in `run.json`, and echoed on
live and restored `WorkflowProcessSnapshot` values. Unstamped runs return
`hostMetadata === undefined`; hosts should treat that as "no declared owner",
not infer ownership from session replay text.

### Live child-agent telemetry

F229 also preserves parent `KodaXEvents` callbacks for child-agent execution.
Treat these callbacks as live telemetry, not canonical assistant messages.
Tool callbacks, prompt callbacks, `onTextDelta`, `onThinkingDelta`,
`onThinkingEnd`, and `onStreamEnd` can receive optional trailing metadata.

The child-agent event bridge is intentionally an allow-list. KodaX does not
blindly clone the parent `KodaXEvents` object into child runs, because unscoped
callbacks such as compaction, retry history, session start, and parent
iteration start would otherwise mutate the parent host state. Child activity
callbacks carry child metadata; child `onIterationEnd` events that are surfaced
to a host are worker-scoped (`scope:'worker'`).

For workflow children, tool/progress/prompt callbacks can carry
`workflowCorrelation` metadata that identifies the workflow run, child agent,
and workflow item. Use that metadata to update a workflow panel or activity log.
Keep `WorkflowProcessEvent` / `WorkflowProcessSnapshot` as the durable source of
workflow state, summaries, terminal status, result reads, and artifact reads.
Async digest failures are still summary-bearing: hosts should render
`summaryStatus:'unavailable'` / `summaryKind:'digest-failed'` with the provided
bounded fallback summary instead of treating the child as silent.
KodaX gives async digest a longer best-effort window than blocking digest, so
late `agent_summary_updated` messages can arrive noticeably after the child
terminal event without restarting the workflow.

### Collecting a child's result inside a workflow script (declare `outputSchema`)

When a workflow script aggregates child agents into a synthesis step, read the
child's result from the **right field**. A `WorkflowTaskResult` (from
`wf.runAgent` / `wf.wait`) carries several fields that are NOT all populated at
the same instant:

| field | reliability at the moment `runAgent`/`wait` resolves |
|---|---|
| `structured` | **The reliable field.** Present + schema-validated (with one bounded, *awaited* repair turn) whenever the spawn declared an `outputSchema`. Resolved before the call returns. |
| `finalText` | Always a string, but **may be empty or a "Let me start…" preamble** if the child ended its turn on a `tool_use`/handoff rather than a closing text block. Do NOT treat it as guaranteed content. |
| `digest` / `digestPending` | The smart digest is delivered **asynchronously** via `agent_summary_updated` *after* the call resolves; at resolve time `digest` is usually absent and `digestPending` is `true`. It powers the live panel — it is NOT available to the script's return value. |

So a script that folds `finalText` straight into `wf.synthesize` can get **empty
findings even though the per-agent digest is visible in the panel** (the digest
arrived a moment later, asynchronously). The supported pattern:

```ts
const FINDING = {
  type: 'object', additionalProperties: false, required: ['finding'],
  properties: { finding: { type: 'string', description: 'Concrete findings with file:line evidence.' } },
};

const result = await wf.runAgent({ name: 'review:auth', prompt, readOnly: true, outputSchema: FINDING });
// Prefer the schema-validated structured finding; fall back to finalText only when non-empty.
const text =
  (result?.structured as { finding?: string } | undefined)?.finding?.trim()
  || (result?.finalText?.trim() ? result.finalText : '[no finding returned]');
```

Declare an `outputSchema` on every child whose result feeds a downstream step,
and read `result.structured`. `finalText` is a best-effort fallback, and the
async `digest` is for live UI only — never rely on it in the script's own control
flow. (The built-in `parallel-investigation` workflow follows exactly this
pattern as the reference.)

For normal `dispatch_child_task` children, hosts should render child activity
under the dispatch tool or a separate child-activity panel, while leaving the
main TodoList/plan visible. A good default is:

- show the main agent plan as the work contract;
- show child-agent tool/thinking/progress as bounded live-only activity;
- persist only the child final summary, explicit approvals/audit records, and
  the parent assistant's final answer in the user-visible conversation history.

Callbacks use optional trailing metadata so existing consumers remain
source-compatible:

```ts
events.onToolProgress = (update, meta) => {
  if (meta?.workflowCorrelation) {
    renderWorkflowToolProgress(meta.workflowCorrelation, update);
    return;
  }
  renderMainToolProgress(update);
};
```

Hosts that want full child transcripts should put them in an explicit debug or
trace drawer. Do not append raw child thinking/text/tool streams into the normal
conversation by default; it makes the parent assistant appear to have authored
every child step and can overwhelm users.

### Result review and historical sessions

The main agent verifies each requested requirement with actual tool and rendered evidence before delivery. The built-in `visual-review` skill covers static images/charts, paginated documents/slides/sheets, interactive web/app/terminal/canvas/3D surfaces, and temporal video/animation results. Missing capabilities and unchecked scope are reported as unverified. An ordinary read-only child reviewer may contribute findings within the same Run; the main agent owns repairs and the final answer.

New Runs do not emit `onSidecarMessage` or `sidecar.message`. Existing persisted sidecar items and synthetic messages remain readable, without replaying execution. Run completion, Goal status, and review findings retain separate meanings.

The lifecycle controller also exposes terminal-run controls: stop, pause,
resume, artifact reads, delete, prune, display-name changes, saved-capsule
revision/replace provenance, and capsule preflight. Provenance fields such as
`source`, `sourceRunId`, `sourceWorkflowName`, `savedWorkflowName`, and
`revisionOf` let a host distinguish AMAW, `/workflow`, `/review --workflow`,
saved-name reruns, and capsule revisions while still consuming one process
contract.

### Generated harness validation

Generated workflow source is treated as a restricted harness, not as trusted
application code. `generateWorkflowFromOptions()` validates the source before a
run is launched, including wrapped JavaScript compilation, the generated
`async function run(wf, args)` contract, source-policy checks that ignore
strings/comments, and a no-effect smoke execution with a fake `wf`
implementation. Smoke validation catches common early harness defects such as
malformed `wf.runAgent` inputs, wrong `wf.wait` arguments, startup
`ReferenceError`, synchronous runaway startup code, and stalled startup awaits;
those errors feed the generator repair loop instead of creating a doomed
workflow run.

`preflightWorkflowCapsule()` also reports invalid restricted source as a
`workflow:source` error. Hosts should show that as a capsule/harness problem
before asking the user to approve a run. If a run still fails before launching
any child agents, render it as a generated harness or saved capsule failure,
not as a failed child-agent task. `/workflow rerun <runId>` repeats the saved
script snapshot; it does not regenerate a broken generated harness.

Layer boundary:

- `@kodax-ai/kodax/agent` owns neutral workflow process/event/status types.
- `@kodax-ai/kodax/coding` owns the coding backend, generated/saved workflow
  execution, run graph, host policy, lifecycle controller, result/artifact
  reads, and retention.
- `@kodax-ai/kodax/repl` renders snapshots; it is not required for SDK workflow
  execution or progress UI.

---

## 12. Provider credential verification — `verifyProviderCredential` (FEATURE_216, v0.7.45)

### Why

The original SDK exposed `provider.isConfigured()` (env-only check) and the full streaming surface (`provider.stream()` / `sideQuery()`). Neither fits the "test connection" UI use case: env check doesn't validate the key actually works against the upstream; streaming costs ~50–200 tokens and several seconds. KodaX Space (and any third-party SDK consumer building a provider-settings UI) needs a lightweight server-validated check.

FEATURE_216 ships **`verifyProviderCredential(name, opts?)`** — never-throws, lightweight, per-provider-strategy.

### Quick start

```typescript
import { verifyProviderCredential } from '@kodax-ai/kodax/llm';

const result = await verifyProviderCredential('zhipu-coding', { timeoutMs: 8000 });

if (result.ok) {
  // Key works. result.durationMs is wall-clock; result.approxTokensSpent
  // is 0 for count-tokens/models-list strategies, ~6-7 for minimal-message.
  console.log(`✓ Verified in ${result.durationMs}ms (${result.approxTokensSpent} tokens)`);
} else {
  switch (result.error) {
    case 'unauthorized':  /* show "invalid key — auth failed" (covers 401/403 + kimi-code 400 special) */ break;
    case 'unconfigured':  /* env var not set */ break;
    case 'network':       /* show "check network" (DNS/conn/socket errors) */ break;
    case 'timeout':       /* upstream didn't respond in time */ break;
    case 'server_error':  /* upstream 5xx; transient */ break;
    case 'rate_limited':  /* 429 — key is valid but throttled; suggest retry */ break;
    case 'unsupported':   /* cli-bridge provider or unknown name */ break;
    case 'unknown':       /* unexpected; surface result.message */ break;
  }
}
```

### Guarantees

- **Never throws** — every failure mode is captured in the returned `KodaXVerifyCredentialResult` envelope. Mirrors the `side-query.ts` pattern. Guarantee holds even for runtime-registered providers whose `verifyCredential()` override might throw (legacy 3rd-party extensions that predate FEATURE_216): the top-level helper wraps the call in try/catch and returns `error: 'unknown'`.
- **No ctor throw on missing env** — the helper short-circuits to `error: 'unconfigured'` BEFORE attempting to instantiate the provider class (which would call `getApiKey()` and throw).
- **Lightweight** — 9 of the 12 verifiable providers run a **zero-token** primitive; the remaining 3 cost ~6–7 tokens per call (~$0.00001 at typical rates).
- **Cancellable** — pass `opts.signal` (any `AbortSignal`); the helper distinguishes timeout vs parent-abort in the result.
- **Key redaction** — `result.message` redacts `sk-...` patterns before being surfaced, so an upstream error body that echoes the submitted key won't leak the fragment into a UI log or display.

### How the strategy is chosen

Each provider has one `verifyStrategy` value baked into `provider-capabilities.json`. Three primitives, picked per-provider empirically:

| Strategy | What runs | Cost | Used by built-ins |
|---|---|---|---|
| `count-tokens` | `client.messages.countTokens({ messages: [{role:'user',content:'hi'}] })` | 0 token | `anthropic`, `kimi-code`, `qwen-token-plan`, `zhipu-coding`, `zai-coding`, `minimax-coding`, `ark-coding` |
| `models-list` | `client.models.list()` | 0 token | `openai`, `deepseek`, `kimi`, `qwen` |
| `minimal-message` | `chat.completions.create({max_tokens:1, content:'hi'})` (or Anthropic equivalent) | ~6–7 token | `zhipu`, `mimo`, `mimo-coding` |
| `unsupported` | nothing — short-circuits | — | `gemini-cli`, `codex-cli` (cli-bridge: credentials live in CLI binary) |

`models-list` is NOT used as a universal default because (a) some providers' `/v1/models` is publicly accessible (so a bad key returns 200 — false positive), and (b) some compat layers don't implement it (404) or 401 even for valid keys (false negative). The 2026-05-28 provider probe matrix captured the original per-provider evidence (12 providers at the time; 15 built-in aliases as of 2026-06-28). The current capability catalog has 16 aliases, including `qwen-token-plan` with `count-tokens`; opencode's `setup-recording-env.ts` makes the same per-provider decision across its 20+ providers.

### Custom providers

Custom providers (`registerCustomProviders` / `~/.kodax/config.json`) inherit the verify primitive from their base class. The strategy default is derived from `protocol`:

- `protocol: 'anthropic'` → defaults to `count-tokens`
- `protocol: 'openai'` → defaults to `models-list`

Override with explicit `verifyStrategy` when the upstream needs a different primitive (e.g. an openai-compat gateway whose `/v1/models` is public — set `verifyStrategy: 'minimal-message'`):

```typescript
registerCustomProviders([{
  name: 'my-gateway',
  protocol: 'openai',
  baseUrl: 'https://api.example.com/v1',
  apiKeyEnv: 'MY_GATEWAY_KEY',
  model: 'gpt-4-mini',
  maxOutputTokensField: 'max_completion_tokens',
  verifyStrategy: 'minimal-message',  // optional override
}]);
```

For an OpenAI-compatible endpoint that follows DeepSeek Chat Completions, set
`maxOutputTokensField: 'max_tokens'`. The default is
`max_completion_tokens`; an object entry in `models[]` may override the
provider-level value for a mixed gateway. DeepSeek V4 custom configurations
should likewise use the model-specific `deepseek-v4-flash-openai` or
`deepseek-v4-pro-openai` reasoning preset. (The built-in `deepseek` provider
itself speaks the official Anthropic-compatible protocol and uses the
`deepseek-v4-anthropic` preset; the `-openai` presets are for custom
OpenAI-wire gateways only.)

For a self-hosted multimodal endpoint (vLLM / SGLang serving a Qwen-VL-style
model), set `imageInput: true` on the custom provider config. The flag feeds
the same `capabilityProfile.multimodalSupport: 'image-input'` merge that
built-in vision routes use, so `getModelInputCapabilities()` reports image
support and `validateInputArtifactsForModel()` accepts image artifacts for that
provider. The field flows through every write path that takes
`KodaXCustomProviderConfig` — `registerCustomProviders()`,
`~/.kodax/config.json`, and `runtime.catalog.upsertCustomProvider()` over the
daemon.

The validator rejects illegal combinations:
- `protocol: 'openai'` + `verifyStrategy: 'count-tokens'` → throws (OpenAI protocol has no count_tokens endpoint).

### Model listing — `listProviderModels(name)`

Separate API for "model picker" UIs. Returns the static model list KodaX maintains in `provider-capabilities.json` (or the custom provider's `models` field). Always `source: 'static'` in v0.7.45 — KodaX's curated list is more reliable than upstream `/v1/models` (which is noisy, includes deprecated entries, or — in zhipu's case — is publicly served regardless of auth).

```typescript
import { listProviderModels } from '@kodax-ai/kodax/llm';

const r = await listProviderModels('ark-coding');
if (r.ok) {
  // r.models is e.g. ['glm-5.1', 'glm-4.7', 'kimi-k2.6', ...]
  // r.source is 'static'; durationMs is 0 (no wire call)
  showModelPicker(r.models);
}
```

Cli-bridge providers (`gemini-cli`, `codex-cli`) return their CLI binary's known model list — filled at SDK load via `cli-bridge-models.ts`.

### Reference

- Source: `packages/llm/src/providers/verify-credential.ts` (orchestrator + classifier) + `verify-credential.test.ts` (27 unit tests) + `verify-credential-integration.test.ts` (12 gated real-key/fake-key tests, enabled by `KODAX_INTEGRATION_TEST=1`).
- Data: `packages/llm/src/providers/provider-capabilities.json` `verifyStrategy` field per provider.
- Design notes + probe matrix: [docs/features/v0.7.45.md FEATURE_216](../../docs/features/v0.7.45.md#feature_216-provider-credential-verification-api).

---

## 13. Inject your product's manual — `selfManual` (FEATURE_221, v0.7.47)

### Why

KodaX has a built-in self-knowledge manual + a read-only `kodax_manual` tool: when a user asks how to use / configure / troubleshoot KodaX, the model looks it up instead of guessing (and instead of mixing in Claude Code / Codex knowledge). If you embed KodaX in your own product (say **KodaX-Space**), your users ask about **your product** — and by default they'd get KodaX's internal manual. `selfManual` lets you inject your product's manual so those questions are answered correctly and on-brand.

### Shape

```ts
import { runKodaX, type KodaXManualTopicInput } from '@kodax-ai/coding';

const SPACE_TOPICS: KodaXManualTopicInput[] = [
  { id: 'overview',  title: 'KodaX-Space', summary: 'What KodaX-Space is.', body: 'A desktop coding app built on KodaX.' },
  { id: 'settings',  title: 'KodaX-Space Settings', summary: 'Configure KodaX-Space.', body: 'Open Settings → Providers …', aliases: ['配置'] },
];

runKodaX({
  /* …your usual config… */
  selfManual: {
    productName: 'KodaX-Space',   // re-brands the routing rule + every answer's scope anchor
    topics: SPACE_TOPICS,         // extend the KodaX base; same id overrides a base topic
  },
});
```

### Semantics

- **Extend, not replace.** Your topics are merged on top of KodaX's base topics (same `id` overrides, new `id` adds). So a KodaX-Space user can ask about KodaX-Space *and* about the underlying provider/config (KodaX base topics).
- **`productName` re-brands the prose**, not the tool. The routing rule and each answer's anti-confusion anchor say your product name; the tool stays `kodax_manual` (the model doesn't care about the tool name).
- **Still tool-on-demand + bounded.** Nothing big is injected into the prompt — only the ≤250-token routing rule. Topics live in the registry and are returned one at a time when the model calls the tool, each capped at 4 KB. Drift-guarding your own topics (e.g. not referencing a removed setting) is your responsibility.

### White-labeling further — `baseTopics` (v0.7.58, FEATURE_221)

By default your `topics` **extend** the KodaX base manual. v0.7.58 adds
`selfManual.baseTopics` to control which base topics are present underneath:

- **omit** — all base topics (default; byte-identical to pre-v0.7.58).
- **`[]`** — none: a full white-label replace where only your topics exist, so the
  model never surfaces a KodaX-branded mechanism topic.
- **explicit subset** — seed only the base topic ids you name.

`KODAX_UNDERLYING_CAPABILITY_TOPICS` (exported) is the recommended mechanism-topic
subset a product built on KodaX should keep even in a full replace — so your users
still get correct answers about the underlying engine (providers / config /
permissions / tools / skills / extensions / mcp / repo-intelligence / sessions /
sdk / custom-providers) without the KodaX brand:

The default full manual also includes the `memory` topic. It is intentionally
not part of `KODAX_UNDERLYING_CAPABILITY_TOPICS` because `/experimental-memory`
is opt-in; hosts that expose it should add `memory` explicitly or provide a
product-specific override.

```ts
import {
  runKodaX,
  KODAX_UNDERLYING_CAPABILITY_TOPICS,
  MANUAL_REGISTRY,
} from '@kodax-ai/coding';

runKodaX({
  selfManual: {
    productName: 'KodaX-Space',
    topics: SPACE_TOPICS,
    baseTopics: [...KODAX_UNDERLYING_CAPABILITY_TOPICS], // keep engine topics, drop KodaX-branded ones
  },
});
```

`MANUAL_REGISTRY` (exported, keyed by `KodaXManualTopicId`) lets you read the base
topic bodies at build time — e.g. to re-word them under your own brand.

### Topic shape (`KodaXManualTopicInput`)

`{ id, title, summary, body }` required; `aliases?`, `nextTopics?`, `sources?` optional. Keep `body` short (a few lines) — it is a bounded on-demand answer, not a document.

### Reference

- Types/exports: `KodaXManualTopicInput`, `KodaXSelfManualConfig`, `ResolveKodaXManualOptions`, `buildSelfKnowledgeRoutingRule` from `@kodax-ai/coding`.
- Design: [docs/features/v0.7.47.md FEATURE_221](../../docs/features/v0.7.47.md#feature_221-injectable-self-manual-for-sdk-consumers).

---

## 14. Media input artifacts — `@kodax-ai/kodax/media` (FEATURE_239, v0.7.56)

### Why

Host apps such as KodaX Space own paste/drop UI, sandbox storage, and path
authorization, but they should not import REPL-private files to normalize images
or construct `runKodaX` artifacts. `@kodax-ai/kodax/media` is backed by the
agent-layer `@kodax-ai/agent/media` implementation in v0.7.57, because input
artifacts are an agent capability rather than a coding-only concept.
`@kodax-ai/coding/media` remains as a compatibility re-export for existing
source consumers.

### Quick start

```ts
import {
  createFileArtifactFromPath,
  createImageArtifactFromPath,
  createVideoArtifactFromPath,
  enqueueWithArtifacts,
  getModelInputCapabilities,
  readAndNormalizeClipboardImage,
  validateInputArtifactsForModel,
} from '@kodax-ai/kodax/media';

const image = await readAndNormalizeClipboardImage();
if (!image) {
  // Clipboard did not provide a native image fallback. Continue normal text paste.
  return;
}

const stored = await spaceImageStore.write({
  bytes: image.buffer,
  mediaType: image.mediaType,
});

const artifact = createImageArtifactFromPath(stored.path, {
  mediaType: image.mediaType,
  source: 'clipboard',
  description: 'Clipboard image',
});

validateInputArtifactsForModel([artifact], {
  provider: selectedProvider,
  model: selectedModel,
});

// Pass the artifacts through `runKodaX` (or the `KodaXClient` constructor) —
// `context.inputArtifacts` is the public entry point. `KodaXClient.send`
// takes only a prompt string, so per-call artifacts go through `runKodaX`.
import { runKodaX } from '@kodax-ai/kodax/coding';

await runKodaX(
  {
    provider: selectedProvider,
    model: selectedModel,
    context: { inputArtifacts: [artifact] },
  },
  promptText,
);
```

### Capability query

Use provider and model together. The same model name behind a gateway route is
not assumed to support media unless that route is verified. A registered custom
provider with `imageInput: true` is treated as a verified image route — the
host declares the endpoint's vision capability, so no per-model probe is
needed.

```ts
const caps = getModelInputCapabilities({
  provider: 'minimax-coding',
  model: 'MiniMax-M3',
});

if (caps.image.sdkSupported) {
  enableImageDropZone();
}

if (caps.video.status === 'provider-native-unwired') {
  showVideoComingSoonCopy();
}
```

v0.7.57 can send image artifacts. File and video artifact shapes are stable, but
the SDK runtime does not serialize them yet. Known native-video models report
`video.status = 'provider-native-unwired'` so hosts can show accurate UI without
enabling a send path KodaX cannot serialize yet.

### Artifact contract

`KodaXInputArtifact` is a stable union:

```ts
type KodaXInputArtifact =
  | { kind: 'image'; path: string; mediaType?: KodaXImageMediaType; source?: KodaXInputArtifactSource; description?: string }
  | { kind: 'file'; path: string; mediaType?: string; mimeType?: string; name?: string; source?: KodaXInputArtifactSource; description?: string }
  | { kind: 'video'; path: string; mediaType: KodaXVideoMediaType; name?: string; source?: KodaXInputArtifactSource; description?: string };
```

Use `createFileArtifactFromPath()` for stable file metadata and
`createVideoArtifactFromPath()` when a video path has a supported media type
(`mp4`, `mpeg`, `mov`, `avi`, `flv`, `webm`, `wmv`, `3gp`). Video construction
throws `KodaXMediaError('UNSUPPORTED_MEDIA_TYPE')` if the type cannot be
inferred or supplied.

### File/video downgrade strategy

`getModelInputCapabilities()` distinguishes native provider support from SDK
runtime support:

- `image.status === 'supported'`: SDK can send image artifacts.
- `video.status === 'provider-native-unwired'`: the selected provider/model is
  native-video capable, but KodaX SDK does not serialize video artifacts yet.
- `file.status === 'unsupported'`: file artifacts are contract-stable, but KodaX
  SDK does not upload or extract files yet.

`validateInputArtifactsForModel()` enforces that policy before provider send.
Hosts should use the thrown `KodaXMediaError.code` and `detail` to disable send
or show downgrade UI. If Space wants to support files before SDK runtime wiring,
Space should perform its own extraction and include the extracted text in the
prompt rather than passing the file artifact through as sendable media.

### Queued follow-ups with artifacts

For streaming follow-ups, use `enqueueWithArtifacts()` instead of the raw
message queue:

```ts
enqueueWithArtifacts({
  provider: selectedProvider,
  model: selectedModel,
  sessionId: activeSessionId,
  content: followupText,
  inputArtifacts: [artifact],
});
```

The helper validates first and then stores `inputArtifacts` on the queued prompt.
Queued image follow-ups are rebuilt as multimodal content blocks on the next
runner turn. Unsupported file/video attachments are rejected before enqueueing.
Pass `sessionId` whenever the host can run more than one session concurrently;
it targets that Actor session's root queue without exposing Actor paths. For
backward compatibility, omitting both `sessionId` and `agentId` still binds to
the sole active Actor root, or uses the legacy unscoped SA queue when no Actor
run is active. If multiple Actor roots are active, the helper rejects the
ambiguous call instead of risking cross-session delivery. Low-level child-Actor
producers may continue to pass an explicit `agentId`.

`enqueueWithArtifacts()` is an in-process queue helper for direct/inline runs.
Daemon clients must use `runtime.runs.submitInput(...)` (with
the same `sessionId` and `afterRunId`) because a process-local MessageQueue
cannot cross the transport boundary. Use `delivery:'after_turn'` to create
a continuation Run after the current Run ends, or `delivery:'interrupt'` to
inject into the current active Actor Run at its next safe Runner boundary.

### Boundaries

- `readAndNormalizeClipboardImage()` returns `null` when there is no clipboard
  image fallback; thrown `KodaXMediaError` values are stable enough for host copy.
- Direct image path artifacts preserve `image/png`, `image/jpeg`, `image/webp`,
  and `image/gif`; clipboard normalization emits static PNG/JPEG bytes and may
  flatten animated GIFs before artifact creation. `image/gif` capability means
  SDK can pass the bytes and media type; provider animation semantics vary
  (for example, first-frame-only or non-animated GIF handling).
- `persistImageAsBlock()` is a convenience helper. Embedded hosts should usually
  pass `directory` or store bytes in their own sandbox before constructing an
  artifact path.
- `validateInputArtifactsForModel()` is pure shape/model validation. It does not
  probe host-owned sandbox paths.

### Reference

- Public SDK entry: `src/sdk-media.ts`.
- Shared implementation: `packages/agent/src/media/`.
- Compatibility source re-export: `packages/coding/src/media/`.
- Design: [docs/features/v0.7.56.md FEATURE_239](../../docs/features/v0.7.56.md#feature_239-sdk-multimodal-input--clipboard-image-public-api).

---

## 15. Space v0.7.57 follow-up ledger

These are the remaining SDK-consumer integration decisions reported after the
v0.7.57 source review. They are not all KodaX core regressions; most are Space
UI/API follow-ups that should consume the SDK contracts already exposed here.

- **Custom provider reasoning form**: Space should expose the v0.7.57 custom
  provider shape `reasoning: { efforts, default }` or `"none"` instead of only
  legacy reasoning-mode inputs. Keep using the SDK validator from
  `@kodax-ai/kodax/llm` so Space does not maintain a parallel schema.
- **Effort selector**: Space should build effort choices from
  `resolveModelCapabilities(provider, model)?.reasoningProfile.supportedEfforts`
  and `defaultEffort`. A fixed five-option selector will miss provider-specific
  values such as `xhigh`, `max`, or custom-provider effort names.
- **Repo-intelligence prewarm**: `prewarmRepoIntelligenceCaches()` is currently a
  best-effort warmup call, not a progress/completion contract. Hosts can call it
  opportunistically; if Space needs visible progress or a completed state, the
  next SDK step should be a small handle/result API rather than inferring status
  from cache side effects.
- **Relationship scan**: `relationship_scan` is a v0.7.57 agent/tool capability.
  It is intentionally model-facing today. Space can decide separately whether it
  deserves a top-level UI entry or remains available through normal agent turns.
- **Quick Ask / `sideQuery`**: `sideQuery` is exported from
  `@kodax-ai/kodax/llm`, so the capability ledger can move from blocked to
  partial. Migrating Space Quick Ask still needs an application-level decision
  about transcript promotion and history semantics, because `sideQuery` is an
  isolated text-only one-shot call rather than a chat-session append.

---

## 16. SDK agent-profile surface — `KodaXAgentProfile` (FEATURE_247, v0.7.58)

### Why

An SDK embedder (e.g. **KodaX-Space Partner**) often needs to run KodaX under a
named product persona — its own identity + instructions, a narrowed tool surface,
and a default verification standard — without forking the agent. `KodaXAgentProfile`
provides this as one **opaque, profile-gated** object on `options.context`. With no
`agentProfile` set the default Coding Agent is **byte-identical**; every path below
is a no-op.

### Shape

```ts
runKodaX({
  /* …your usual config… */
  context: {
    agentProfile: {
      surface: 'partner',            // opaque label ('code' | 'partner' | …)
      name: 'KodaX-Space Partner',   // opaque display name
      instructions: '…house rules injected into the AMA/AMAW Worker role prompt…',
      verification: { /* KodaXTaskVerificationContract — profile-default standard */ },
    },
    // R2 — narrow the model-visible tool list (applied on top of excludeTools):
    toolVisibilityPolicy: (tool) => tool !== 'web_search',
  },
});
```

### What each field / companion gates

- **R1 — identity + instructions.** `agentProfile.instructions` is prepended to the
  AMA/AMAW Worker role prompt; the SA path uses `context.systemPromptOverride`
  (mapped from `instructions` by `startKodaX`), so a profile behaves consistently
  across both execution modes.
- **R2 — `context.toolVisibilityPolicy`.** A predicate applied when the
  model-visible tool list is built (in addition to `excludeTools`); tools it returns
  `false` for are hidden from the model.
- **R3 — `agentProfile.verification`.** A profile-default `KodaXTaskVerificationContract`
  merged with per-task `context.taskVerification` (per-task fields win) before it
  reaches the main agent on both SA and AMA paths.
- **R4 — `KodaXEvents.onEffectiveConfig`.** Reports the effective agentMode / tool
  scope / verification at run start, so a host can reflect what
  the profile actually resolved to.
- **R5 — metadata across `fork()`.** Structured `profile` + `runtimeInfo` metadata
  ride on results and are inherited by forked sessions.
- **R6 — `compactSession(id, options)`** from `@kodax-ai/kodax/session` — an
  imperative session compaction the host can trigger directly.
- **R7 / R8 — attribution.** Session / profile / toolCall attribution is threaded
  into the tool execution context and onto inline-workflow process events + AMA tool
  events.
- **R9 — `reads-network` side-effect class** (`isToolNetworkRead`) tags read-only
  network tools (`web_search`, MCP read / prompt) so a profile can allow network
  reads without granting mutation.

### Reference

- Types: `KodaXAgentProfile`, `KodaXToolVisibilityPolicy`, `KodaXEffectiveTaskConfig`
  from `@kodax-ai/coding`; `compactSession` from `@kodax-ai/kodax/session`.
- Design: [docs/features/v0.7.58.md](../../docs/features/v0.7.58.md) FEATURE_247.

---

## 17. Runtime SDK and local daemon (FEATURE_253-FEATURE_257)

`@kodax-ai/kodax/runtime` is the stable host-facing runtime facade for
applications that want KodaX as a substrate instead of only as a terminal CLI.
It wraps the same coding/session engine used by the REPL and exposes it through
one interface in two deployment shapes:

- **embedded / inline**: in-process runtime owned by the caller;
- **daemon**: local-only runtime owner reached through a named pipe on Windows or
  a Unix domain socket on Linux/macOS.

The v0.7.96 Worker-hosted embedded runtime (`isolation: 'worker'`, the
`dist/runtime-worker.js` sidecar, and the `requirements.hardDispose` gate) was
removed in v0.7.97. Loading the configured A2A plane is owner wiring, not
Runtime magic: call `createConfiguredA2ARuntimeIntegration({ configHome })`
(exported from `@kodax-ai/kodax/a2a`) and pass its `runtimeOptions` as
`externalAgents` — exactly what the CLI does for both its embedded sessions
and the daemon Host it launches.

The daemon is not a separate product engine. It hosts the embedded runtime behind
a process boundary, so REPL, Space, IDE adapters, ACP, and custom SDK clients can
share the same profile runtime without reimplementing sessions, permissions,
events, config, MCP, catalogs, artifacts, or diagnostics.

### Which shape to use

Product UI and shared-Session automation should use `/client` as described at
the top of this guide. This table also identifies explicit low-level ownership.

| Host scenario | Recommended shape | Why |
|---|---|---|
| Unit tests, one-off scripts, short-lived SDK tools | `createKodaXRuntime()` | No daemon lifecycle; easiest cleanup. |
| A single app owns all KodaX state in one process | `createKodaXRuntime({ mode: 'embedded' })` | Direct in-process calls and no IPC. |
| REPL + Space + IDE product clients | `ensureKodaXClient({ profile, homeDir })` | Starts or reuses the Host and returns the Product contract. |
| Product attach-only client | `connectKodaXClient({ profile, homeDir })` | Passive; fails if no compatible Host is ready. |
| Trusted low-level daemon integration | `ensureKodaXRuntime` / `connectKodaXRuntime` | Runtime services rather than Product business methods. |
| Test/CI isolated daemon namespace | pass `homeDir` and `profile` | Keeps state/config/sessions out of the user's home daemon. |

### Public construction contract

Import the Runtime facade from the dedicated subpath:

```ts
import {
  createKodaXRuntime,
  connectKodaXRuntime,
  type CreateKodaXRuntimeOptions,
  type KodaXRuntime,
} from '@kodax-ai/kodax/runtime';
```

The important creation options are:

| Option | Default | Contract |
|---|---|---|
| `mode` | `'embedded'` | Chooses private ownership or a shared daemon process. |
| `homeDir` | unset | When omitted, use the exact resolved `KODAX_HOME`. When set, this is the base directory that owns `.kodax`, with the same meaning as CLI `daemon --home`; daemon state/config live under `<homeDir>/.kodax`. |
| `profile` | `'default'` | Daemon uniqueness and runtime configuration namespace. |
| `sessionsDir` | `<homeDir>/.kodax/sessions` | Explicit session storage override. |
| `daemonStartupTimeoutMs` | `60000` | Total cold-start/concurrent-owner wait budget. |
| `daemonConnectTimeoutMs` | `2000` | Per-socket connection timeout. |
| `autoStartDaemon` | conditional | For `createKodaXRuntime({mode:'daemon'})`, true only when no explicit endpoint/transport is supplied. |
| `execPolicy` | unset | Trusted host-owned administrator rules and canonical trusted-project roots. The inline owner receives it directly; daemon mode accepts it only while auto-starting a new owner. |
| `autoReview` | unset | Trusted host-owned administrator/model guidance for Auto review. It follows the same owner-only transport contract as `execPolicy`. |
| `externalAgents` | unset | Host-installed executor factories, dispatch policy, optional credential/artifact policies, and default dispatch context. Inline owner only; see §18. |
| `requirements.externalAgents` | `false` | Reject a Runtime/daemon connection that does not advertise an installed external-agent plane. |

The former `isolation`, `worker.*`, and `requirements.hardDispose` options were
removed with the Worker facade in v0.7.97; supplying them is now a plain unknown-
option error. Options are never silently ignored to select a weaker ownership
form.

### Basic embedded usage

```ts
import { createKodaXRuntime } from '@kodax-ai/kodax/runtime';

const runtime = await createKodaXRuntime({
  mode: 'embedded',
  homeDir: '/tmp/my-host-kodax',
  defaultProvider: 'zai-coding',
});

try {
  const session = await runtime.sessions.create({
    title: 'SDK embedded session',
    projectPath: process.cwd(),
    surface: 'my-host',
  });
  const handle = await runtime.runs.start({
    sessionId: session.id,
    prompt: 'Read package.json and summarize this project.',
  });
  const result = await handle.result;
  console.log(result.phase);
} finally {
  await runtime.close();
}
```

### Basic daemon usage

```ts
import { createKodaXRuntime, connectKodaXRuntime } from '@kodax-ai/kodax/runtime';

const replLikeClient = await createKodaXRuntime({
  mode: 'daemon',
  profile: 'default',
  clientInfo: { name: 'my-repl', title: 'My REPL', version: '1.0.0' },
  capabilities: {
    richEvents: true,
    permissionPrompts: true,
    contextDiagnostics: true,
  },
});

const spaceLikeClient = await connectKodaXRuntime({
  profile: 'default',
  clientInfo: { name: 'my-space', title: 'My Space', version: '1.0.0' },
  capabilities: {
    richEvents: true,
    permissionPrompts: true,
    contextDiagnostics: true,
  },
});

try {
  console.log(replLikeClient.identity.runtimeId === spaceLikeClient.identity.runtimeId);
} finally {
  await spaceLikeClient.close();
  await replLikeClient.close();
}
```

This is a low-level Runtime example, not the default product integration.
`createKodaXRuntime({ mode: 'daemon' })` is a retained convenience API: when
no explicit `daemonEndpoint` or `daemonTransport` is supplied it starts or reuses
the local profile daemon. `connectKodaXRuntime()` is passive and rejects
`autoStart: true`; use `ensureKodaXRuntime()` for low-level startup/update.

Trusted `execPolicy` and `autoReview` options are owner bootstrap inputs, not
client connection settings. For a new daemon, KodaX transfers them through a
bounded one-shot file in the selected daemon state directory, consumes and
deletes that file before loading extensions, and never exposes its contents in
process arguments or the daemon protocol. If the profile already has an owner,
creation with non-empty owner policy fails closed; stop that daemon and retry if its
administrator policy must change. Ordinary `connectKodaXRuntime()` clients
cannot supply or mutate these policy layers.

SDK auto-start allows `daemonStartupTimeoutMs` (default 60 seconds) and
`daemonConnectTimeoutMs`. The longer startup budget covers cold machines and
concurrent test/desktop startup without weakening PID, endpoint, token, or
runtime-identity validation.

### Windows daemon shutdown containment (v0.7.83)

On Windows, a newly started daemon is created suspended and assigned to a
kill-on-close Job Object before it is resumed. Daemon application code cannot
create descendants before that assignment. An out-of-Job supervisor waits for
the daemon to exit and then waits for the Job's active-process count to reach
zero, so a daemon PID exit alone is not a verified shutdown.

Hosts that own the shutdown boundary can use the public verifier:

```ts
import { waitForRuntimeDaemonShutdown } from '@kodax-ai/kodax/runtime';

const result = await waitForRuntimeDaemonShutdown({
  homeDir: kodaxHome,
  profile: 'default',
  runtimeId,
  timeoutMs: 30_000,
});
if (!result.verified) {
  throw new Error(`Runtime shutdown was not verified: ${result.outcome}`);
}
```

The connected daemon must advertise `daemonShutdownVerification: 1` when a host
requires this contract. A legacy daemon without Job-containment metadata is
kept usable for ordinary Session recovery, but it is never reported as a
verified shutdown and is not silently upgraded in place. Stop it explicitly and
relaunch it before requiring the capability. The CLI's `kodax daemon stop
--json` follows the same daemon-plus-supervisor boundary.

The daemon-owned slice does not carry the former Runtime Worker's
child-lifetime gap (Issue 256); that owner-lease work remains open after
v0.7.87 only for constructed-handler workers, without a replacement target
assigned by this release. Executor cleanup still uses identity-checked
evidence and fails closed when a descendant cannot be proven gone.

### Actor settlement recovery (v0.7.84)

The v0.7.84 Actor settlement boundary bounds progress persistence to one
in-flight durable projection plus one latest replacement. A terminal save can
therefore make progress without waiting behind an unbounded backlog. If Actor
durability becomes unknown because that boundary times out, a
`runtime.runs.abort()` Stop can reconcile the late Actor snapshot only for the
exact same local owner, validate the owner fence, quiesce remaining turns, and
retry the repair.

The receipt remains unknown until both Actor and executor settlement are
resolved. Repeated same-owner Stop delivery is idempotent under the same
unknown-owner proof; foreign owners, missing snapshots, legacy records, and
unresolved stores fail closed. After repair, Promise terminal facts win over
fallback callbacks, so a stale callback cannot rewind a terminal Run or emit a
duplicate outcome. A no-op quiesce does not rewrite the Session.

### v0.7.85 Runtime and Memory release boundaries

The v0.7.85 SDK originally added Session-scoped durable Runtime Event Journals;
v0.7.97 removes that surface. Events are now a live in-process stream only:
each envelope is `{ id, seq, time, sessionId, runId, turnId?, type, payload }`,
where `seq` is a per-Session in-process ordering hint. It starts at `1`, resets
when a Session is deleted and recreated, and is not comparable across restarts
or Sessions. There is no durable `event.replay` RPC, no
`{ sessionId, journalEpoch, seq }` cursor, and no `sessionEventJournal:1`
capability; remote consumption reuses `session.observe` notifications, and the
SDK `runtime.events.subscribe()` facade delivers the same live stream. A2A
binds one Runtime Session to each Task.

Memory management is conversation-first for explicit remember, correction,
forget, recall, and exceptional-decision requests. Safe explicit mutations are
host-governed and immediate; ambiguous or inferred changes remain reviewable.
F289/F290 bound review draining and lesson/verdict admission, and the
experimental Memory SDK exposes the additive management facade only when the
supplied controller supports it. Terminal Runs with authoritative status and
no queued interrupt input are restored at startup without replaying event
history. The semantic repo-intelligence Worker retires after its idle
warm-cache window, while later cache misses start a fresh Worker.

### v0.7.86 Runtime ownership and sandbox lifecycle boundaries

The v0.7.86 SDK hardens ownership and sandbox cleanup without weakening the
fail-closed contract. Inline daemon-enable recovery removes only a provably
abandoned inline owner fence; live, malformed, legacy, and ambiguous owners
remain untouched. Runtime owner and learning-file lock records include an OS
process-start identity, so PID reuse cannot preserve stale ownership.

On Windows, sandbox ACL owner markers are durable and recovery is serialized
across Runtime profiles. A sandbox stop waits for process-tree termination proof
before ACL recovery. Missing attestation fences later filesystem effects and
does not replay the command; spawn, lease-release, and authoritative lifecycle
cleanup failures remain combined in the lifecycle diagnostic for operator
recovery. After lifecycle proof, best-effort deletion of a command-owned private
Temp leaf cannot replace the proven result; failure is reported as a warning.

POSIX workspace sessions use the same replacement fence: an unconfirmed
process-tree or cleanup failure latches the sandbox safety state and prevents a
new workspace session from racing the retained one. A fresh `KODAX_HOME` has
its Runtime-owned policy roots initialized before identity capture, concrete
admission waits only for workspace-local warm-up within the Shell abort/deadline,
and lease-cleanup failure retires the invalid cached session before replacement.

Windows workspace Shell execution also preserves case-insensitive `PATH`/`Path`
and `PATHEXT` values through both Runtime broker layers. Read grants are derived
from the final shell PATH and executable, including only bounded junction
ancestors for profile-managed toolchains. The `cmd.exe` verbatim-argument
contract is retained for quoted paths and executable lookup. Exact workspace,
Agent Home, additional-filesystem, toolchain, and network policies form a
cross-process Windows policy group; compatible owners join without global ACL
recovery and only the last owner recovers. Incompatible policy or pre-start
infrastructure failure returns to the already-authorized normal permission path.
A missing lifecycle attestation after target start remains fail-closed and is
never repaired by replaying the command. Runtime sandbox capability v3 first
fenced older daemon policy revisions in v0.7.86. The v0.7.95 contract was
`sandboxRuntime:5`: auto-start replaced an idle older daemon and failed closed
while it was busy. Version 5 added automatic same-boot Windows ACL recovery: a
sandbox-user SID probe must prove that no unrelated process remains before an
uncontained `unconfirmed-owner` ticket is cleared. Probe uncertainty is
diagnosed and retried automatically; it never becomes permission to reset ACLs.
Sandboxed text cleanup also retains a consumed execution attestation
across retries. Transient workspace cleanup, policy reset, and outer effect
lease release are retried without replaying the text operation or repeating a
completed cleanup phase.

`homeDir` and `KODAX_HOME` deliberately name different levels. Runtime SDK and
CLI daemon `--home` accept the **base directory that contains `.kodax`**;
lower-level `KODAX_HOME` points at the **data directory itself** and need not be
named `.kodax`. To share the default CLI daemon, omit `homeDir`; this honors the
exact resolved `KODAX_HOME`. Passing `os.homedir()` explicitly instead selects
`<os.homedir()>/.kodax`, regardless of an ambient custom `KODAX_HOME`. For an
isolated embedder namespace, pass a private base directory and expect data at
`<homeDir>/.kodax`. Passing `~/.kodax` as `homeDir` would instead select
`~/.kodax/.kodax` and a different daemon namespace.

### v0.7.88 GLM Coding Plan boundaries

The built-in model catalog exposes `glm-5.3`, `glm-5.2`, and (since
2026-08-26) the natively multimodal `glm-5.3-flash` for `zhipu-coding` and
`zai-coding` (flash also on public `zhipu`); both aliases default to
`glm-5.3` (the overseas alias switched from `glm-5.2` on 2026-08-15).
`ark-coding` likewise defaults to `glm-5.3` and keeps `glm-5.2` (alias
`glm-latest`). Capability metadata still records the 1M context locally,
but the provider sends the model ID verbatim and never appends `[1m]`.

GLM-5.3 and `glm-5.3-flash` are always-thinking. Hosts may continue to express a stable `off` /
`none` intent; KodaX normalizes it to low effort. Anthropic-compatible requests
use adaptive thinking plus `output_config.effort`, while OpenAI-compatible
requests use enabled thinking plus `reasoning_effort`.

### v0.7.89 web search and run-scoped Host Tools

The built-in `web_search` remains zero-service and requires no API key or
hosted search provider. Its default bounded attempts are DuckDuckGo's HTML
results, Bing RSS, then Bing HTML. A structurally valid empty result is a
successful empty result; transport, challenge, HTTP-status, or parse failures
fall through with per-attempt diagnostics. Results expose normalized direct
HTTP(S) locators, deduplicated items, `freshness: unknown` when freshness is not
provable, and the winning transport metadata. `KODAX_WEB_SEARCH_ENDPOINT` is
an explicit single-endpoint compatibility override and never silently joins the
public fallback chain.

When a daemon run binds a Host Tool lease, v0.7.89 materializes the leased
descriptors into that run's model-facing tool table and adds a cache-stable
`Host Capability Provider (run-bound)` catalog block. Host Tools remain outside
`TOOL_REGISTRY`; dispatch is registry-first, so the executed schema is the one
the model saw. `none` side effects are readonly/plan-allowed, while
`idempotent` and `non_idempotent` tools are mutating/plan-blocked. Revocation,
name collisions, malformed lease ids, and unknown capability paths fail closed;
unrelated CLI runs do not inherit a Space lease. A2A role policies may authorize
exact `host:<leaseId>:<tool>` capability ids.

### v0.7.90 stabilization boundaries

The v0.7.90 patch preserves the v0.7.89 SDK contracts while tightening three
follow-up boundaries. A workspace-session RPC timeout fails its pending request
and retires the shared session through orderly close; cleanup may use the full
reset-grace budget before a replacement is admitted. Daemon diagnostics encode
Error names/messages, `AggregateError.errors`, and `cause` chains, including
cyclic chains, so hosts can distinguish timeout, attestation, and deletion
failures.

Session lineage `sourceEntryId` is the direct physical predecessor copy, not a
transitive root. The archive slimmer keeps a direct predecessor referenced by a
retained clone addressable for one hop and places its archive marker under the
retained parent. Hosts should continue to use `readConversationHistory()` for
ordinary-chat folding and `readFullTranscript()` for raw audit scrollback.

Run-scoped leased/embedded tool schemas are normalized at the shared model
materialization point to `{ type: 'object', properties, required? }`; only
string names remain in `required`. This keeps the schema shown to the model and
the provider wire contract aligned across daemon and embedded hosts.

### Close, abort, and ownership semantics

The same method name deliberately has deployment-specific ownership effects:

| Form | `runtime.close()` | Run abort | After owner crash/termination |
|---|---|---|---|
| embedded / inline | Cancels owned runs and permissions and closes private runtime state. It cannot recover a host event loop blocked by arbitrary inline code. | `runs.abort(runId)` settles the Runtime handle and forwards cancellation to coding. | The embedding process owns recovery. |
| daemon client | Detaches only this client transport. Other REPL/Space/SDK clients and runs remain owned by the daemon. | Aborts only the addressed run. | The client connection rejects; reconnect explicitly after the daemon is healthy. |

`close()` is idempotent. It is not a shared-daemon stop command. Use
`kodax daemon stop`, `kodax daemon restart`, or an authenticated low-level
`runtime.shutdown` request for administrative shutdown. KodaX does not
automatically retry or replay an in-flight run after a daemon owner dies,
because provider and tool side effects may already have happened.

`runtime.shutdown` performs a real idle shutdown: it takes the draining fence,
rechecks preflight, and stops the daemon only when no active or queued run,
Workflow, Agent turn, pending permission/user input, other logical client, or
in-flight mutation exists; otherwise it fails with a structured `conflict`
error and the daemon keeps running. Shutdown never changes the owner mode
implicitly — a daemon-to-inline ownership change goes only through an explicit
`setKodaXRuntimeOwnerMode()` call, or owner-lock release followed by
`acquireKodaXInlineOwner()`; the former `stopForInline()` rollback and the
crash-resumable exit-settlement transaction were removed in v0.7.97. Host-close
logging and owner-lock release are still intermediate
progress boundaries. A successful `kodax daemon stop` / `restart` additionally
waits for the original daemon PID to disappear and verifies a shutdown-success
outcome bound to that exact Runtime ID and PID. Before that process exits, the
serve host completes bounded A2A/extension, LSP, managed-child-tree, and tracing
cleanup; an unverified current-owner child tree, cleanup timeout, failed outcome,
or missing outcome makes CLI stop fail instead of reporting a false success.
The stop client also owns an outer watchdog that starts when the request is
accepted. On Windows it captures the daemon's creation identity before
requesting shutdown and can therefore reclaim that exact process tree if
Runtime close never settles or synchronous code blocks the daemon event loop.
Node 20 exposes only cached-PID signaling on POSIX, so KodaX fails closed there
instead of risking a reused PID/PGID; the result is `cleanup_unverified` and the
process is left to an external lifecycle manager until Issue 269 supplies a
retained native handle/supervisor. A forced exit without a matching success
outcome is never success. After the original PID exits, the client re-reads the profile; JSON
results use `replacementRunning: true` and return the current state/health when
a replacement daemon has already acquired the owner lock. Such a result also
uses `stopped: false` and `reason: 'replacement_running'`, so existing callers
that gate cleanup on `stopped` remain safe. Callers must not clean or rebuild a
profile while that flag is present or health is non-missing.
The administrative connection also verifies that `initialize.identity` still
matches the Runtime ID/profile observed before connecting; if an old owner exits
and a replacement binds the same endpoint first, the stale stop command fails
without sending `daemon.stop` to the replacement.

### Daemon ownership and state

Daemon ownership is scoped by `homeDir + profile`.

- Default `homeDir` is the OS user home directory.
- Default `profile` is `default`.
- State lives under `.kodax/runtime/daemon/{profile}/`.
- Default runtime session storage is also scoped under `<homeDir>/.kodax/sessions`
  when `sessionsDir` is omitted.
- Windows uses a named pipe; Linux/macOS use a Unix domain socket.
- The daemon opens no public TCP listener.

For a given profile, one owner wins an atomic lock. Concurrent starters wait for
the winner and connect once it is ready. Stale state is cleaned only after pid,
endpoint, token, and runtime identity checks. If ownership cannot be verified,
KodaX reports the daemon as unhealthy instead of killing an arbitrary process.
SDK auto-start launches a detached `kodax daemon serve` process; it never treats
an in-process socket listener as daemon mode. Closing the SDK client detaches
without stopping that shared process. Use `kodax daemon stop` or the explicit
runtime shutdown protocol to stop the owner.

CLI and SDK startup retain the exact spawned candidate until health confirms
that candidate PID. Early exit, timeout, identity mismatch, cancellation, or a
different owner winning the race reclaims only the unsuccessful candidate
process tree. Once healthy, the owner detaches normally and is not tied to the
creating client process.

### Daemon startup, conflict, and recovery behavior

REPL, Space, and SDK callers using the same resolved `homeDir + profile` target
the same daemon. Simultaneous startup is expected: candidates race only for the
atomic owner lock, then non-owners wait for and attach to the verified winner.
A client never owns a daemon merely because it caused auto-start.

When auto-start refreshes an older build, concurrent temporary clients retain
the same client-count and ownership fences. A conflict or reconnectable
`protocol_closed` / `transport_error` during initialization or the read-only
upgrade inspection releases that connection before retrying against the current
Owner. Inspection retries and client contention share the original startup
deadline; cancellation interrupts backoff. The randomized contention window
also accounts for the previous inspection duration so sub-second reconnects do
not continually invalidate a slower peer. Shutdown and business requests are
never replayed by this recovery. Corrupt data, invalid frames, client-initiated
closure, and an unverified live Owner remain explicit failures. Passive connect
does not gain auto-start or replacement behavior. Existing startup progress
types are unchanged: a retried inspection reports `checking`.

The shared Host performs historical managed-child recovery once after acquiring
its Owner and Session-storage fences, before readiness, in its resolved config
home. Clients do not repeat that sweep; process exit still verifies its own
exact registrations. Passive connect and private embedded Runtime construction
do not run shared-Host global recovery. Stop preflight projects canonical Actor
metadata without materializing transcripts, while retaining all admitted active
Session coverage, writer/file identity fences, and Owner liveness checks. Resume
indexes never authorize stopping a Host. Claimed Actor controllers are checked
for admission before initialization and supply live state while persistence is
pending; unclaimed Actors use canonical metadata. Existing process/Job/supervisor and
durable shutdown verification remain required; unavailable evidence stays unknown.

Standalone MCP embedders can pass `McpProviderOptions.configHome` (or transport
`configHome`) to bind stdio process registration and recovery to their Host;
`cacheDir` remains a separate cache location. Product Hosts supply it for
prewarm, lazy connection, reload and reconnect. Runtime tool execution, dynamic
Skill context and hooks inherit the same trusted home without changing the
process-global Agent home. Omitted standalone options retain Agent defaults.

On abnormal exit, the next start validates the saved PID, endpoint, token, and
runtime id before removing stale state. KodaX will not kill a process whose
ownership cannot be proven. Persisted queued/running/waiting-permission runs are
recovered as `interrupted` with a runtime event; they are not resumed
automatically. Session and bounded event records remain available for explicit
reconnect/retry decisions.

Operational guidance:

- use one stable profile for cooperating desktop clients;
- use a separate `homeDir` or profile for tests, previews, and incompatible
  configurations;
- test harnesses that auto-start a process daemon must send authenticated
  `runtime.shutdown` (or run `kodax daemon stop --home <dir> --profile <name>`)
  before deleting their temporary home; use the CLI command when the caller
  needs a completed process-exit boundary, because `runtime.close()` only
  detaches and the low-level shutdown response is acceptance, not completion;
- KodaX's own Vitest harness also supplies an internal worker-PID marker so a
  forcibly terminated worker cannot strand its test daemon; this is a test-only
  fallback, not a public SDK option or a production idle-shutdown policy;
- query `kodax daemon status --json` before deciding to restart;
- inspect `kodax daemon logs --lines 100` when startup times out;
- custom endpoints and injected transports are attach-only unless the caller
  implements their owner lifecycle explicitly.

The matching CLI surface is:

```bash
kodax daemon start --profile default
kodax daemon status --profile default --json
kodax daemon logs --profile default --lines 100
kodax daemon stop --profile default --json
kodax daemon restart --profile default
```

Inside the REPL, `/status runtime` reports embedded/daemon mode, profile,
runtime id, endpoint/health when applicable, and active/queued counters.

### Runtime services

Every `KodaXRuntime` exposes the same service set in inline and daemon mode:

| Service | Purpose |
|---|---|
| `identity` | Runtime id, mode, isolation (`inline` for embedded, `process` for daemon), profile, started time, package version. |
| `sessions` | Create/load/list/fork/transcript/settings/notice/rewind/compact/archive/delete. |
| `runs` | Start/await/get/list/abort runs; update provider/model/reasoning for supported phases. |
| `events` | Subscribe to the live in-process event stream (one `seq` ordering hint per Session). |
| `permissions` | Request/list/respond to tool permissions across clients. |
| `workflows` | Observe workflow process snapshots/events and lifecycle controls. |
| `config` | Read/patch/reload daemon or embedded profile config. |
| `catalog` | Providers, models, commands, skills, custom providers, extensions. |
| `mcp` | MCP server CRUD, validation, reload, and tool catalog listing. |
| `artifacts` | Create/get/delete runtime artifact references for file/image/video inputs. |
| `status` | Runtime snapshot with sessions, runs, permissions, workflows, and daemon counters. |
| `admin.agentRegistrations` | List/upsert, atomically set `enabled` while preserving the full registration, or remove redacted external-agent registrations. Owner/revision-conditional mutation prevents a stale manager from changing a same-ID replacement. With no plane, list is empty and mutations fail clearly. |
| `agents` | Check `enabled`, list/describe policy-filtered dispatchable agents, and preflight a selected route. |
| `agentTasks` | Start/list/get/wait/continue/cancel/reconcile durable external-agent tasks and read their ordered event stream. |

### Sessions, runs, and queueing

Runs are serialized per session and can run concurrently across different
sessions. Same-session prompts are FIFO queued. `runs.start()` returns a handle
with a `result` promise that always settles on completion, failure, abort, or
runtime close.

```ts
const session = await runtime.sessions.create({ title: 'Shared session' });

const sub = runtime.events.subscribe({ sessionId: session.id }, (event) => {
  if (event.type === 'assistant.delta') {
    // Render streaming text in the host UI.
  }
});
// Daemon subscriptions establish a remote handshake. Await this before
// starting work whose first event must not be missed; local subscriptions omit it.
await sub.ready;

const artifact = await runtime.artifacts.create({
  kind: 'image',
  path: '/tmp/screenshot.png',
  mediaType: 'image/png',
});

const handle = await runtime.runs.start({
  sessionId: session.id,
  input: [
    { type: 'text', text: 'Review this screenshot.' },
    { type: 'artifact_ref', artifactId: artifact.id },
  ],
  options: {
    provider: 'zai-coding',
    effort: 'high',
  },
});

const result = await handle.result;
sub.close();
```

### Structured, credential-safe Runtime failures

> Availability: v0.7.96-alpha.3. A host using a published pre-v0.7.96 package
> must tolerate an absent `failureDetail`.

Provider text is useful for debugging, but forwarding a raw upstream error is
not a safe SDK contract: it can contain a response body, echoed prompt or
credential, request headers, signed URL, local path, or stack. It is also not a
stable programmatic contract across providers. Runtime therefore normalizes
the useful facts once. When a classified failure fact exists, it publishes the
same optional `RuntimeFailureDetail` through all authoritative surfaces:

| Surface | Location |
|---|---|
| Event | `event.payload.failureDetail` on `run.failed`, `run.cancelled`, `run.interrupted`, or settlement-uncertainty `run.updated` |
| Result | `RuntimeRunResult.failureDetail` from `handle.result` or `runtime.runs.await(runId)` |
| Status | `RuntimeRunStatus.failureDetail` from `runtime.runs.get()` / `runtime.runs.list()` |
| Diagnostics | `RuntimeSessionDiagnostics.run.failureDetail` from `runtime.sessions.diagnostics()` |

These surfaces are projections of the same Run fact and use the same
classification and safe values whenever the optional fact is present. A failed
`KodaXResult` such as a policy-blocked result may have no `failureDetail`.
Runtime settlement that cannot be persisted remains `phase:'unknown'` and uses
`run.updated`; it does not emit a false terminal event. Do not infer a more
specific category from an older `error` or terminal message.

```ts
import {
  parseRuntimeEvent,
  type RuntimeFailureDetail,
} from '@kodax-ai/kodax/runtime';

function renderRuntimeFailure(detail: RuntimeFailureDetail | undefined): void {
  if (!detail) {
    // Older Runtime/daemon or a lifecycle state with no classified failure.
    showFailure('The run failed without structured diagnostics.');
    return;
  }

  switch (detail.providerErrorCode) {
    case 'authentication_failed':
    case 'credential_unavailable':
      showCredentialAction(detail.safeMessage);
      return;
    case 'rate_limited':
      if (detail.retryAfterMs !== undefined) {
        scheduleRetry(detail.retryAfterMs);
      } else {
        showRateLimit(detail.safeMessage);
      }
      return;
    default:
      showFailure(detail.safeMessage, {
        code: detail.providerErrorCode,
        requestId: detail.requestId,
      });
  }
}

const sessionId = session.id;
const failureSub = runtime.events.subscribe(
  { sessionId },
  (event) => {
    const parsed = parseRuntimeEvent(event);
    if (!parsed.ok) return;
    const typed = parsed.event;
    if (typed.type === 'run.updated') {
      const settlementCode = typed.payload.lifecycleError?.code;
      if (
        typed.payload.phase === 'unknown'
        && typed.payload.failureDetail?.stage === 'runtime_settlement'
        && (
          settlementCode === 'run_settlement_not_persisted'
          || settlementCode === 'actor_settlement_not_persisted'
        )
      ) {
        renderRuntimeFailure(typed.payload.failureDetail);
      }
      return;
    }
    if (
      typed.type === 'run.failed'
      || typed.type === 'run.cancelled'
      || typed.type === 'run.interrupted'
    ) {
      renderRuntimeFailure(typed.payload.failureDetail);
    }
  },
);
await failureSub.ready;

const handle = await runtime.runs.start({
  sessionId,
  input: { type: 'text', text: 'Review this repository.' },
});
const result = await handle.result;
const status = await runtime.runs.get(handle.runId);
const diagnostics = await runtime.sessions.diagnostics({
  sessionId,
  runId: handle.runId,
});

if (result.phase !== 'completed') {
  renderRuntimeFailure(result.failureDetail);
}
// `status.failureDetail` and `diagnostics.run.failureDetail` are the equivalent
// status/support-bundle access paths; choose one observation path for rendering.
failureSub.close();
```

#### Field contract

| Field | Stability and use |
|---|---|
| `failureKind` | Bounded broad category for UI grouping and coarse policy. |
| `stage` | Failure boundary: `catalog`, `credential`, `request_build`, `transport`, `response_stream`, `runtime_control`, or `runtime_settlement`. This is separate from the Run lifecycle `stage`. |
| `providerErrorCode` | Stable KodaX-owned code. Use this field for programmatic handling. |
| `safeMessage` | Non-empty, at most 1,024 characters, and owned by KodaX. Safe for ordinary user display, but still treat it as text rather than markup. |
| `httpStatus` | Optional validated HTTP status. It is not sufficient by itself to identify a model or endpoint error. |
| `upstreamErrorCode` | Optional provider-controlled identifier. Useful for support only; not part of KodaX compatibility. |
| `requestId` | Optional bounded upstream request identifier for provider support. |
| `retryAfterMs` | Optional validated retry delay, capped at 24 hours. Absence does not imply immediate retry is safe. |
| `contextTokens` | Present for `context_capacity`; contains bounded non-negative `required` and `available` token counts for diagnostics and UI guidance. |

The stable classification is:

| `failureKind` | `stage` | Stable `providerErrorCode` values |
|---|---|---|
| `auth` | `credential` | `credential_unavailable`, `authentication_failed` |
| `rate_limit` | `transport` | `rate_limited` |
| `network` | `transport` | `network_error`, `tls_error`, `request_timeout` |
| `not_found` | `transport` | `model_not_found`, `endpoint_not_found`, `resource_not_found` |
| `unknown_provider` | `catalog` | `provider_not_registered` |
| `request` | `request_build` | `request_build_failed` |
| `upstream` | `transport` | `upstream_client_error`, `upstream_server_error` |
| `invalid_response` | `response_stream` | `protocol_mismatch`, `response_stream_error` |
| `cancelled` | `runtime_control` | `cancelled` |
| `provider_aborted` | `transport` | `cancelled` |
| `runtime_cleanup` | `runtime_settlement` | `runtime_settlement_failed` |
| `context_capacity` | `runtime_control` | `context_capacity_exceeded` |
| `provider` | `catalog`, `transport`, or `response_stream` | `catalog_error`, `provider_error` |

`providerErrorCode` intentionally describes the KodaX interpretation, while
`upstreamErrorCode` preserves a safe provider identifier when one exists. For
example, HTTP 401/403 maps to `authentication_failed`, 429 maps to
`rate_limited`, 5xx maps to `upstream_server_error`, and other 4xx maps to
`upstream_client_error`. A 404 becomes `model_not_found` or
`endpoint_not_found` only when the provider supplies a recognized precise code;
otherwise it remains `resource_not_found`. This prevents a generic status from
claiming certainty KodaX does not have. User cancellation and an isolated
provider-side abort share the stable `cancelled` code but remain distinguishable
by `failureKind` and `stage`.
Local context exhaustion is reported as `context_capacity` /
`runtime_control` / `context_capacity_exceeded`; when available,
`contextTokens.required` is the estimated complete request and
`contextTokens.available` is the physical model-window budget.

#### Security boundary

`safeMessage` comes from a fixed KodaX template and never copies an upstream
message or response body. Runtime never copies API keys, Authorization/Cookie
values, URL userinfo/query, request/response bodies, prompts, complete local
paths, raw header collections, stacks, or raw `Error` objects into
`failureDetail`. The only header-derived values are the documented allowlisted
request ID and retry facts. `upstreamErrorCode` and `requestId` accept only the
bounded identifier character set `[A-Za-z0-9_.:-]` (maximum 200 characters). If one of
those identifiers contains the run credential, a prompt of at least four
characters, or the value of a registered credential/sensitive-name environment
variable, Runtime omits the whole optional field. Runtime does not source
identifier values from prompts; the prompt comparison is an additional
coincidence/leak guard. Optional facts are also omitted when unavailable or
invalid; absence is part of the contract.

Keep unrestricted provider diagnostics inside a provider-owned, privileged
debug sink if your product explicitly offers one. Do not merge that sink back
into Runtime events, status, diagnostics, telemetry, or user-visible support
bundles.

#### Migration and compatibility

- Stop branching on `error.message`, terminal display text, broad
  `failureKind:'provider'`, or HTTP status alone. Branch on
  `providerErrorCode`, then use `stage`/`failureKind` for grouping.
- Render `safeMessage`; append only explicitly needed optional identifiers.
  Never reconstruct or expose a raw provider body from another channel.
- `failureDetail` is additive and optional. When connecting to an older SDK or
  daemon, treat absence as legacy/unclassified and keep the existing terminal
  phase/lifecycle handling. Do not replay `runs.start()` to obtain diagnostics.
- Preserve an unknown-code/default UI path at transport boundaries so a newer
  Runtime cannot turn a diagnostic extension into a failed host UI.

### Session-scoped live event ordering

Runtime event order is defined inside one Session, not across the Runtime.
Since v0.7.97 the event surface is a live in-process stream; the durable
journal, `events.replay()`, and the `{ sessionId, journalEpoch, seq }` cursor
were removed. Every event envelope is:

```ts
type RuntimeEventEnvelope = {
  id: string;
  seq: number; // per-Session in-process ordering hint; starts at 1
  time: string;
  sessionId: string;
  runId: string;
  turnId?: string;
  type: RuntimeEventType;
  payload: unknown;
};
```

`seq` is an ordering hint, not a durable cursor. It starts at `1` within one
Session, resets when that Session is deleted and recreated, and is not
comparable across restarts or between Sessions — do not persist it as a
resume point. Consumption is subscription-shaped and always scoped:

```ts
const sub = runtime.events.subscribe(
  { sessionId: session.id }, // runId optionally narrows to one Run
  (event) => renderLiveEvent(event),
);
await sub.ready; // daemon handshake; absent for local subscriptions
sub.close();
```

Remote event consumption reuses `session.observe` notifications: an
observation snapshot carries a `seq` high-water, every event with
`seq <= snapshot.seq` is already reflected in the snapshot, and live listener
events for that observation have strictly greater `seq`. Separate Sessions may
both contain `seq: 1`; that is intentional. Supplying both `sessionId` and
`runId` validates their ownership before the subscription is installed.
Deleting and recreating a Session invalidates outstanding observations with
reason `runtime_changed`; acquire a fresh observation instead of reusing a
stale projection or sequence number.

### Run options across the daemon boundary

`runs.start({ options })` is a DTO boundary in daemon form. Do not
pass process-local objects such as `extensionRuntime`, callbacks, `AbortSignal`,
LSP services, class instances, or cyclic structures. KodaX rejects them before
transport instead of silently dropping fields.

`events.beforeToolExecute` is an executable policy hook, not an observation
callback. It is preserved in embedded mode and rejected in daemon mode; install
the equivalent policy in the daemon owner instead. The KodaX REPL explicitly
marks and removes only its own legacy approval hook because Runtime-owned
permission brokering replaces that hook.

Use the runtime APIs for cross-boundary behavior:

- cancellation: `runtime.runs.abort(runId)`;
- output/progress: `runtime.events.subscribe(...)`;
- approval: `runtime.permissions.respond(...)`;
- session defaults: `runtime.sessions.updateSettings(...)`;
- config/MCP/extensions: configure or reload them in the Runtime owner.

Host-bound extensions or callbacks that cannot be represented as owner-loaded
module/config descriptors require inline embedded mode. There is no fallback to
executing those objects in the client process.

For daemon mode, extension and MCP ownership follows daemon configuration.
Configure extensions in the daemon profile and call
`runtime.catalog.reloadExtensions()` or the matching config service. A CLI
`--extension <path>` is intentionally rejected in daemon mode because that
process-local object cannot become part of a durable shared owner. Use
owner-readable config/module descriptors or inline mode for host-created
extension objects.

### Permissions across clients

Pending permission requests live in the runtime/daemon, not in one UI client. A
Space-style client can subscribe to permission events and answer a request
created by a REPL-style client.

```ts
const sub = runtime.events.subscribe(
  { sessionId: session.id, type: 'permission.requested' },
  (event) => {
  const payload = event.payload;
  if (!payload || typeof payload !== 'object' || typeof payload.id !== 'string') {
    return;
  }
  void runtime.permissions.respond(
    payload.id,
    { type: 'allow_once' },
    { runId: payload.runId },
  );
  },
);
await sub.ready;
```

Await `ready` before another client starts work that may request permission;
this creates an explicit cross-connection ordering boundary. Only the first
valid response wins. Wrong-run or stale responses are rejected.
Abort, runtime close, daemon stop, and timeout reject unresolved permission
requests so tool approval promises do not hang forever. Permission timeout is
a fail-closed `{ type: 'reject', cause: 'approval_timeout' }` decision.

Hosts that render approval UI should use the public lifecycle helper instead
of awaiting a dialog directly from an event listener:

```ts
import { handleRuntimePermissionRequest } from '@kodax-ai/kodax/runtime';

await handleRuntimePermissionRequest(runtime, request, async (pending, context) => {
  // Close the popup when context.signal aborts. Runtime timeout, cancellation,
  // or a response from another client can all win before this UI does.
  return showPermissionDialog(pending, { signal: context.signal });
});
```

`handleRuntimePermissionRequest()` subscribes before showing the prompt,
rechecks pending state, and makes Runtime resolution authoritative. A late UI
answer is ignored. Embedded AskUser callbacks receive the same optional third
argument, `{ signal }`; abort the visible prompt when it fires.

`createKodaXRuntime({ userInputTimeoutMs })` and daemon auto-start use an
independent AskUser deadline (300,000 ms by default). The value must be a
positive integer no greater than 2,147,483,647 and is validated before
embedded or daemon startup. The same bound applies to
`permissionTimeoutMs`, except that its existing value `0` disables the
permission timer. On expiry, the Runtime accepts only a model-supplied default that is
valid for the rendered options and selection bounds; otherwise it dismisses
the question. MCP reverse elicitation uses the same five-minute bounded UI
lifecycle and safely cancels a stalled prompt.

SDK clients that create a concrete request may pass `toolInput` and
`executionCwd` to `runtime.permissions.request(...)` in both embedded and
daemon mode. The Runtime removes raw `toolInput` before publishing the pending
request, derives the bounded/redacted preview from that concrete input,
canonicalizes it into a matcher, and returns only opaque `grantSuggestions`.
A caller-supplied `inputPreview` cannot override this trusted summary.
`projectRoot`, classifier signals, and other owner-only safety context are
deliberately not client request fields.

Grant administration is typed through `RuntimePermissionScope` and the
exported `RuntimePermissionMatcher` union (`exact-command`, `exact-path`, and
`exact-call`). These types are available from both the package root and
`@kodax-ai/kodax/runtime`; matcher construction remains Runtime-owned.
Legacy `allow_always.scope` responses remain accepted for 0.7.x clients, but
the Runtime narrows them to its concrete candidate and never persists the
client-provided coarse scope. Legacy persisted grants that lack a Runtime
matcher remain inspectable and revocable, but never authorize a concrete tool
call; the user must approve a fresh Runtime-issued exact suggestion.

### Config, catalogs, MCP, and Space-style admin APIs

Daemon-connected clients should not edit KodaX config files directly. Use the
runtime services instead:

```ts
await runtime.config.patch({ provider: 'zai-coding', model: 'glm-5.2' });
await runtime.config.reload();

await runtime.catalog.upsertCustomProvider({
  name: 'my-openai-compatible',
  protocol: 'openai',
  baseUrl: 'https://example.com/v1',
  apiKeyEnv: 'MY_LLM_API_KEY',
  model: 'my-model',
  // imageInput: true,  // uncomment when the endpoint is multimodal (vision)
});

await runtime.mcp.upsertServer('filesystem', {
  command: 'npx',
  args: ['-y', '@modelcontextprotocol/server-filesystem', process.cwd()],
});
await runtime.mcp.reloadServers();

const commands = await runtime.catalog.commands(process.cwd());
const skills = await runtime.catalog.skills({ projectRoot: process.cwd() });
```

`runtime.catalog.skills()` returns all enabled Skills. `userInvocable` is true
for every entry; `disableModelInvocation` tells the host whether the entry is
also model-visible. The legacy `userInvocableOnly` filter is accepted for wire
compatibility but no longer removes enabled Skills.

This is the intended path for KodaX Space, IDE adapters, and settings UIs:
session defaults go through `sessions.updateSettings()`, one-turn overrides go
through `runs.start({ options })`, and daemon/profile config goes through
`config`, `catalog`, and `mcp`.

### Context optimization and diagnostics

The runtime carries the Hermes-inspired context-efficiency plane from the coding
engine:

- small-window schema pruning hides non-core deferred tool schemas while keeping
  bridge discovery resident;
- tool-search/describe/call-style bridge semantics keep tools reachable;
- repo-intelligence schemas remain discoverable under pressure;
- context-aware tool result budgets and compaction pressure surface as bounded
  diagnostic events.

The v0.7.96 pull-style diagnostics RPCs (`context.budget.get`,
`tool.exposure.preview`, `provider.cache.diagnostics.get` and the
`runtime.diagnostics.latestContextBudget()` / `latestToolExposure()` /
`latestProviderCacheDiagnostic()` facade) were removed in v0.7.97. The
`capabilities.contextDiagnostics: true` client capability now only gates
delivery of diagnostic event notifications (`context.budget.snapshot`,
`tool.exposure.planned`, `provider.cache.diagnostics`, and
`context.compaction.skipped`) on the live event stream; consume them through
`runtime.events.subscribe(...)` or a `session.observe` snapshot. Diagnostic
payloads carry `contextId` and, for children, `parentContextId`. These
diagnostics are designed for status panels and debugging: budget snapshots
contain counts, and cache diagnostics contain hashes plus Provider-reported
usage; they do not contain raw prompt or sensitive tool input/output.

### Protocol schema and versioning

The runtime subpath also exports daemon protocol metadata for clients that need
schema-aware IPC validation:

```ts
import {
  KODAX_DAEMON_PROTOCOL,
  KODAX_DAEMON_PROTOCOL_VERSION,
  RUNTIME_DAEMON_PROTOCOL_SCHEMA,
  listRuntimeDaemonSchemaMethods,
} from '@kodax-ai/kodax/runtime';
```

The schema is additive within this patch line. Removing or changing required
fields requires a protocol version bump.

### v0.7.69 Runtime verification record

This subsection is the historical verification record for the original shared
Runtime delivery. The Worker-isolation gates it records validated the Worker
facade that v0.7.97 later removed; the current deployment shapes are inline
embedded and daemon only. Current 0.7.80 release gates and evidence live in
[`docs/release.md`](https://github.com/icetomoyo/KodaX/blob/main/docs/release.md#v0780-release-preparation).

The v0.7.69 release validation covers the runtime migration, the Worker
isolation follow-ups delivered ahead of their original v0.7.71/v0.7.72
planning slots, the v0.7.67 external-agent/session additions, the v0.7.68
experimental Memory Agent surface, and the v0.7.69 A2A/integration/shared-
daemon delivery:

- Node 20 and Node 22 post-review regression for process cleanup, lock
  ownership, frozen eval inputs, A2A transport, and the built-in manual;
- root `tsc --noEmit`, package builds, bundle builds, and all 12 public DTS
  entries on Node 20 and Node 22;
- runtime/daemon/SDK/ACP/REPL integration tests, including process-distinct SDK
  auto-start and multi-client sessions/permissions;
- the (since-removed) Worker Runtime's identity, service parity, hard close,
  capability requirements, and contradictory-option rejection;
- constructed-handler reverse tool RPC, abort bridging, CPU-loop termination,
  respawn, and revoke/dispose queue drainage;
- context/tool-exposure eval gate;
- embedded and hosted-daemon external-agent catalog/task parity, durable task
  recovery, policy/credential/artifact gates, and disabled-plane failure;
- exact session `surface` filtering plus opaque cursor continuation through the
  narrow `/session` API, embedded Runtime, and daemon transport;
- scoped zero-wait memory recall, read-only deliberate query, trace-only
  receipts, bounded episode review, governed consult-before-write promotion,
  and the self-contained `/experimental-memory` bundle/DTS surface;
- bidirectional A2A 1.0 discovery/call/serve, durable task replay, no-code
  configuration, local-Agent binding, exact Skill-script admission, SSRF/
  credential boundaries, and the self-contained `/a2a` bundle/DTS surface;
- split MCP/A2A/Extension configuration, lossless migration, canonical-template
  drift checks, last-known-good hot reload, draining, and restart-required
  classification;
- atomic shared-daemon observation/resync, durable operations and same-session
  ordering, settings/grant CAS, AskUser/permission transport, credential/Host
  Tool reverse bridges, owner fencing, restart outcomes, and process-distinct
  client/daemon smokes with credential-canary scans;
- a fresh `0.7.69` tarball consumer importing all 11 public subpaths, creating a
  session through the embedded Worker form (removed in v0.7.97), running the
  packaged CLI, and checking packaged DTS and sidecars; plus a Windows x64
  binary/version/sidecar smoke;
- external fresh npm consumer installation of the `0.7.67` tarball, proving
  the embedded Worker isolation contract (removed in v0.7.97) and a distinct
  daemon PID through the published subpath;
- Ubuntu Node 22 Unix-domain-socket daemon gate, including two clients sharing
  one runtime and cross-client permission resolution.

The portable manual gates remain in
`docs/test-guides/FEATURE_255_v0.7.66_TEST_GUIDE.md`,
`FEATURE_256_v0.7.71_TEST_GUIDE.md`, and
`FEATURE_257_v0.7.72_TEST_GUIDE.md` for release-machine verification; the latter
two filenames retain their original planning slots while their content records
the v0.7.66 delivery. v0.7.67 adds
`FEATURE_258_v0.7.67_TEST_GUIDE.md`, `FEATURE_259_v0.7.67_TEST_GUIDE.md`, and
`FEATURE_261_v0.7.67_TEST_GUIDE.md`; v0.7.69 adds
`FEATURE_267_v0.7.69_TEST_GUIDE.md`, `FEATURE_268_v0.7.69_TEST_GUIDE.md`, and
`FEATURE_269_v0.7.69_TEST_GUIDE.md`. The earlier release-preparation Actions
run is not reused after the severe-fix review. Fresh GitHub Actions run
`29385073422` passes the Node 20/22 build, bundle, DTS, and full-test matrix plus
the Node 22 Unix-domain-socket daemon gate. npm publication remains a
maintainer-owned manual step.

---

## 18. External-agent executor plane (FEATURE_258, v0.7.67)

FEATURE_258 lets an SDK host register remote agents without teaching the coding
runtime a specific A2A, MCP, or HTTP client. The public contracts live in
`@kodax-ai/kodax/agent`; the host-facing catalog and task services live on
`@kodax-ai/kodax/runtime`.

### Ownership rule

An `AgentExecutorFactory` contains functions, so it cannot cross a daemon DTO
boundary. Install factories where the Runtime owner executes:

| Desired owner | Supported construction |
|---|---|
| Private in-process owner | `createKodaXRuntime({ mode: 'embedded', externalAgents })` |
| New locally hosted daemon owner | `createKodaXRuntime({ mode: 'daemon', profile: '<unique>', externalAgents })` |
| Existing daemon | Configure its owner, then attach with `connectKodaXRuntime({ requirements: { externalAgents: true } })`; a client cannot inject factories. |
| Built-in configured A2A plane | Wire it in the owner: `createConfiguredA2ARuntimeIntegration({ configHome })` → pass `runtimeOptions` as `externalAgents` (the KodaX CLI does this for its embedded sessions and the daemon Host it launches; an SDK-created runtime never reads `integrations/a2a.json` on its own). The former `worker: { configuredA2A: true }` opt-in was removed with the Worker facade in v0.7.97. |

When `mode: 'daemon'` and `externalAgents` are supplied, the caller must win a
new in-process daemon lease. KodaX rejects an already-running profile instead of
silently replacing its executor configuration. Closing that owner facade shuts
down the host it created; closing an ordinary attached client only detaches.

### Minimal owner and task flow

The reference executor below is a contract/conformance adapter. Replace it with
your own `AgentExecutorFactory` for a real remote protocol.

```ts
import {
  createReferenceAgentExecutorFactory,
  type ExternalAgentRegistration,
} from '@kodax-ai/kodax/agent';
import { createKodaXRuntime } from '@kodax-ai/kodax/runtime';

const runtime = await createKodaXRuntime({
  mode: 'embedded',
  externalAgents: {
    factories: [createReferenceAgentExecutorFactory({
      executorId: 'example-http',
      protocol: 'http',
    })],
    policy: ({ registration, query }) => ({
      allowed: registration.enabled && query.readOnly === true,
      reasons: query.readOnly === true ? [] : ['This host allows read-only dispatch only.'],
    }),
    defaultContext: { actorId: 'desktop-host' },
  },
});

const registration: ExternalAgentRegistration = {
  agentId: 'external:reviewer',
  displayName: 'Remote Reviewer',
  enabled: true,
  executorId: 'example-http',
  protocol: 'http',
  configurationRevision: 'reviewer-config-v1',
  endpointIdentityHash: 'sha256:replace-with-stable-endpoint-identity',
  skills: ['code-review'],
  inputModalities: ['text'],
  outputModalities: ['text'],
  capabilities: {
    streaming: 'supported',
    durableTasks: 'supported',
    inputRequired: 'conditional',
    cancellation: 'supported',
    artifacts: 'unsupported',
  },
  effects: { remote: 'read', workspace: 'proposal' },
  maxConcurrency: 1,
};

try {
  await runtime.admin.agentRegistrations.upsert(registration);

  const query = {
    actorId: 'desktop-host',
    requiredSkills: ['code-review'],
    readOnly: true,
  } as const;
  const available = await runtime.agents.listDispatchable(query);
  const preflight = await runtime.agents.preflight({
    agentId: 'external:reviewer',
    query,
    expectedConfigurationRevision: registration.configurationRevision,
  });
  if (!preflight.ok) throw new Error(preflight.reasons.join('; '));

  const started = await runtime.agentTasks.start({
    agentId: 'external:reviewer',
    objective: 'Review the supplied immutable patch and return cited findings.',
    context: { actorId: 'desktop-host', runId: 'host-run-42' },
    readOnly: true,
    requiredSkills: ['code-review'],
    expectedConfigurationRevision: registration.configurationRevision,
  });
  const terminal = await runtime.agentTasks.wait(started.taskId, 60_000);
  console.log(available, terminal.state, terminal.output, terminal.usage);
} finally {
  await runtime.close();
}
```

`runtime.agents.enabled` is the cheap external-plane feature check. If it is
false, catalog queries can still return built-in local agents but no external
agents; registration and task lists are empty, while point reads and mutations
fail clearly. Set
`requirements.externalAgents: true` when absence must abort connection.

### Service reference

| Surface | Methods | Contract |
|---|---|---|
| `runtime.admin.agentRegistrations` | `list`, `upsert`, `setEnabled`, `remove` | Durable owner configuration. `setEnabled` preserves the complete captured executor registration while changing admission. Mutations accept both `expectedConfigurationRevision` and `expectedManagementOwner`; `setEnabled` can also atomically `claimOwner` on an unowned registration and rejects another owner. List results expose `managementOwner` and `credentialConfigured`, never a credential value. The same contract is carried across the daemon transport. With no plane, `list()` is empty and mutations fail clearly. |
| `runtime.agents` | `enabled`, `listDispatchable`, `describe`, `preflight` | Applies health, capability, effect, concurrency, credential-presence, configuration-revision, and host-policy checks before dispatch. |
| `runtime.agentTasks` | `start`, `list`, `get`, `events`, `wait`, `sendInput`, `cancel`, `reconcile` | Durable snapshots and append-only events for external tasks. The task keeps the immutable registration/executor binding captured at start. |

`agentTasks.events(taskId, cursor)` uses the last seen numeric event `seq` as its
cursor and returns events with a greater sequence. `wait()` resolves only at a
terminal task state and rejects on a positive `timeoutMs` expiry. `sendInput()`
is valid only while the task reports `input-required` or `auth-required`.
`reconcile()` asks the bound executor for authoritative remote state after an
owner restart or uncertain failure.

For external tasks, the built-in stores persist an internal full registration
snapshot before the public task ledger. It is keyed by Agent ID and revision,
is never returned by task or daemon APIs, and lets an admitted task keep using
its original executor route after registration update/removal and Runtime
restart. The internal form fixes `enabled: true` and omits management ownership
and health diagnostics. The task's public route summary is validated against that internal
snapshot before recovery. Terminal task state is durable before the last
unreferenced snapshot is removed; startup cleans crash-window orphans.

Custom `AgentExecutorPlaneStore` implementations should implement
`loadTaskRegistrationSnapshots()` and `saveTaskRegistrationSnapshots()` as a
pair and give one Runtime exclusive write ownership of that store. Omitting
both remains compatible, but restart recovery then succeeds only while the
exact current registration still exists. Store only non-secret executor config
or secret references in `executorConfig`/`credentialRef`; the broker resolves
the current referenced credential just in time, so removing a registration is
not equivalent to revoking that credential at its issuer.

The owner plane has a terminal close contract. Closing it rejects every pending
`wait()` (including a wait without `timeoutMs`), disposes its executor instances,
and makes subsequent registration, catalog, preflight, and task calls reject
with `Agent executor plane is closed.` One overall deadline covers admitted
work plus executor disposal: the default is 30 seconds, and direct
`createAgentExecutorPlane()` hosts may supply a positive finite
`closeTimeoutMs`. A timeout rejects visibly even though already-admitted cleanup
may finish in the background. Repeated `close()` calls are safe. SDK hosts
should stop accepting work before closing the owner and must not retain a plane
service as a reusable handle after Runtime shutdown.

Restricted Workflow scripts use the same route as direct SDK calls. Both
`wf.spawnAgent()` and `wf.runAgent()` validate and forward
`target: { agentId, expectedConfigurationRevision? }`; `phase` is forwarded as
well. A blank ID or revision is rejected at the script boundary instead of
silently falling back to the native child backend.

### Credential, artifact, and failure boundaries

- Put only a `credentialRef` in a registration. Resolve secret material through
  `AgentCredentialBroker.withCredential()`; do not place tokens in
  `executorConfig`, events, diagnostics, or task output.
- Remote artifacts are denied by default. Supply `artifactPolicy` to authorize
  each artifact before it materializes in the host boundary.
- External agents may declare workspace effect `none` or `proposal`; direct
  workspace mutation is intentionally not a valid external registration.
- Use `expectedConfigurationRevision` for dispatch. For registration mutations,
  compare both it and `expectedManagementOwner` so a same-revision ownership
  change cannot be overwritten from an earlier catalog read. Config managers
  should set a stable `managementOwner`; they may atomically claim an unowned
  legacy registration while disabling it, but must not mutate a registration
  owned by another manager.
- Treat `configurationRevision` as the stable identity of immutable execution
  content, not as a small counter. The same content may deterministically reuse
  the same revision across remove/re-add or Runtime restart, but different
  endpoint, protocol, executor/auth config, capabilities, effects, Skills,
  modalities, or resource limits must never reuse it. Built-in A2A
  configuration derives it from content.
- A remote start followed by uncertain local persistence is recorded as
  `unknown` with its executor reference preserved; reconcile it rather than
  blindly starting a duplicate. Stable idempotency keys protect retries.
- The durable plane records provider-reported usage when available. It never
  invents missing token or cost fields.

For a production adapter, implement `preflight?`, `start`, `events`, `get`,
`sendInput`, `cancel`, `reconcile`, and `dispose` on `AgentExecutor`. The factory
receives `withCredential()` and `authorizeArtifact()` callbacks so protocol code
cannot bypass the host's secret/artifact policies.

---

## 19. Session surface filtering and cursor pagination (FEATURE_261, v0.7.67)

The narrow session SDK and Runtime facade now share the same listing semantics:
`surface` is an exact filter applied before `limit`, and `cursor` is an opaque
continuation token carried by each returned summary.

### Narrow `/session` API

```ts
import { listSessions, type SessionSummary } from '@kodax-ai/kodax/session';

const all: SessionSummary[] = [];
let cursor: string | undefined;
do {
  const page = await listSessions({
    scope: 'user',
    surface: 'partner',
    limit: 50,
    ...(cursor ? { cursor } : {}),
  });
  all.push(...page);
  cursor = page.length === 50 ? page.at(-1)?.cursor : undefined;
} while (cursor);
```

### Embedded/daemon Runtime API

```ts
const first = await runtime.sessions.list({ surface: 'acp', limit: 25 });
const nextCursor = first.at(-1)?.cursor;
const second = nextCursor
  ? await runtime.sessions.list({ surface: 'acp', limit: 25, cursor: nextCursor })
  : [];
```

The filter also composes with `projectRoot`, `scope`, `includeArchived`, `before`,
and `tag`. Treat cursors as opaque: do not parse them, compare them to session
IDs, or manufacture them. An invalid cursor produces an empty page on the narrow
session API. A page shorter than the requested limit is terminal; a full page
may continue with its last item's cursor.

The interactive `kodax -r` picker is a consumer of these session semantics, not
a separate SDK API. Headless hosts should build their own UI on `listSessions()`
or `runtime.sessions.list()` and resume by the selected full session ID.

---

## 20. Cost-disciplined workflow routing and telemetry (FEATURE_259, v0.7.67)

FEATURE_259 adds a public cost/quality contract without making the authoring LLM
choose provider-specific model names. The SDK host maps semantic tiers to routes;
workflow/child briefs request intent.

### Configure tiers and bounded concurrency

```ts
import { join } from 'node:path';
import { runKodaX } from '@kodax-ai/kodax/coding';

const workflowRunsBaseDir = join(process.cwd(), '.kodax-host', 'workflow-runs');
const result = await runKodaX({
  provider: 'zai-coding',
  model: 'glm-5.2',
  agentMode: 'amaw',
  workflowRunsBaseDir,
  modelTiers: {
    fast: { provider: 'deepseek', model: 'deepseek-v4-flash' },
    deep: { provider: 'zai-coding', model: 'glm-5.2' },
  },
  workflow: { maxConcurrency: 3 },
  events: {
    onWorkflowAgentDigest: ({ runId, event }) => {
      if (event.type === 'agent_completed' || event.type === 'agent_unverified'
        || event.type === 'agent_failed') {
        console.log(runId, event.data);
      }
    },
  },
}, 'Review this change using scoped evidence packets.');

console.log(result.lastText);
```

Tier rules are deliberately small:

- `fast`: mechanical read-only lookup. A write child is ineligible and safely
  inherits the parent route.
- `balanced`: ordinary implementation/investigation/review; uses the parent
  route, so there is no separate `balanced` mapping.
- `deep`: architecture, adversarial verification, severity calibration, and
  final synthesis.
- An unconfigured or selector-shadowed tier inherits the appropriate explicit,
  specialist, or parent route and records why; it does not silently claim the
  requested route was applied.

The workflow authoring contract also supports `scopeSummary`, `constraints`,
`evidenceRefs`, `verification`, `readOnly`, `outputSchema`, and `terseResult`.
Use those fields to transfer a compact immutable packet instead of asking every
child to rediscover the same repository context.

### Live route facts

Terminal `WorkflowEvent.data` may include `requestedTier`, `tierOutcome`,
`providerSource`, `modelSource`, initial/final provider and model,
`fallbackReason`, `iterations`, `durationMs`, `usage`, and `digestUsage`.
Treat absent fields as unknown. In particular, KodaX does not fabricate usage
for external executors that did not report it.

Direct child-dispatch consumers receive the typed `KodaXChildAgentResult.routeFacts`
surface, including resolved effort and input/cache-read/output/digest token
breakdown when known. Inline workflow consumers can subscribe to the raw
`onWorkflowAgentDigest` event as above; GUI progress remains available through
`onWorkflowProcessEvent` / `runtime.workflows`.

### Durable efficiency report

When `workflowRunsBaseDir` is supplied, every terminal workflow writes:

```text
<workflowRunsBaseDir>/<runId>/run.json
<workflowRunsBaseDir>/<runId>/events.jsonl
<workflowRunsBaseDir>/<runId>/artifacts/*.json
```

`run.json.efficiencyReport` includes:

- total/input/cache-read/output/digest tokens and wall-clock duration;
- total starts, child turns, starts by `role/tier`, and primary-review starts;
- duplicate primary packet reads plus verification/synthesis packet reads;
- review/fix/re-review waves and structured review quality-gate outcomes;
- `tokenCoverage.ok` plus missing local task IDs;
- `excludedExternalTaskIds` for external tasks whose executor reported no usage.

Do not interpret `totalModelTokens: 0` as free execution unless
`tokenCoverage.ok` is true and the relevant external task IDs are not excluded.
The report is an audit/optimization artifact; correctness still comes from the
workflow's structured findings, verification results, and quality gates.

---

## 21. Experimental governed memory — `/experimental-memory` (FEATURE_260 + FEATURE_275 + FEATURE_292, v0.7.68–v0.7.85)

KodaX has one durable memory plane: the F228 Memory Control Plane. FEATURE_260
adds a thin, opt-in agent/session API over that plane; it does not add a second
database, filesystem memory actions, a resident memory specialist, or online
self-modification.

Top-level `runKodaX()` coding runs wire this lifecycle automatically. They build
an exact-scoped memory pack at session start, keep passive recall off the
blocking hot path, expose `memory_recall` only when the memory session starts,
record bounded observations/outcomes, and close the session at the run boundary.
Use the direct SDK below when a custom host needs to own those boundaries.

### Minimal direct session

```ts
import { createMemoryControlPlane } from '@kodax-ai/kodax/agent';
import { createMemoryAgent } from '@kodax-ai/kodax/experimental-memory';

const identity = {
  tenantId: 'tenant:acme',
  workspaceId: 'workspace:desktop',
  userId: 'user:42',
  agentId: 'agent:reviewer',
  projectId: 'project:kodax',
  sessionId: 'session:20260712',
};

const controlPlane = createMemoryControlPlane({
  cwd: process.cwd(),
  identity,
  projectDocs: [],
  discoverSkills: false,
});
const memory = createMemoryAgent({ controlPlane });
// `memory` is a MemoryManagementAgent because this controller exposes the
// additive management capability. A legacy MemoryController returns MemoryAgent.
const remembered = await memory.remember({
  operation: 'remember',
  statement: 'Run npm run build before this project is released.',
  claimKind: 'procedure',
  claimKey: 'project.procedure.release-build',
  evidenceRef: 'host:user-request:42',
});
const accepted = await memory.list();
if (accepted[0] !== undefined) {
  await memory.forget(accepted[0].handle, accepted[0].storageFingerprint);
}
const session = await memory.startSession({
  identity,
  objective: 'Review the runtime shutdown change',
});

const immediate = session.recall({
  decisionRevision: 'decision:1',
  objective: 'Review the runtime shutdown change',
  decisionContext: 'Choosing the first verification step',
  decisionIntent: 'runtime shutdown regression',
  throughSequence: 0,
});
const deliberate = await session.query({
  decisionRevision: 'decision:2',
  need: 'What uncommon daemon cleanup failure happened before?',
  throughSequence: 0,
});

await session.complete({
  status: 'succeeded',
  summary: 'Shutdown state replacement verified',
  evidence: [],
});
await session.close();
```

`recall()` is synchronous and exact. `query()` is deliberate and read-only; one
distinct query is admitted per decision epoch, and the result is bounded to at
most three prompt-safe hints and 512 estimated tokens. `undefined` means there
is no governed reminder to inject.

`list()`, `remember()`, and `forget()` are the direct host equivalents of the
conversation-first Memory surface added by FEATURE_292. `remember()` reuses the
same preview/fingerprint/applicability/apply controller: a safe authoritative
host request returns `remembered`, `updated`, or `already_known`. Ambiguous or
broad input returns `needs_clarification`; claim-key conflicts return
`needs_review` plus a durable proposal ID; restricted or secret input is
`rejected` without persistence. The host must supply its own durable evidence
reference and must not present inferred model text as user authority. The base
`MemoryAgent` and `MemoryController` interfaces remain source-compatible. The
overload returns `MemoryManagementAgent` only when the supplied controller
implements `MemoryManagementController`; legacy custom controllers receive the
base `MemoryAgent` type and never get methods that can only fail at runtime.

### Sparse foreground intervention (FEATURE_275, v0.7.77)

`MemorySession.intervene()` replaces the old timing-ineffective semantic
prefetch. It is awaited only after `tool_failure`, `verification_failure`, or a
durably committed `context_compacted` event, then supplies at most three
prompt-safe, low-authority evidence items to the next Action-LLM request. The
candidate set is rebuilt from current objective/open todos, recent governed
observations, and a fresh F228 pack. Exact selection is deterministic; stale,
unknown, malformed, timed-out, cancelled, or failed semantic results are
discarded without blocking the coding run.

Top-level coding runs wire the deterministic path automatically and make zero
selector calls by default. An inline host that deliberately wants semantic
selection can provide the coding-owned forced-tool runner:

```ts
import {
  createCodingMemoryInterventionRunner,
  runKodaX,
} from '@kodax-ai/kodax/coding';
import { resolveProvider } from '@kodax-ai/kodax/llm';

const memoryRecallRunner = createCodingMemoryInterventionRunner({
  provider: resolveProvider('zhipu-coding'),
  model: 'glm-5.2',
});

await runKodaX(
  {
    provider: 'zhipu-coding',
    model: 'glm-5.2',
    memoryRecallRunner,
  },
  'Finish the repository migration and verify it.',
);
```

`memoryRecallRunner` is a process-local function binding. Daemon DTO
options reject it instead of silently dropping it; configure the binding
inside the Runtime owner or keep this run inline. The selector can return only
exact IDs from the closed offered set and is capped at three calls per memory
Session.

### Evidence, tracing, and persistence boundaries

- Recalled content is low-authority evidence. Current repository/config/runtime
  facts must still come from current tools or host state.
- `observe()` accepts monotonic, evidence-linked observations and rejects secret
  material. `rewind()` removes observations after a sequence boundary.
- `complete()` can emit an Outcome Digest through `persistOutcomeDigest` and run
  bounded episode review through `reviewEpisode`; cancellation creates neither.
- `onTrace` receives policy-versioned `MemoryDecisionReceipt` metadata that links
  offered `candidateIds`, validated `selectedCandidateIds`, exposed
  `injectedEvidenceRefs`, triggers, and later outcome influence. Receipts are
  trace-only and contain no hidden reasoning; exposure is not proof of
  causality.
- Durable memory mutation remains owned by F228's
  proposal/preview/fingerprint/apply flow. Conversation is the normal product
  surface; `/memory` is the advanced CLI escape hatch. Direct file/shell writes
  to managed memory roots are denied, and `MEMORY.md` is a derived projection.
- Identity/applicability matching is exact and fail-closed. Hosts should supply
  stable tenant/workspace/user/agent/project/session identifiers and must not put
  credentials into those identifiers.

The subpath is experimental and ESM-only. Treat its exported types as opt-in
v0.7.x contracts; keep persistence and product policy behind your own adapter.

---

## 22. Bidirectional A2A 1.0 — `/a2a` (FEATURE_267, v0.7.69)

`@kodax-ai/kodax/a2a` is the protocol edge for the A2A 1.0 JSON-RPC/SSE
profile. It composes the protocol-neutral F258 executor plane with the Runtime
facade; `/agent` and `/coding` remain free of A2A wire types and dependencies.

### Call an A2A Agent through F258

Discovery is an explicit host action. The URL must match `allowedOrigins`, and
the default safe transport pins the validated DNS address for each connection
and independently revalidates redirects, rejects public plain HTTP, bounds
time/body/redirects, and strips authorization on a cross-origin redirect. A
custom `fetch` option is a trusted transport override: the embedder then owns
equivalent DNS-to-connection binding in that transport or proxy.

The selected interface must remain on the Card's trusted origin. KodaX parses
typed Card-level and Skill-level security declarations: requirement objects are
alternatives (OR), every scheme inside one object is conjunctive (AND), and an
empty requirement is anonymous. A configured credential is used only when one
complete requirement is satisfiable; protected Skills that the configured
profile cannot satisfy are not advertised to the Runtime catalog.

The built-in profiles are HTTP Bearer and OAuth 2.0 Client Credentials. The
OAuth profile pins the Card scheme, issuer, exact token endpoint, client ID,
secret reference, scopes, optional RFC 8707 resource, and client authentication
method. The external Authorization Server—not the Agent and not KodaX—issues
the access token. KodaX resolves the client secret only for refresh, keeps an
expiring token in process memory, coalesces refreshes, and retries one RPC once
with a fresh token after `401`. Card, Agent RPC, and token endpoints remain
separate safe-fetch trust boundaries, so a remote Agent cannot redirect a task
payload to the token origin. API key, Basic, interactive OAuth, OIDC, mTLS, and
multi-scheme AND requirements fail explicitly in the built-in client.

```ts
import {
  createA2AAgentExecutorFactory,
  discoverA2ARegistration,
} from '@kodax-ai/kodax/a2a';
import { createKodaXRuntime } from '@kodax-ai/kodax/runtime';

const client = {
  networkPolicy: {
    // Card/RPC and OAuth token endpoints are separate trust boundaries.
    allowedOrigins: ['https://reviewer.example', 'https://identity.example'],
    allowPrivateAddresses: false,
    requestTimeoutMs: 10_000,
    maxResponseBytes: 1_048_576,
    maxRedirects: 2,
  },
  pollIntervalMs: 500,
} as const;

const discovered = await discoverA2ARegistration({
  agentId: 'external:a2a-reviewer',
  agentCardUrl: 'https://reviewer.example/.well-known/agent-card.json',
  credentialRef: 'a2a/reviewer',
  effects: { remote: 'read' },
}, client);

const runtime = await createKodaXRuntime({
  mode: 'embedded',
  externalAgents: {
    factories: [createA2AAgentExecutorFactory(client)],
    credentialBroker: {
      async withCredential(ref, use) {
        const value = ref === 'a2a/reviewer'
          ? process.env.A2A_REVIEWER_TOKEN
          : ref === 'a2a/reviewer-client-secret'
            ? process.env.A2A_REVIEWER_CLIENT_SECRET
            : undefined;
        if (!value) throw new Error(`Missing credential for reference: ${ref}.`);
        return use(value);
      },
    },
    policy: ({ registration }) => ({ allowed: registration.effects.remote === 'read' }),
    defaultContext: { actorId: 'a2a-host' },
  },
});

await runtime.admin.agentRegistrations.upsert(discovered.registration);
const started = await runtime.agentTasks.start({
  agentId: discovered.registration.agentId,
  objective: 'Review this change and return cited findings.',
  context: { actorId: 'a2a-host' },
  readOnly: true,
  expectedConfigurationRevision: discovered.registration.configurationRevision,
});
const terminal = await runtime.agentTasks.wait(started.taskId, 60_000);
```

For OAuth, replace the legacy `credentialRef` input with the structured form;
the same F258 `credentialBroker` must resolve `clientSecretRef`. The shared
network policy must admit both origins, while each Card, RPC, and token request
is still narrowed to its own exact origin:

```ts
const discovered = await discoverA2ARegistration({
  agentId: 'external:a2a-reviewer',
  agentCardUrl: 'https://reviewer.example/.well-known/agent-card.json',
  authentication: {
    type: 'oauth2-client-credentials',
    scheme: 'enterprise-oauth',
    issuer: 'https://identity.example/',
    tokenUrl: 'https://identity.example/oauth/token',
    clientId: 'kodax-reviewer',
    clientSecretRef: 'a2a/reviewer-client-secret',
    scopes: ['a2a.invoke'],
    resource: 'https://reviewer.example/',
    clientAuthentication: 'client-secret-basic',
  },
  effects: { remote: 'read' },
}, client);
```

The executor supports durable task start/get, input continuation, cancel,
reconcile, SSE events, and polling fallback. An ambiguous start is not retried
automatically. A `credentialRef` is resolved just in time by the F258 broker;
the registration, task store, and diagnostics never contain the credential.
Authenticated SSE uses that same broker. JSON-RPC ID/version and task/context
correlation are validated before an event is accepted; if a stream ends
normally before a terminal snapshot, the executor resumes bounded polling.
Streamed `artifactUpdate` chunks are accumulated by artifact ID according to
`append`, and direct Message file Parts are preserved as authorized artifact
references.

### Built-in configured path (no host code)

The CLI product path stores one user document at
`~/.kodax/integrations/a2a.json` and uses the same F258 plane:

```bash
kodax a2a add reviewer https://reviewer.example/.well-known/agent-card.json \
  --credential-env A2A_REVIEWER_TOKEN --effect read
kodax a2a test reviewer
kodax a2a call reviewer "Review this document"
```

Private-address access and plaintext HTTP beyond exact loopback are independent
persisted permissions. Both default to false; private HTTP requires both:

```bash
kodax a2a add intranet http://10.20.30.40/.well-known/agent-card.json \
  --allow-private --allow-insecure-http --effect read
```

Private HTTPS requires only `--allow-private`. Public HTTP requires only
`--allow-insecure-http`, but TLS remains the recommended deployment. The flags
are persisted under the Agent's `network` block and are honored by Card
discovery, interface execution, Runtime registration, and task execution.
Private-address permission also applies to HTTPS OAuth endpoints, but OAuth
token endpoints deliberately retain the stricter HTTPS-or-exact-loopback
protocol rule; Agent-transport plaintext authorization does not weaken OAuth.
`a2a test` and `a2a call` also accept the flags as one-shot overrides.

The no-code OAuth path stores only the environment-variable name for the client
secret. It can be staged disabled and hot-activated later:

```bash
export A2A_REVIEWER_CLIENT_SECRET='provisioned-out-of-band'
# PowerShell: $env:A2A_REVIEWER_CLIENT_SECRET='provisioned-out-of-band'
# PowerShell: use one line or replace each trailing \ with a backtick.
kodax a2a add reviewer https://reviewer.example/.well-known/agent-card.json \
  --disabled --effect read --oauth-scheme enterprise-oauth \
  --oauth-issuer https://identity.example/ \
  --oauth-token-url https://identity.example/oauth/token \
  --oauth-client-id kodax-reviewer \
  --oauth-client-secret-env A2A_REVIEWER_CLIENT_SECRET \
  --oauth-scope a2a.invoke --oauth-resource https://reviewer.example/
kodax a2a enable reviewer
kodax a2a disable reviewer
```

Embedded CLI Runtimes and the user-owned daemon automatically reconcile these
entries as `external:<name>`. Discovery/update failure retains that entry's
last-known-good registration; another entry can still update. The environment
broker resolves `credentialEnv` only at call time. Automatic Runtime
registration accepts public HTTPS and exact loopback targets; private-address
and non-loopback plaintext access require their independent persisted operator
permissions.

`enabled` is desired state in `a2a.json`, not a fabricated cross-process live
flag. `a2a list` reports configured entries and that desired state. The owning
Runtime's `admin.agentRegistrations.list()` is authoritative for applied
registrations. Automatic reconciliation handles disables/removals first,
skips unchanged peers, performs no Card or token request for disabled entries,
and rediscovers before re-enable. Once the owning Runtime observes and applies
the revision, disable blocks all new starts, including an explicit
`external:<name>` target, but does not cancel or break an already admitted task.
The CLI mutation returning is not cross-process acknowledgement. A failed
activation remains retryable through the owning
`ConfiguredA2ARuntimeHandle.reload()` even when the disk revision is unchanged;
the passive `kodax integrations reload` command validates only its own process.

`kodax a2a test` performs Card discovery and security planning only. It never
requests an OAuth access token; token acquisition starts at `a2a call` or the
first Runtime dispatch.

Inbound publication is also no-code:

```bash
export KODAX_A2A_TOKEN='replace-with-a-long-random-token'
# PowerShell: $env:KODAX_A2A_TOKEN='replace-with-a-long-random-token'
kodax a2a expose                    # Runtime default Agent
kodax a2a expose document-agent     # ~/.kodax/agents/document-agent.md
kodax a2a serve --port 8765
```

The fixed token above is the compatibility profile. For dynamic production
tokens, configure KodaX as an OAuth Resource Server and point it at an external
issuer:

```bash
kodax a2a expose document-agent --auth oauth2-jwt \
  --oauth-scheme enterprise-oauth \
  --oauth-issuer https://identity.example/ \
  --oauth-audience https://kodax.example/a2a \
  --oauth-jwks-url https://identity.example/.well-known/jwks.json \
  --oauth-token-url https://identity.example/oauth/token \
  --oauth-metadata-url https://identity.example/.well-known/oauth-authorization-server \
  --required-scope a2a.invoke
kodax a2a serve --port 8765
```

The Authorization Server authenticates clients, provisions client IDs/secrets,
issues/rotates/revokes tokens and, for JWT access tokens, signs them and
publishes metadata/JWKS. The calling A2A
client obtains a token out of band or with Client Credentials and sends it in
the Bearer header. KodaX validates JWT type, asymmetric signature, issuer,
audience, lifetime, subject, and required scopes before task lookup, then maps
`sub` to the A2A principal. Missing/invalid credentials return `401`; a valid
token without the required scope returns `403 insufficient_scope`. KodaX does
not hold the issuer signing key or expose token, refresh, client-registration,
login, or consent endpoints. Opaque-token introspection and mTLS deployments
must use a host authentication adapter or reverse proxy. Offline JWT/JWKS
validation also cannot observe immediate per-token revocation: use short access
token lifetimes, signing-key rotation, or an introspecting proxy/adapter when
that property is required.

#### Upgrade retained pre-realm tasks

Realm-aware task ownership intentionally has no normal-request legacy fallback:
an authority switch must never adopt tasks merely because it reuses a subject.
If a v0.7.70 task store must remain addressable after upgrading, stop the A2A
server and first inspect an exact-owner migration plan:

```bash
kodax a2a migrate-tasks
kodax a2a migrate-tasks --apply --confirm-server-stopped

# OAuth identity is token-specific, so provide the known historical subject.
kodax a2a migrate-tasks --subject trusted-orchestrator
```

The configured Bearer profile supplies its fixed `principalId`; OAuth requires
`--subject`. Dry-run does not rewrite `tasks.json`. Apply rekeys only exact
matches, preserves unmatched records, and refuses a live task-store owner.
Custom SDK hosts can plan multiple known owners without exposing raw tokens:

```ts
import { migrateA2ALegacyTaskOwners } from '@kodax-ai/kodax/a2a';

const mappings = [{
  securityRealm: 'oauth2-jwt:https://identity.example/',
  subject: 'trusted-orchestrator',
}] as const;
const plan = migrateA2ALegacyTaskOwners({
  dataDir: '/var/lib/kodax/a2a', mappings, apply: false,
});

// After the host/operator verifies the plan:
if (plan.matchedLegacyTaskCount > 0) {
  migrateA2ALegacyTaskOwners({
    dataDir: '/var/lib/kodax/a2a', mappings, apply: true,
  });
}
```

The SDK also accepts `tenant` when a custom authentication adapter historically
returned one. Two mappings that claim the same legacy owner for different
realms are ambiguous and rejected; split or guessed ownership is never applied.

`a2a serve` resolves its Runtime provider in this order: explicit CLI option,
environment, core configuration, then the built-in default. Provider-compatible
model selection follows the normal hosted Runtime rule. A selected Markdown
Agent may declare its own validated `provider`; remote A2A input cannot choose
or override provider, model, reasoning, profile, workspace, or tools.

`expose` validates a named user Markdown Agent before writing its reference.
`serve` loads configured MCP and Extensions before it resolves the execution
binding or opens a socket. Native workspace read tools are admitted by
workspace access; writes, narrow Extension Tools, MCP capabilities, subagents,
and isolated Skill scripts require their corresponding exact `toolPolicy`
authority. Internal Skills come from `~/.kodax/skills`, `~/.agents/skills`,
plugins, and built-ins; public Agent Card skills are a separate explicit
projection and never reveal the private Skill inventory.

The running server pins Agent, Skill, workspace, tool registration, process and
store revisions. Card/auth/limits can hot reload; execution-authority changes
require an explicit restart. Managed contexts live below
  `~/kodax_a2a_server_workspace/<runtime-profile>/contexts/<context-key>/`. Exact Skill scripts require
`process: isolated`, an admitted `scripts/...` path, and a passing
`kodax sandbox doctor`; KodaX never falls back to an unsandboxed shell. On
 current native protocol 10, this isolated Skill Script route is POSIX-only.
Windows is unavailable because the route requires per-command `denyRead`, which
the Windows `WRITE_RESTRICTED` backend rejects as `unsupported_policy` before
doctor, setup, DACL mutation, or target start.

Every concrete file reached by `read`, `grep`, or `glob` is checked against the
bound workspace. Child runs inherit ceilings for native reads, tools, Skills,
and Skill scripts; they cannot expand the parent's admitted authority.

### Publish one KodaX Agent

Publication is host-owned and opt-in. The public card describes only the
configured Agent, media types, and skills. Authentication runs before task
lookup; authorization runs per operation; task visibility is principal-scoped.

```ts
import {
  createBearerEnvA2AAuthentication,
  createKodaXA2AServer,
} from '@kodax-ai/kodax/a2a';
import { createKodaXRuntime } from '@kodax-ai/kodax/runtime';

const runtime = await createKodaXRuntime({ mode: 'embedded' });
const server = createKodaXA2AServer({
  runtime,
  dataDir: '/var/lib/kodax/a2a',
  agent: {
    name: 'KodaX Reviewer',
    description: 'Reviews bounded code changes.',
    version: '1.0.0',
    publicBaseUrl: 'https://kodax.example',
    skills: [{ id: 'review', name: 'Review', description: 'Review code.', tags: ['code'] }],
    inputModes: ['text/plain'],
    outputModes: ['text/plain'],
  },
  authentication: createBearerEnvA2AAuthentication({
    type: 'bearer-env',
    tokenEnv: 'KODAX_A2A_TOKEN',
    principalId: 'trusted-orchestrator',
  }),
  async authorize({ principal }) { return principal.scopes.includes('a2a:invoke'); },
  limits: {
    maxRequestBytes: 1_048_576,
    maxPartBytes: 524_288,
    maxConcurrentTasks: 8,
    maxTaskWaitMs: 30_000,
    maxActiveTasksPerPrincipal: 8,
    maxRetainedTasksPerPrincipal: 64,
    maxEventsPerTask: 1_000,
    maxEventBytesPerTask: 16_777_216,
    maxWorkspaceBytesPerContext: 1_073_741_824,
  },
});

// Development only: the built-in listener refuses non-loopback hosts.
const localBaseUrl = await server.listen({ hostname: '127.0.0.1', port: 0 });
```

The listener also refuses an explicit port blocked by WHATWG Fetch clients.
With `port: 0`, it retries ephemeral allocation rather than returning a URL
that Fetch would reject before connecting.

Production hosts route `GET /.well-known/agent-card.json` and canonical
JSON-RPC `POST /a2a` to `server.handle(request)` behind their own TLS
terminator. `POST /` remains an accepted compatibility alias. `listen()` waits for durable recovery before
it resolves. A host that wires `handle()` directly may explicitly await
`server.whenReady()` before it starts accepting traffic; `handle()` also waits
for the same recovery promise. The durable edge store supports get/list,
continuation, cancellation, ordered SSE subscription, and surviving Runtime-run
reattachment after an edge restart. Push notifications, A2A 0.3, gRPC, and
HTTP+JSON are not advertised; unsupported push methods return the standard
`PushNotificationNotSupportedError`.

Non-streaming `SendMessage` waits at most `maxTaskWaitMs` (30 seconds by
default). When that bound is reached the response contains the current working
task; it does not cancel the Runtime run, and clients can continue with
`GetTask` or `SubscribeToTask`.

When a task enters `INPUT_REQUIRED`, the next accepted input answers the pending
interaction on the original Runtime run; it does not start a replacement run.
History length and list filters are validated and bounded. Task listing uses a
stable opaque cursor, while per-principal retention prunes only the oldest
terminal records. Terminal subscriptions and failed-start resources are closed
by their owning lifecycle.

Remote messages are ordinary user inputs. They cannot select provider, model,
profile, tools, working directory, permission mode, or Runtime configuration.
URL parts are rejected; inline raw/data parts are bounded and materialized under
the server-owned data directory. Responses expose final approved output only,
not system prompts, reasoning deltas, tool payloads, credentials, or local paths.

Generated files are published only through the trusted output broker: a normal
tool or Extension stages a file in the context's `.kodax-a2a-staging` area, or
a successfully admitted `run_skill_script` promotes one of its declared
outputs. The server rechecks that the result is a regular non-symlink file in
the real bound workspace and applies part-size/output-mode limits before
inlining it. A declaration from a failed Skill run, an ordinary `write`/`edit`
elsewhere in the workspace, and a local path in model text never become A2A
artifacts implicitly.

The normative baseline is A2A repository commit
`2183794bfb9b67af4aee1be0a0ef726050642873`, protocol `1.0`, with
`specification/a2a.proto` SHA-256
`e195bf96ab630c69797851970203e1b2b6b19528f2e9803b7d904b91a5104016`.

---

## 23. Shared Coder daemon for Space and IDE hosts (FEATURE_269, v0.7.69)

> Trusted Electron Main/Host integration reference, including capabilities not
> exposed by Product Client. UI business operations use `/client`; do not port
> this entire Runtime facade into the renderer. See the migration guide above.

FEATURE_269 makes one local daemon the source of truth for a Coder profile.
CLI, Space, IDE, and SDK clients can observe and control the same sessions and
runs. The transport remains local to the current OS user; it is not a remote
collaboration protocol. Closing a client detaches that client and does not stop
the daemon or another client's run.

Partner is deliberately outside this migration. Keep Partner on its existing
inline callbacks and give it a distinct product data root and sessions root.
Do not point a Partner inline Runtime at the Coder daemon profile or the Coder
data root.

### Connect and fail closed on required capabilities

Space should own the daemon SDK client in Electron Main. Persist a random,
stable `instanceId` and a separate 32+ character `instanceSecret` per Space
installation. Store the secret in the OS keychain; never accept either value
from renderer or model output. `connectKodaXRuntime()` is passive;
use `ensureKodaXRuntime()` for low-level startup/update.
An explicit inline rollback policy blocks auto-start until the owner policy is
explicitly changed back to daemon.

The embedder owns the complete credential storage lifecycle. When using an
Electron `safeStorage` encrypted file on Windows, preserve the associated
`Local State` encryption state together with the ciphertext across cleanup,
uninstall, reinstall, and profile migration. Keeping only the ciphertext is
insufficient, even when the Windows account and Provider API keys are unchanged.
The SDK does not read, repair, or replace this Electron encryption state.

If the existing client secret cannot be decrypted, surface a terminal credential
recovery error before connecting; do not silently generate a replacement secret.
A successful daemon connection alone does not prove that a recovered candidate
matches the old secret: a different secret selects a different reverse bridge
and cannot resume the old bridge's leases. Restore the exact existing identity
from verified recovery material, or explicitly treat it as a new identity.

For Electron, `homeDir` is still the CLI-style base directory, not
`process.env.KODAX_HOME`. Packaged/asar applications may use `ensureKodaXRuntime()`
directly; the SDK launches only the daemon child in Electron's Node execution
mode and does not mutate the application's environment or start a second GUI
instance. `ELECTRON_RUN_AS_NODE` exists only at the child exec boundary and is
removed before daemon application code loads, so Bash, MCP, LSP, sandboxed
commands, and ordinary external processes do not inherit Electron Node mode.

Packaged auto-start requires Electron's `RunAsNode` fuse, which Electron enables
by default. If an embedder deliberately disables that fuse, the packaged
executable cannot serve as a detached Node host: start the daemon with an
ordinary Node/CLI process and use attach-only mode instead. A packaged
startup timeout includes this fuse requirement in its diagnostic; the
SDK does not relaunch the GUI or silently fall back to an inline Runtime.

### Packaged Electron native artifact layout

An Electron host that enables `asar` must keep KodaX native artifacts as
physical ordinary files. All platforms unpack KodaX's `dist/native` tree;
Windows additionally unpacks ASRT's `vendor/srt-win` tree. For
`electron-builder`, use:

```json
{
  "asar": true,
  "asarUnpack": [
    "node_modules/@kodax-ai/kodax/dist/native/**/*",
    "node_modules/@anthropic-ai/sandbox-runtime/vendor/srt-win/**/*",
    "node_modules/**/@anthropic-ai/sandbox-runtime/vendor/srt-win/**/*"
  ]
}
```

The nested ASRT pattern covers an npm installation that cannot hoist the exact
KodaX dependency version. If a different packager or dependency layout is
used, apply the same rule to the actual installed paths. KodaX maps an embedded
`app.asar` source only to an existing sibling under `app.asar.unpacked`, then
retains the ordinary-file identity, bounded-read, embedded SHA-256, and
protected-cache checks. It does not trust virtual ASAR file metadata or fall
back to unchecked native bytes. Missing physical artifacts therefore fail with
an actionable native-artifact diagnostic before a sandbox process is launched.
Once an embedded manifest's exact hash has been materialized, resolution reuses
that verified protected-cache generation before consulting mutable packaged or
linked source. This keeps a long-lived Electron/SDK process on one native
evidence schema while a new build is prepared. A new process with a new embedded
hash publishes its own immutable generation atomically.

```ts
import { ensureKodaXRuntime } from '@kodax-ai/kodax/runtime';

const runtime = await ensureKodaXRuntime({
  profile: 'coder',
  // Opt in only when this product remains the visible owner of the daemon.
  // If the product crashes, the daemon stops after its final client is gone
  // and governed work becomes idle.
  daemonOrphanExitMs: 30_000,
  homeDir: coderRuntimeBaseDir, // owns <coderRuntimeBaseDir>/.kodax
  clientInfo: {
    name: 'kodax-space',
    version: '0.1.32',
    clientType: 'app',
    instanceId: spaceInstallationId,
    instanceSecret: await spaceKeychain.readRuntimeClientSecret(),
  },
  capabilities: {
    richEvents: true,
    permissionPrompts: true,
  },
  requirements: {
    sessionObservation: 1,
    afterTurnInput: 1,
    interruptInput: 1,
    askUserTransport: 1,
    permissionCas: 1,
    providerCredentialBroker: 2,
    effectiveConfig: 1,
    runBoundHostTools: 1,
    coderOwnerFencing: 1,
    crashOutcomeModel: 2,
    sandboxRuntime: 11,
    coderFeatureMatrix: 1,
    sessionAdmission: 1,
    completeObservationSnapshot: 1,
    connectionLifecycle: 1,
    typedRuntimeEvents: 1,
    daemonSafeRunInput: 1,
    sharedSessionSettings: 2,
    durableRecoveryQueries: 1,
    daemonManagement: 1,
    runtimeEventCoalescing: 1,
    liveOutputSegments: 1,
    runtimeAutoModeGuardrail: 6,
  },
});
```

Requirements are server facts, not authorization requests. Check
`runtime.grantedScopes` before enabling controls. Missing capabilities or
scopes must disable the affected UI; Space must not silently start inline
Coder. Products that depend on same-Run delivery should require
`{ interruptInput: 1 }`. Individual active Runs without a safe Actor boundary
(for example, SA execution) still return `unsupported_capability`; do not
silently substitute `delivery:'after_turn'` unless that is the user's intent.

The SDK requires `runtimeAutoModeGuardrail:6` and
`sharedSessionSettings:2` automatically for ordinary launcher startup.
The capability gate prevents an alpha.6 client from attaching to an alpha.3
daemon that advertises the older permission-before-sandbox contract. Supplying
`daemonOrphanExitMs` additionally requires the
dedicated `daemonOrphanExit:1` capability and passes the option only when
spawning a new daemon. It does not silently reinterpret an already-running
persistent daemon: the SDK uses the normal fenced capability-upgrade path and
replaces it only when preflight proves that doing so is safe. After the daemon
has observed a logical client, final-client detach arms the requested grace
period; a new client cancels it, and active/queued runs, Workflow, Agent turns,
pending permission/user input, or other governed work defer exit until
preflight is idle. Omit the option for CLI-style daemons that are intentionally
persistent.

An embedder can inspect `KODAX_RUNTIME_SDK_CAPABILITIES.daemonOrphanExit`
before calling an auto-start API. This prevents an older SDK from spawning a
persistent daemon and only then discovering that it cannot honor the requested
lifecycle policy. The connected daemon capability remains the authoritative
check that the current host actually enabled the policy.

`KODAX_RUNTIME_SDK_CAPABILITIES.runtimeEventCoalescing` performs the same
local-SDK preflight for bounded source-level text/reasoning coalescing. Requiring
`runtimeEventCoalescing:1` lets auto-start replace only an idle legacy daemon;
a busy or otherwise unsafe owner produces the normal capability-upgrade error.
The capability changes event allocation/persistence pressure, not reconstructed
stream content: flush boundaries remain explicit and an accumulated merge
never exceeds 8 KiB.

`liveOutputSegments:1` makes provider replacement semantics an SDK fact rather
than a host heuristic. `output.segment.started` identifies the logical reply
with `responseId`, the physical call with `providerRequestId`, and whether the
segment appends or replaces the current call. Text and reasoning deltas carry
the physical request id. Raw replay retains every attempt; use
`snapshot.live.outputSegmentsByRun` for the effective live response after an
observation join or reconnect. Do not append a provider's cumulative response
again during recovery, and do not infer replacement from attempt numbers or
text equality.

`KODAX_RUNTIME_SDK_CAPABILITIES.conversationHistory` is now `2`.
Require it before auto-start so an idle daemon that still exposes the legacy
ordinary-history projection is replaced; a busy or otherwise unsafe owner
produces the normal capability-upgrade error.

`KODAX_RUNTIME_SDK_CAPABILITIES.sandboxRuntime` is `11` in v0.7.97
and `crashOutcomeModel` remains `2`. Windows auto-start requires
`sandboxRuntime:11`, so an idle v10-or-older daemon is replaced. Concurrent
authenticated upgrade clients converge on one fenced replacement, including
the exact revision-CAS attach window; a busy daemon or one with
untrusted clients remains untouched and returns structured restart guidance. Version 6 means that
trusted text transactions are host-owned and the native shell runner has no
command-lifetime filesystem-effect lease; a v5 daemon cannot be reused for
those semantics. The former `model-filesystem-effects.*` coordinator state is
ignored by v0.7.96 and cannot block Bash, trusted text, or worktree admission;
deprecated lease exports are immediate compatibility shims. Require
`crashOutcomeModel:2` when the host
depends on managed Session persistence preceding completion and on the
executor Promise — not managed `onComplete` — as terminal authority. Do not
delete old coordinator files to recover a current Runtime; an older process
must instead be stopped/upgraded. `reclaimStaleKodaXFileLock` remains an
explicit stale-lock helper for APIs that still use file locks, not a general
lock-deletion primitive.

### Windows lifecycle diagnostics

Windows lifecycle diagnostics use the existing process-local
`setKodaXDiagnosticSink` export from `@kodax-ai/kodax/agent`. Install the sink
before connecting or ensuring Runtime ownership, and call its returned cleanup
function when the host closes. The daemon already writes its own diagnostics
to `daemon.log`; a client-process sink does not subscribe to daemon-process
events.

`source: 'runtime:windows'` identifies boot identity, Job membership, process
snapshot, and process-start identity stages. Probe
details report availability, whether a cached result was used, and (for an
executed probe) elapsed time, timeout, exit code, and a bounded OS error code.
`source: 'runtime.daemon.capabilities'` with
`stage: 'capability-check'` records the original required capability and version
before a subsequent upgrade failure can obscure it.

These records omit commands, environment variables, stdout, stderr, credentials,
and identity values. They do not add probes or retries, change existing failure
caching, relax Job/identity checks, or alter shutdown results. A missing
capability diagnostic is evidence for troubleshooting, not permission to bypass
the required capability. Diagnostic sink exceptions remain isolated from the
Runtime operation.

### Unreleased: interrupted Run recovery and transcript ownership

The current development tree integrates the rc.14 fixes under FEATURE_298 /
v0.7.97. Product applications use [/client](#product-client-integration), and
the Host is the only Session writer. Ink/classic consumers render Host facts
and submit intents; they do not save a competing transcript or lineage.

Runtime-owned managed Runs save generated messages and tool results at Runner
commit boundaries. An interrupted Run can contribute a bounded recovery note
to the next SA or AMA model request. Its sources are canonical Session/active
lineage, Run status, and successfully saved display checkpoints. The Host
flushes the existing writer before reading; it does not replay durable events
or infer success from telemetry. Failed checkpoint reads/writes remain errors.

Evidence uses accepted input and turn identities, explicit sourceRunId /
sourceTurnId, assistant outputId, and the assistantOutputId owning a tool call.
A proposed tool is not an executed effect. Execution without a recorded result
has an unknown outcome, including a displayed cancelled tool whose result was
never saved. Already committed output is excluded by identity, so two equal
replies with different outputIds remain distinct. Thinking, child output, and
ordinary notices never enter the recovery record.

The record covers at most three Runs and 6,000 characters, giving operations
priority over quoted, unconfirmed reply excerpts. It is transient model context,
never a user instruction or canonical Session message. No automatic tool redo
or recovery of uncheckpointed tokens is promised. Tool-only invocations make
no model call and need no recovery note. Standalone callers can supply the
internal KodaXInterruptedRunEvidence / Operation / Reply handoff types through
context.interruptedRunEvidence; that option is not a persistence protocol.

Uncertain Shell cleanup retains deferred process ownership while allowing the
next Run and Host close to proceed. ClientRunStatus and ClientRunOutcome expose
the Host terminal.effectOutcome and Stop facts. A completed execution with
unknown effects does not prove cleanup or confirm Stop.

### Historical v0.7.92 filesystem-effect coordinator and managed terminal authority

The coordinator described below applied to v0.7.92-v0.7.95. v0.7.96 retires
it from Bash, trusted text, and worktree lifecycle; its files are ignored.

A Worker operation can disappear while the shared Coder daemon PID remains
alive. The coordinator queue now identifies each attempt by an operation token
that is also the exact lock token. Waiters heartbeat their ticket. A stale
same-process ticket is reclaimed only when that token no longer owns
`model-filesystem-effects.lock`. Effect release writes a token-scoped
`.released` marker first so a later transaction can drop only that settled
owner.

On Windows the coordinator state is
`C:\ProgramData\KodaX\sandbox-runtime\runtime\`. Deleting the lock file does
not remove leftover `.queue` tickets or `model-filesystem-effects.json`
owners. Timeouts surface as `KodaXFileLockTimeoutError`; the historical
`learning store lock timed out` text was a reused generic-lock message, not
proof that a learning job held the lock.

Managed Runs persist the canonical Session before publishing completion.
Repo-intelligence and task-file projections are asynchronous and must not keep
the Run in `finalizing`. For `mode: 'managed_task'`, Runtime uses the executor
Promise as terminal authority; `events.onComplete` alone does not finish the
Run. Require `crashOutcomeModel:2` when the host depends on that ordering.

Resume reconstruction is canonical-first. Hosts that call
`restoreHistoryItemsFromSession({ messages, uiHistory })` receive the bounded
message-derived transcript plus optional display overlays. Do not treat
`session.uiHistory` as the set of ordinary conversations that exist.
Presentation-only synthetic completion events remain host-owned when that
cache is non-empty.

Observation boundaries such as `events.subscribe()` and Session status
projection deliver the live in-process stream; since v0.7.97 removed the
durable event journal, there is no replay boundary, durable append, or
stale-waterline failure mode on this path. Latest-only progress coalescing
preserves its required first sample plus the most recent sample; discarded
intermediate snapshots are not lifecycle events, and surviving samples retain
their latest emission order.

When a healthy profile daemon is too old, the SDK first reads capabilities from
the authenticated health probe, before attaching the embedder's stable client
identity or restoring its reverse bridge. The incompatible daemon is contacted
with an ephemeral upgrade identity. The SDK requires `daemonManagement:1`,
takes a revision/owner-policy fenced preflight, and replaces it only when no
active or queued run, Workflow, Agent turn, pending permission/user input, or
other logical client exists. Replacement performs a fenced idle shutdown: it
verifies the captured owner/process-start identity, sends `runtime.shutdown`,
waits for the complete process exit, and then starts the packaged Runtime.
v0.7.97 removed the crash-resumable exit-settlement ticket this path
previously reused; there is no prepared-ticket state to preserve across a
crash mid-upgrade.
A busy or still-older daemon is never stopped: the connection rejects with
`RuntimeDaemonCapabilityUpgradeError`, whose `recoverable` and
`restartRequired` fields are `true` and whose optional `preflight` explains the
blockers. Attach-only connections never mutate daemon ownership and must request
the exact capabilities they depend on. Capability requirements are minimum
versions: v4 satisfies v1-v3, v3 satisfies v1/v2, v2 satisfies v1, and an older
daemon never satisfies a newer requirement.

The `coderFeatureMatrix` capability reports daemon availability for managed
runs, transcript/session operations, Todo projection, managed tasks, Workflow,
MCP, Reference External Agent, Memory, and Runtime artifacts. Reference
External Agent is `false` when the daemon owner did not install its executor
plane.

The packaged daemon authenticates one local OS-user/profile trust domain with
a random token stored beside daemon state and a user-only local endpoint. It
does not issue a different daemon token to each application in v0.7.69. The
returned scope set is chosen by the host (the packaged host grants the public
local-user set). `clientInfo.instanceId` is stable attribution: the daemon
derives its authenticated connection principal from it. `instanceSecret` proves that a new authenticated
connection is the same stable client when it resumes that client's credential
or Host Tool leases; only its hash participates in daemon-owned bridge state.
Keep all three values in Electron Main. Mutually distrusting processes running
as the same OS account remain outside this release's threat model.

### Query authoritative Session and Run lifecycle

Use `runtime.runs.get(runId)` for the exact Run and
`runtime.sessions.status(sessionId)` for the one current Session projection.
Do not infer completion from assistant text:

```ts
const run = await runtime.runs.get(runId);
const sessionStatus = await runtime.sessions.status(sessionId);

switch (run.phase) {
  case 'running':
  case 'waiting_agent':
  case 'recovering':
  case 'waiting_permission':
  case 'waiting_user_input':
    renderActive(run.phase);
    break;
  case 'unknown':
    renderUnconfirmedExecution(run.error);
    break;
  case 'completed':
  case 'cancelled':
  case 'interrupted':
  case 'failed':
    renderTerminal(run.terminal);
    break;
}
```

`phase` answers whether the Run is queued, active, terminal, or unconfirmed.
Use `stage` for the finer executor location: `executing`,
`waiting_agent`, `recovering`, managed phases such as `worker` or `verifying`,
and `finalizing`. In particular, managed status `completed` first appears as
`phase:'running', stage:'finalizing'`; it is not terminal until the outer
executor settles. `stageChangedAt` timestamps that transition, and
`activeSubtaskCount` is present only when the managed executor reported an
authoritative count. If Runtime shutdown begins after an executor terminal
callback was latched, that terminal fact is persisted synchronously before the
owner-liveness endpoint is released. Result-handle resolution and queue drain
still wait for the executor result or the deferred lost-result fallback.
Destructive Session mutations remain fenced across the same settlement window.

Run ownership is private persistence metadata, not a public ordering field. A
second Runtime may observe a live owner's status but cannot abort or mutate
that Run. A definitely dead owner is recovered to a durable `interrupted`
result. If liveness cannot be proven either way, the observer returns
`phase: 'unknown'`; it does not report a successful stop and does not overwrite
the original non-terminal record. The same rule applies to ownerless legacy
non-terminal records. A durable terminal event is reconciled before this
fallback; non-terminal evidence such as an input-delivery event may refine the
read projection but does not prove that execution stopped. Persisted terminal
states are monotonic.

Current source treats Run terminal persistence as its own fail-closed
convergence boundary. If the durable terminal status succeeds but event
publication fails, the durable status remains authoritative. If status commit
succeeds but status-lock cleanup reports failure, Runtime rereads the record;
only an exact deep match with its local terminal proposal continues to one
terminal event publication. A different authoritative record wins without a
duplicate event. If neither
terminal record can be persisted, `handle.result`, `runs.get()`, and
`runs.await()` converge to `phase:'unknown'` with lifecycle code
`run_settlement_not_persisted`; the Session execution fence stays closed.
When a classified fact exists, failed/cancelled terminal projections and
settlement `run.updated` carry the same credential-safe `failureDetail` described in
[Structured Runtime failures](#structured-credential-safe-runtime-failures),
including its stable KodaX code, stage, bounded display message, and optional
sanitized upstream metadata.
Sandbox and managed-child termination failures are observed and retained as
diagnostics rather than escaping as process-global unhandled rejections.
If terminal status persistence fails, Runtime still publishes `run.updated`
with `phase:'unknown'` on the live event stream. If live delivery fails too,
active `sessions.observe()` handles resolve
`invalidated` with `reason:'delivery_failed'`; consumers must discard their
local projection and acquire a fresh observation instead of retaining a stale
running/terminal state.

`runtime.status.preflight()` treats `queued`, all active/waiting/recovery
phases, and `unknown` as stop blockers. A host must never infer completion from
reply text or convert `unknown` into success.

`runtime.runs.abort(runId)` requests Stop; it does not manufacture an
acknowledgement. Queued work can become `cancelled` immediately. For an active
executor, inspect `run.stop`: while termination is unconfirmed, the Run reports
`phase/stage:'unknown'` and `stop.state/outcome:'unknown'`. A later executor
result confirms the actual outcome, including `completed` when the executor
ignored Stop and completed normally. Terminal callback order is latched before
deferred result settlement: Stop cannot rewrite an earlier completion as
interrupted, and late finalizer/recovery progress cannot revive an unconfirmed
stopped Run. If the Runtime owner then dies, recovery resolves the pending Stop
as `confirmed/interrupted`.

Since v0.7.82, an observed Stop cooperatively gates later Runtime-controlled
provider retries and continuations, Runner guardrail/tool dispatch, and
Run-admitted Actor work. It does not hard-kill turns admitted before Stop or
rewrite a genuine completion or an independent failure. A trusted Stop/Abort
cause is classified before credential redaction, so `runs.get()` and `await()`
report the same factual terminal outcome.

For support bundles, use the pure read-only compositor:

```ts
import { captureRuntimeSessionDiagnostics } from '@kodax-ai/kodax/runtime';

const diagnostic = await captureRuntimeSessionDiagnostics(runtime, {
  sessionId,
  runId,
  timeoutMs: 10_000,
  signal: abortController.signal,
});
```

The schema-versioned result includes SDK/Runtime/daemon versions, Runtime and
Session identity, observation cursor/transcript revision, Run/Turn identity,
phase/stage and stage time, terminal fact/time, Run-owned active child count,
Stop and chat-interrupt records, and structured errors. If the selected Run
did not persist an authoritative child count, the result returns
`activeSubtaskCount:null` and `activeSubtaskCountSource:'unknown'`; it never
attributes a later Session-wide child sample to that Run. If a historical
Session has no Run control record, it returns `controlRecord:'unknown'` with
`run_control_unknown`; it never infers completion from transcript text.
`owner_liveness_unconfirmed`, `owner_recovery_required`,
`stop_outcome_unconfirmed`, `run_failed`, `run_status_unknown`, and
`terminal_time_unknown` remain distinct. These are independent facts rather
than an enum: for example, an unavailable owner and an unconfirmed Stop appear
together in `errors`. `sdkVersion` is the calling SDK package version;
`runtimeVersion` and `daemonVersion` identify the connected daemon in daemon
mode, so a support bundle preserves version skew. One timeout/cancellation
budget covers the transcript, settings, pending interactions, and owner
liveness inspection. The helper uses the dedicated
`sessions.diagnostics()` read boundary: it never runs status preflight,
resumes, repairs, migrates, takes ownership, or evicts a retained transcript
page boundary. Embedded and daemon facades use the same schema-validated
`session.diagnostics` contract.

### Join atomically and resync after disconnect

`sessions.observe()` installs the live subscription before taking the
snapshot. Its snapshot contains one authoritative `runtimeId`, cursor,
`transcriptRevision`, bounded transcript slice, versioned settings, run/queue state,
queued continuation IDs/order/origin/safe previews, pending permission and
AskUser requests, and live assistant/thinking/tool/Todo/managed-task
projection. Run requirements include the current credential/Host Tool
availability. Listener events are strictly after the returned cursor.

```ts
let observedRuntimeId: string | undefined;
let lastCursor = 0;

async function openCoderSession(sessionId: string) {
  const observation = await runtime.sessions.observe(sessionId, (event) => {
    if (event.seq <= lastCursor) return;
    applyRuntimeEvent(event);
    lastCursor = event.seq;
  });

  const { snapshot } = observation;
  const runtimeChanged = observedRuntimeId !== undefined
    && observedRuntimeId !== snapshot.runtimeId;
  observedRuntimeId = snapshot.runtimeId;
  lastCursor = snapshot.cursor;
  replaceSessionProjection(snapshot, { runtimeChanged });
  void observation.invalidated.then((reason) => {
    discardSessionProjection(reason);
    scheduleFreshObservation(sessionId);
  });
  return observation;
}
```

Subscribe to `runtime.connection` to freeze mutation UI immediately rather
than waiting for a status poll:

```ts
runtime.connection?.subscribe((state) => {
  setCoderConnectionState(state.state, state.reason);
  if (state.state === 'disconnected' && state.reconnectable) {
    scheduleReconnect();
  }
});
```

The SDK reports the current `connectionId`, `runtimeEpoch`,
disconnect reason, and whether a new connection may be
attempted. It does not transparently replay requests or subscriptions. Space
creates a replacement Runtime client, checks its new epoch, resumes eligible
leases, and observes the session again.

`RuntimeDaemonDisconnectCode` reports only transport-observable facts:
`protocol_closed`, `transport_error`, `invalid_frame`, or `client_closed`.
The lifecycle state and pending RPC rejection carry the same `connectionId`
and `reconnectable` value. `invalid_frame` includes the 8 MiB protocol boundary;
outbound oversize is rejected before socket write. A transport close alone is
not evidence of `daemon_crashed`; use durable Run status or launcher/crash
evidence for that classification.

Once `runs.start()` returns, retain the exact `runId`. If the result Promise
fails because a reconnectable transport was lost, attach a replacement Runtime,
verify the same Session with `runs.get(runId)`, and await that Run:

```ts
const admitted = await runtime.runs.start(input);
let replacement: KodaXRuntime | undefined;

for (;;) {
  try {
    if (replacement === undefined) {
      return await admitted.result;
    }
    const status = await replacement.runs.get(admitted.runId);
    if (status.sessionId !== admitted.sessionId) {
      throw new Error('Run identity changed');
    }
    return await replacement.runs.await(admitted.runId);
  } catch (error) {
    if (!isRuntimeDaemonDisconnectError(error) || !error.reconnectable) {
      throw error;
    }
    replacement = await attachRuntimeAfterBackoff();
  }
}
```

Here `attachRuntimeAfterBackoff()` owns one shared reconnect schedule, resolves
only after a replacement Runtime is ready, and rejects on permanent
initialization failure or explicit host close.

Never call `runs.start()` again for the admitted request: transport recovery is
observation, not execution replay. A second disconnect during `runs.get()` or
`runs.await()` repeats the same recovery loop with the same `runId`. Permanent
initialization errors and explicit host close settle the waiting result instead
of leaving it pending.

On transport failure, Runtime change, expired history, or `resync_required`,
discard the local derived projection and call `sessions.observe()` again. Do
not merge a new snapshot into the old projection. The handshake buffer is
bounded; overflow fails explicitly instead of dropping events. A Runtime
restart changes `runtimeId`. The observation's `invalidated` promise reports
`event_overflow`, `event_order`, `runtime_changed`, or
`transport_disconnected`; after it resolves, no state derived from that
observation remains authoritative. Restart recovery interrupts only a Run
whose owner is definitely gone; uncertain external execution is `unknown`.
Timeout or cancellation removes the daemon request immediately. A result that
arrives after its reader abandoned the request is dropped — the transport
sends a hygiene `request.cancel` so the Host frees the in-flight record and
any subscription it created, but no late delivery reaches the caller.

### Durable mutations, stable ordering, and settings CAS

Public control mutations no longer take an operation envelope. v0.7.97 removed
the generic `operation: { operationId }` input, auto-generated operation IDs,
the control journal, and the `runtime.operations.get` receipt query; mutation
identity now comes from each mutation's own domain fields — the explicit
`sessionId` on create, the returned `runId` on start, and the settings
revision on CAS updates. Credential and Host Tool
register/revoke/supply/complete requests are reverse-bridge
control frames and persist no secrets or results. They still enter the daemon
management draining fence: once an atomic stop begins, they fail with typed
`conflict` and cannot change reverse-bridge state. Reconnection semantics are
explicit: after a lost response, re-read authoritative state and reconcile in
your product code; the SDK never transparently retries or replays a mutation.

```ts
const session = await runtime.sessions.create({
  sessionId: stableSpaceSessionId,
  title: 'Shared session',
  surface: 'space-desktop',
});

const handle = await runtime.runs.start({
  sessionId: session.id,
  input: { type: 'text', text: prompt },
  options: { provider: 'anthropic' },
});

const current = await runtime.sessions.getSettingsVersioned(session.id);
const updated = await runtime.sessions.updateSettingsVersioned(
  session.id,
  { model: 'claude-sonnet-4-5' },
  { expectedRevision: current.revision },
);
```

Re-creating with the same explicit `sessionId` cannot overwrite
an existing session. Same-session starts and after-turn inputs receive a durable `sessionOrder`.
Settings use compare-and-swap; a stale revision returns a
structured conflict and must be reloaded, never silently overwritten. The
shared settings keys are `provider`, `model`, `effort`, `thinking`,
`reasoningMode`, `permissionMode`, `executionCwd`, `agentMode`, and
`autoModeClassifierModel`. Older Auto engine/timeout/window fields are accepted
only as inert migration input and are omitted from new writes.

```ts
const queued = await runtime.runs.submitInput({
  sessionId: session.id,
  afterRunId: handle.runId,
  delivery: 'after_turn',
  input: { type: 'text', text: 'Also update the tests.' },
});

if (!queued.accepted) {
  // stale_run, unsupported_capability, or interrupt_window_closed:
  // show the factual result and preserve the user's unsent input.
}
```

For input that must join the current active Run, submit `delivery:'interrupt'`.
This does not create a Run. Each accepted input appears as `queued` in the
owning Run's `interruptInputs`. At the next safe boundary, all accumulated
interrupts are drained FIFO, remain separate user messages in one next LLM
request, and produce one `run.input.delivered` event whose `inputs` array is the
complete ordered batch. An accepted interrupt returns the `inputId` of the
admitted item, which you keep for later reconciliation.
The accepted result's `runId` is the existing owning Run (equal to
`afterRunId`), not a newly created continuation.

Since v0.7.81, every newly delivered item also carries `entryId`: the exact
physical Session-lineage user entry created by canonical persistence. The same
value appears in `runtime.runs.get(runId).interruptInputs`; do not infer it
from a transcript ordinal or fabricate one. Runtime-owned Sessions write the
required snapshot before publishing the delivery event, so a failed or
ambiguous canonical reference fails delivery closed. The field may be absent
only when reading a legacy persisted record. Event replay, Session compaction,
and Runtime restart preserve a newly recorded reference.

Since v0.7.82, submission resolves the admitted authoritative Run before it
reads mutable canonical Session history. Active interrupt and after-turn
requests therefore do not surface a transient `data_changed` response caused by
predecessor persistence. `after_turn` still waits for predecessor settlement;
admission and queue placement are owned by the receiving Run.

Interrupt admission closes when the Runner publishes its final completion or
terminal error signal, or when the Run's supplied `abortSignal` aborts, even if
the outer Run is still settling. Non-terminal observer diagnostics do not close
the window. Same-Run lifecycle continuations also have a fixed internal
allowance beyond the configured iteration ceiling; the Runner closes admission
before its final absolute generation so repeated submissions cannot keep one
Run alive indefinitely. The allowance never expands an admitted manifest's
`maxIterations` governance cap. A submission after closure returns
`accepted:false` with `reason:'interrupt_window_closed'` and is not queued. Keep
the original input available for retry after the Run ends; do not silently
change its delivery to `after_turn`. As a final race/recovery
guard, inspect terminal Run status: any `interruptInputs` entry whose state is
`terminal` was not delivered. Reconcile it by `inputId` and present a visible
non-delivery outcome rather than leaving a pending queue indicator.

```ts
const interrupted = await runtime.runs.submitInput({
  sessionId: session.id,
  afterRunId: handle.runId,
  delivery: 'interrupt',
  input: { type: 'text', text: 'Also preserve the public API.' },
});
```

Run status exposes acceptance/start/queue times, authenticated origin,
`sessionOrder`, and a single terminal fact. Important terminal codes include
`runtime_restarted`, `daemon_crashed`, `credential_unavailable`,
`host_not_dispatched`, `host_outcome_unknown`, and
`control_history_untrusted`. Managed tasks that require user input use
`terminal.code = 'blocked'`; surface `terminal.message` when present instead of
replacing it with a generic run failure. Respect `effectOutcome`; `unknown` must
never be presented as success or automatically retried. After a lost response,
there is no operation receipt to query: re-read authoritative state with
`runs.get(runId)` / `sessions.status(sessionId)` and reconcile explicitly.
Permission grants remain daemon-owned and
revisioned.

Runtime startup restores all indexed active Runs and at most 200 recent
terminal Runs from a bounded durable status index. `runs.get(runId)` remains an
exact persisted lookup even when an older terminal Run is outside that recent
window. The first start after upgrading an unindexed home may perform one full
compatibility scan. A start after a crash, or a concurrent Runtime starting
while a live writer has intentionally left the index dirty, may likewise do
one authoritative reconciliation. Normal writers publish canonical
`status.json` first and keep the derived index recovery-fenced across those
crashes and concurrent Runtime instances.

### AskUser and permission from any client

AskUser is no longer an in-process callback for daemon Coder runs. Any client
with the responder scope can list the pending request and answer or dismiss it.
The request revision and run binding prevent a stale UI from answering a new
request. Exactly one concurrent answer is accepted. Runtime creation accepts
independent `permissionTimeoutMs` and `userInputTimeoutMs` values; each defaults
to five minutes. `userInputTimeoutMs` must be positive;
`permissionTimeoutMs` may also be `0` to disable its timer. Positive values
must not exceed 2,147,483,647.
The same non-negative bound applies to a per-request
`runtime.permissions.request({ timeoutMs })` override. A supplied `expiresAt`
must be a valid date no more than 2,147,483,647 ms in the future; past dates
fail closed immediately.
On AskUser expiry, the Runtime selects `default` only when it
is valid for that request (or is the free-text input default); without a valid
default it dismisses the request. For multi-question requests every question
must have a valid default to produce an automatic answer.

```ts
for (const request of await runtime.userInputs.listPending({ sessionId })) {
  const resolution = await runtime.userInputs.respond(request.id, answer, {
    expectedRevision: request.revision,
    runId: request.runId,
  });
  if (!resolution.accepted) refreshPendingInteractions();
}

for (const request of await runtime.permissions.listPending({ sessionId })) {
  const sessionScope = request.grantSuggestions
    ?.find((candidate) => candidate.kind === 'session');
  const accepted = await runtime.permissions.respond(
    request.id,
    sessionScope
      ? { type: 'allow_session', suggestionId: sessionScope.id }
      : { type: 'allow_once' },
    { runId: request.runId },
  );
  if (!accepted) refreshPendingInteractions();
}
```

Persistent `allow_always` grants are owned by the daemon and require
`permission:grant-admin`. Use `permissions.listGrants()` and
`revokeGrant(grantId, expectedRevision)` for revision-safe administration.
Clients must return one opaque `grantSuggestions[].id` from the pending request;
they must not infer, construct, or widen a scope from the display label or input
preview. A safe request can offer `allow_session` and `allow_always`; a risky or
dynamic shell request deliberately omits the persistent candidate. Command
grants match one exact normalized command/cwd/shell/background combination,
while path grants match one tool and normalized absolute path (the future
Write/Edit content may differ). Generic extension calls can receive only an
exact in-memory Session grant. Raw command/argv data is not stored in the
matcher; grants and audit contain only its fingerprint plus a bounded,
secret-redacted operator label. Clients must not keep separate persistent
permission rule stores. Runtime capability `runtimeAutoModeGuardrail` v5
advertises sandbox completion as authority, host-boundary-only Auto review,
one bounded host retry, and no automatic user prompt on reviewer denial.
Capability v6 adds the corrected concrete text-call approval and live
permission context contracts: Auto approvals bind to one exact text call
without granting a directory, and direct plus managed provider requests carry
the live permission mode refreshed on retries.
`sharedSessionSettings` v2 advertises the four canonical profiles and the
input-only `auto-in-project` alias. Embedded and daemon hosts expose
the same contract; restart or upgrade an older daemon instead of falling back
to client-side routing.

### Broker Space keychain credentials

Credentials remain owned by Space's OS keychain. Register a broker in Electron
Main, bind the returned lease only to operations that Space starts, and return
one key only after checking the daemon-provided Provider, Session, target, and
purpose. The v2 broker resolves Providers lazily and never preloads credentials
into the daemon environment.

```ts
const credentialLease = await runtime.credentials.registerScoped(
  { providers: ['anthropic', 'openai'] },
  async ({ provider, sessionId: requestedSession, target, purpose }) => {
    authorizeSpaceCredential({
      provider,
      sessionId: requestedSession,
      target,
      purpose,
    });
    return spaceKeychain.readProviderCredential(provider);
  },
);

const run = await runtime.runs.start({
  sessionId,
  input: { type: 'text', text: prompt },
  options: { provider: 'anthropic' },
  credential: {
    leaseId: credentialLease.id,
    mode: 'scoped',
    providers: ['anthropic', 'openai'],
  },
});
```

The allowlist is a ceiling: a run binding can narrow it but cannot add a
Provider. The daemon asks only when an actual primary, fallback, classifier,
sidecar, compaction, Workflow, or utility wire call needs that Provider.
An unauthorized Provider fails before the host callback. The secret crosses
only the authenticated reverse frame and exists in a transient exact-Provider
scope for that wire call. It is excluded from Provider caches, SDK-client
caches, events, status, logs, diagnostics, operation records, and persistence.
While such a scope is active, Provider mismatch fails closed and never falls
back to daemon environment.

The legacy `register()` / `resume()` exact-Provider v1 API remains available for
existing Run-only integrations. Use `registerScoped()` / `resumeScoped()` for
manual compaction, lazy multi-Provider routing, native Agent turns, and
Workflows. Requiring `providerCredentialBroker:2` makes an older daemon fail
closed instead of silently weakening the contract.

Without a stable `instanceSecret`, registration ends when the Space connection
closes. With it, the daemon keeps the registration owned by that stable client;
a replacement Space process reattaches the callback with
`runtime.credentials.resumeScoped(leaseId, broker)`. Disconnect does not replay
pending Provider requests. Revocation or expiry rejects pending and delayed
credential supply, aborts active request signals, and prevents every later
resolution through already-propagated async context. Runtime restart expires
all leases.

Native/constructed child Agents inherit only the intersection of the parent
scope and their concrete Provider capabilities; `'*'` never expands the parent
allowlist. Host `agents.spawn(..., { credential })` and a follow-up that starts
a new internal turn must bind explicitly at the shared-daemon boundary. A
follow-up delivered into the current turn cannot replace its binding. External
turns keep using `credentialRef`, reject Runtime Provider bindings, and cannot
read daemon ambient Provider keys. Detached
Workflow work receives a derived,
revocable Workflow scope; it closes on completion, failure, cancellation, or
parent closure. ALS propagates the handle but does not define its lifetime.

Agent operation, capability, control, and credential-binding objects are
closed protocol records. Put host-specific extension data only in `metadata`;
unknown authority fields are rejected instead of being ignored.

Use the separate admin-only effective-config API to diagnose startup source
without reading secrets:

```ts
const effective = await runtime.config.readEffective();
// entries.provider: { value, source, priority, applied, present }
// credentials.ANTHROPIC_API_KEY: { present, source } // never a value
```

The snapshot is a whitelist, reports persisted config as `loaded`, `missing`,
or `invalid`, and omits arbitrary persisted fields. Daemon clients need the
`integration:admin` scope and may require `effectiveConfig:1` during connect.

### Bind Space-owned Host Tools to one run

Register only narrow product capabilities. Descriptors are data; handlers stay
in Electron Main. A lease grants nothing until its ID is explicitly bound to a
run.

```ts
const hostLease = await runtime.hostTools.register([{
  name: 'space_artifact_create',
  description: 'Create a Space-owned artifact for this run.',
  inputSchema: {
    type: 'object',
    properties: { title: { type: 'string' } },
    required: ['title'],
    additionalProperties: false,
  },
  sideEffect: 'non_idempotent',
}], {
  async space_artifact_create(invocation) {
    authorizeBoundSpaceInvocation(invocation);
    const artifact = await createSpaceArtifact(invocation.input);
    return { content: `Created artifact ${artifact.displayId}` };
  },
});

await runtime.runs.start({
  sessionId,
  input: { type: 'text', text: 'Create the report artifact.' },
  hostTools: { leaseId: hostLease.id },
});
```

The daemon injects session/run/lease/invocation identity; renderer, model, and
ordinary tool input cannot choose it. CLI runs never inherit a Space lease just
because Space later observes their session. The client memoizes one handler
promise per invocation ID, and the daemon never replays a dispatched Host Tool.
After a stable-client reconnect, call
`runtime.hostTools.resume(leaseId, handlers)`. Bound run status reports
`ready`, `waiting_host`, `expired`, or `terminal`. Disconnect or timeout after dispatch produces `host_outcome_unknown`; Space
must reconcile the product side effect itself before offering a new user
action. `runtime.hostTools.getInvocation(invocationId)` returns the durable
metadata state `prepared`, `dispatched`, `completed`, `unknown`, or
`not_dispatched`; it never returns handler input, result, or credential data.
The daemon writes the `dispatched` marker before attempting the reverse frame
and never auto-replays an invocation.

Since v0.7.82, a live Host Tool lease contributes a complete, lease-scoped
capability snapshot to unfiltered `mcp_search`. An explicit `server` filter
selects only that named MCP or Host Tool source; it never leaks tools from the
other source. A provider without a snapshot is queried uncapped and reported as
incomplete/unknown rather than silently presenting a truncated catalog.

### Coder admission, typed events, and transport-safe inputs

The daemon enforces Coder session admission on the server for list/create/load,
run, settings, delete, rewind, fork, compact, transcript, event, interaction,
and diagnostic paths. Coder
surfaces are `code`, `cli`, `repl`, `acp`, `a2a`, `sdk`, `ide`, and
`space-desktop`. A session marked with
Partner surface/profile metadata, or any unknown product surface, fails with
typed `session_not_admitted` before mutation. Space must continue marking
Partner sessions as `surface: 'partner'` and keep their inline storage root
separate. Legacy sessions without a surface remain admitted for existing Coder
compatibility, so absence of metadata is not a Partner namespace mechanism.

`RuntimeEventPayloadMap` and `RuntimeTypedEvent` provide the public
discriminated contract for known events. Existing raw listeners remain
compatible; consumers can use `parseRuntimeEvent(value)` before exhaustive
handling. One unknown or malformed event is diagnosed and dropped without
closing the observation stream.

Daemon clients use `RuntimeDaemonStartRunInput`. Function callbacks,
`AbortSignal`, Extension Runtime objects, and guardrail instances are excluded
from that type and rejected at runtime with `RuntimeTransportBoundaryError`
and an exact value path if an untyped caller supplies them. Host-only values
remain valid only for embedded Runtime calls.

### Recovery queries and stop preflight

`runtime.status.preflight()` returns the initialized logical-client count,
active and queued runs, running/paused Workflows, every non-terminal External
Agent task (including `unknown`), pending AskUser/permission records, blockers,
and `canStop`. The background-work blockers are `active_workflows` and
`active_agent_tasks`. The current facade counts as one; daemon self-connections
and bounded health probes do not count. A second process changes the count to
two, and its awaited `close()` makes the count converge back to one.

Daemons that advertise `daemonClientInventory:1` also return optional
`preflight.clients`. Each entry contains a daemon-generated
`daemonConnectionId`, the connection principal, bounded display metadata,
`clientType`, and the server-recorded connection time. Connection IDs change
after reconnect and principals are attribution, not destructive work-ownership
proof. `name`, `title`, `version`, and `clientType` are self-reported,
display-only hints; never use them for authorization, work ownership, or process
control. Inventory never contains `instanceSecret`, daemon tokens, or other
credentials. Consume it additively: when `clients` is absent, continue using
`clientCount`. Do not require `daemonClientInventory:1` during a compatibility
rollout unless the product cannot operate without it.

Preflight is useful for UI, but it is not a stop authorization token. Use
`runtime.daemon.inspect()` to obtain one consistent management revision,
verified owner fence, owner-policy revision, and preflight projection, then
send the authenticated `runtime.shutdown` request: management rechecks
preflight under the draining fence and commits the stop only when the daemon is
idle, otherwise it fails with a structured `conflict` and the daemon keeps
running. The management revision also advances when the preflight projection changes,
so a Workflow or AgentTask lifecycle transition between inspect and stop
invalidates the stale attempt. Capability details
`daemonManagement.backgroundWorkPreflight` and
`daemonManagement.reverseBridgeDrainingFence` identify this complete contract.
`hostTools.getInvocation()` reconciles Host Tool metadata, and
`permissions.listGrants()` returns the daemon-owned persistent grant set;
durable mutations are reconciled by re-reading their authoritative state.

Terminal notification read/unread state is intentionally client-owned in
v0.7.69 (`durableRecoveryQueries.terminalAcknowledgement === false`): Space
persists its own UI acknowledgement cursor against Runtime/run terminal facts.
This avoids a false claim that one client's acknowledgement is global daemon
truth.

### Owner policy, rollback, and Electron boundary

Daemon and inline Coder use one profile fence. Do not compose
`status.preflight()` with a low-level unconditional stop: another client or run
can appear between those calls. v0.7.97 removed the combined rollback
transaction (`runtime.daemon.stopForInline()`); stopping the daemon and
changing the owner mode are now two explicit steps, and the owner mode never
changes implicitly. First stop the daemon through the fenced idle shutdown —
management rechecks preflight under the draining fence and returns a
structured `conflict` instead of stopping a busy daemon — then flip the owner
policy while no owner lock exists:

```ts
import {
  acquireKodaXInlineOwner,
  enableKodaXDaemonOwner,
  getKodaXRuntimeOwnerState,
  setKodaXRuntimeOwnerMode,
} from '@kodax-ai/kodax/runtime';

const management = await runtime.daemon.inspect();
if (!management.preflight.canStop) {
  showStopBlockers(management.preflight.blockers);
  return;
}

// Fenced idle stop; active work returns structured `conflict`.
const stop = await runtime.daemon.shutdown();

// `accepted` means the stop was taken. Wait through the public owner-state
// query; never infer release from a PID.
const shutdownDeadline = Date.now() + 30_000;
while (getKodaXRuntimeOwnerState({ homeDir: kodaxHome, profile: 'coder' }).owner) {
  if (Date.now() >= shutdownDeadline) throw new Error('Timed out waiting for daemon owner release.');
  await delay(25);
}
await runtime.close(); // Detach only; it does not perform a second stop.

// Explicit daemon→inline owner-mode change; rejected while an owner lock exists.
setKodaXRuntimeOwnerMode({
  mode: 'inline',
  expectedRevision: management.ownerPolicy.revision,
  homeDir: kodaxHome,
  profile: 'coder',
});
const inlineOwner = acquireKodaXInlineOwner({ homeDir: kodaxHome, profile: 'coder' });

// Later, after the inline owner has released its fence:
inlineOwner.close();
const daemonPolicy = enableKodaXDaemonOwner({ homeDir: kodaxHome, profile: 'coder' });
// daemonPolicy.revision is authoritative; no expectedRevision guess is needed.
```

Any management revision change, another logical client, active or queued run,
running/paused Workflow, non-terminal/unknown AgentTask, pending
AskUser/permission, or in-flight mutation returns structured `conflict`; the
daemon remains running and the owner mode remains unchanged. Draining also rejects
credential and Host Tool state changes without persisting their secrets or
results. The inline policy is sticky: later CLI auto-start is rejected until
`setKodaXRuntimeOwnerMode({ mode: 'daemon', ... })` or
`enableKodaXDaemonOwner()` changes it back to `daemon`. `runtime.close()` still
only detaches. Stale-owner handling validates the owned lock/state and never
kills a process merely because a PID was reused.

Keep all trusted objects in Electron Main: daemon token/endpoint, stable client
identity, owner policy, keychain broker, Host Tool handlers, and
permission-grant administration. Renderer IPC should expose product-specific
commands and sanitized projections only. Never pass daemon credentials,
leases, or trusted session/run context to renderer or model
tool arguments.

---

## 24. Runtime-owned permission routing and plan bridges (v0.7.96)

> The product equivalent is `view.interactions` plus `interactions.respond`.
> The Runtime helpers below are for trusted Host adapters, not client-created
> permission requests or alternate authorization owners.

The Runtime owns permission routing in inline and daemon deployments.
Clients select one of four profiles and must not add a second preflight gate:

```ts
await runtime.sessions.updateSettings(session.id, {
  permissionMode: 'auto', // 'plan' | 'accept-edits' | 'auto' | 'full-access'
  autoModeClassifierModel: 'zhipu:glm-5.2', // optional
  executionCwd: projectDirectory,
});
```

The public SDK types are `RuntimePermissionMode` for canonical stored/output
values and `RuntimePermissionModeInput` for accepted update input. Host-owned
policy is configured through `CreateKodaXRuntimeOptions.execPolicy` /
`RuntimeExecPolicyOptions` and `CreateKodaXRuntimeOptions.autoReview` /
`RuntimeAutoReviewOptions`. `KODAX_RUNTIME_SDK_CAPABILITIES` is exported for
pre-spawn checks; alpha.6 reports `runtimeAutoModeGuardrail:5` and
`sharedSessionSettings:2`.

ACP integrations can import the corresponding root SDK surface without
duplicating the mode list:

```ts
import {
  ACP_PERMISSION_MODE_IDS,
  type AcpPermissionMode,
  type AcpPermissionModeInput,
  type AcpRuntimePermissionMode,
} from '@kodax-ai/kodax';
```

`AcpPermissionMode` and `AcpRuntimePermissionMode` contain only canonical
stored/output values. `AcpPermissionModeInput` additionally accepts the legacy
`auto-in-project` alias at the input boundary.

`auto-in-project` remains an input-only compatibility alias for `auto`. Legacy
Auto engine, timeout, and speculative-window settings are ignored and omitted
from new writes. Auto always means Auto[LLM]; there is no selectable rules
engine.

### What an embedder should expect

```text
Plan mutation ------------------------------------> deny
Full Access -> Exec Policy -----------------------> one host attempt or deny; never prompt
Edits / Auto -> sandbox
                  | completed --------------------> return silently
                  | started or uncertain --------> return; never replay
                  ` proven pre-start boundary ---> Exec Policy
                                                    | Edits -> user decision
                                                    ` Auto  -> LLM review
                                                                | allow -> one host attempt
                                                                ` deny  -> safer-route result
```

The workspace sandbox permits broad host reads, workspace and platform-Temp
writes, external network access, and inherited host environment variables. On
Windows, the Temp grant is a private per-command child. It
does not permit arbitrary host writes. Sandbox completion is authoritative and
does not initialize or call Auto review. Only a proven pre-start denial or
unavailable backend may create a host-boundary decision. The Runtime owns the
single host retry; a tool implementation must never fall through and execute
the command itself.

Full Access samples the current profile once when each Bash call starts, then
skips the sandbox, every approval path, and built-in dangerous-command fallbacks.
Explicit `forbidden` rules still block; unmatched commands and
explicit `allow` rules run directly. An explicit `prompt` rule is rejected
under Never approval semantics and creates no Runtime permission event.

Exec Policy denials remain Bash text results, encoded as JSON with `code`,
`denialSource`, `source`, `sourcePath`, `permissionMode`, `matchedRules`,
`retryable: false`, `remediation`, and `guidance`. Sources distinguish explicit
administrator/user/trusted-project rules, built-in fallbacks in other profiles,
and policy configuration errors. Preserve these fields when displaying or passing
the denial to a model; do not label a KodaX rule as an OS restriction or recommend
rewriting the command to evade it.

Auto review uses a fixed reviewer role/output schema. The optional
`config.json#autoReview.policy` replaces only its security-policy body. The
first attempt has a 90-second deadline; one 180-second retry is permitted only
for timeout, provider failure, or invalid structured output. An explicit deny
does not retry. Infrastructure exhaustion returns a bounded deny telling the
Agent to use a safer route; it does not ask the user automatically, downgrade
the profile, or switch engines. Three consecutive denies, or ten denies among
the last fifty completed reviews in the current turn, stop that turn.

Low/medium-risk host-boundary operations are normally allowed. A concrete
high-risk operation requires narrow informed authorization present in trusted
conversation context; critical effects and administrator forbids remain
denied. A later natural-language user direction is reviewed semantically—there
is no approval command or keyword matcher.

The permission event's `inputPreview` remains a display-safe diagnostic
projection. Use the Runtime owner's typed tool input for execution; never
reconstruct or authorize an operation from the preview. If a permission event
times out, the operation is cancelled and the Agent receives a safer-route
instruction.

Exec Policy lives in `~/.kodax/exec-policy.jsonc` and the trusted repository's
`.kodax/exec-policy.jsonc`. Use `kodax execpolicy check -- <command>` to inspect
the exact matched source, rule, decision, and justification without execution.
Repository policy is never trusted merely because the current directory is a
Git checkout. A trusted host must opt canonical roots in explicitly:

```ts
const runtime = await createKodaXRuntime({
  execPolicy: {
    trustedProjectRoots: [projectDirectory],
    // adminRules may supply host-managed rules that model/run input cannot edit.
  },
});
```

`RuntimeExecPolicyOptions.adminRules` accepts `ExecPolicyRuleInput[]`, exported
from the root and `/coding` SDK surfaces. This trusted-host input deliberately
has no `source` or `sourcePath`: Runtime assigns `admin` / `host:admin`
provenance itself, and the daemon owner rejects either provenance field on the
wire. A renderer, model, or run cannot forge administrator ownership.

`match` and `notMatch` in JSONC are load-time positive/negative examples for
validating a prefix. `hostExecutable`, `network`, and `compound` are runtime
qualifiers and match only when the trusted integration can prove those facts.
The built-in Bash route never guesses unavailable operation facts.

### 0.7.x source compatibility

The v0.7.x public declarations retain the following migration aliases:

| Legacy source | Current source | Contract |
|---|---|---|
| `agentMode: 'amaw'` | `'ama'` | accepted as deprecated input and normalized to AMA; no separate AMAW runtime is restored |
| `SkillSource` | `ResolvedSkillSource` | formal source union remains `project \| user \| plugin \| builtin`; only resolved discovery output adds `learned` |
| `RuntimeDaemonPreflight.activeAgentTasks` | `activeAgentTurns` | both required fields are returned and reference the same array throughout the 0.7.x line |
| `permissionMode: 'auto-in-project'` | `'auto'` | accepted only as input and immediately canonicalized; never persisted or advertised as a fifth profile |
| persisted `permissionMode: 'default'` | `'accept-edits'` | legacy pre-four-profile records reopen as Edits instead of becoming unset |
| legacy Auto engine, timeout, and window fields | fixed Auto[LLM] review | accepted only as inert migration input; never persisted or exposed as selectable settings |
| `AutoModeRulesContext` | Auto[LLM] operation context | remains the active context type for `AutoModeCallAnalyzer`; its legacy name does not mean that an Auto Rules engine still runs |
| `AutoModeGuardrailConfig.rules`, `AutoModeRulesDecision`, `AutoModeRulesEvaluator`, `AutoModeGuardrailConfig.askUser`, `AutoModeAskUser*`, `AutoModeDecisionDiagnostics`, and Runtime permission `autoModeDiagnostics` fields | Runtime-owned Auto[LLM] facts/review | retained only as deprecated 0.7.x source/wire compatibility; Rules/evaluator/ask-user values are ignored, diagnostics may round-trip only as non-authorizing legacy metadata, and none of these fields restores Auto Rules or the removed automatic prompt path |
| `allowsAcceptEditsClassifierFallback` | no replacement | removed from the `/repl` barrel; the Runtime now owns the only shell boundary, so embedders must not install a second classifier fallback |
| legacy ACP `tool_permission_resolved.outcome` literals | current request outcomes | retained as deprecated source/wire-read variants for 0.7.x consumers, but alpha.6 never emits them |

### Plan capability is opt-in

`exit_plan_mode` is exposed to a Runtime run only when that run supplies an
approval bridge. A daemon or headless host that cannot approve a plan should
leave the bridge absent; KodaX removes the tool from that run's scope.

```ts
const planned = await runtime.runs.start({
  sessionId: session.id,
  prompt: 'Draft a migration plan, then ask for approval.',
  options: {
    events: {
      exitPlanMode: async () => showPlanAndAskUser(),
    },
  },
});
await planned.result;
```

The callback belongs in a trusted host process (for Electron, Main rather than
renderer). It is intentionally not inferred from the presence of a permission
UI: tool permission and plan approval are different user decisions.

See [ADR-069](../../docs/ADR.md#adr-069-sandbox-success-is-authority-while-host-escalation-is-a-separate-policy-boundary)
and [FEATURE_297](../../docs/features/v0.7.96.md#feature_297-codex-aligned-permission-profiles-sandbox-escalation-and-exec-policy)
for the current permission contract.

---

## 25. Always-on context compaction and bounded transcript recovery (v0.7.74)

> Product clients use `sessions.compact`, `observe`, `readItem`, `readHistory`,
> `readHistoryEntry` and `searchHistory`. Low-level transcript/event examples
> below do not imply an additional Product event replay surface.

Automatic large compaction is always enabled. `enabled` remains accepted for
v0.7.x source compatibility, but `false` is normalized to `true`.
`triggerPercent` defaults to `75` and is clamped to `15..90`. The optional
absolute threshold is inactive when omitted or zero; otherwise the smaller
percentage, absolute, and physical-capacity threshold wins.

```ts
const run = await startKodaX({
  provider: 'zhipu-coding',
  model: 'glm-5.2',
  compaction: {
    triggerPercent: 60,
    triggerTokens: 300_000,
  },
});
```

The recent raw tail is 20% of that effective trigger, not 20% of the model's
maximum context window. A manual Runtime compact bypasses only the trigger
comparison and uses the Session's same effective policy:

```ts
await runtime.sessions.updateSettings(session.id, {
  compactionTriggerPercent: 60,
  compactionTriggerTokens: 300_000,
});

await runtime.sessions.compact({
  sessionId: session.id,
  provider: 'anthropic',
  credential: {
    leaseId: credentialLease.id,
    mode: 'scoped',
    providers: ['anthropic'],
  },
});
```

Manual compact uses the same credential-aware summary implementation as
automatic compact. There is no client-supplied operation envelope: the daemon
itself mints the short-lived compaction identity for the scoped credential
target (a `compact_<uuid>` maintenance id bound to the stable
`session.compact` operation, not a fabricated Run ID) and validates lease,
Provider, and Session before the summary call. After a lost response, re-read
the Session's compaction state instead of retrying blindly.

Setting `compactionTriggerTokens: 0` removes the absolute Session override.
Percentage updates are normalized to `15..90`; negative/fractional absolute
values are rejected. Explicit per-run `options.compaction` values override
Session settings.

Large compaction covers the complete eligible prefix once, preserves an atomic
recent tail, and installs a synthetic user checkpoint. Every genuine user query
is rendered mechanically in its checkpoint ledger; tool-result wire messages
and synthetic prompts are excluded. The normal summary request preserves the
main request's system, message, tool, model, and reasoning prefix and appends a
text-only ephemeral instruction so providers can reuse prompt/KV cache.

The exact pre-compaction transcript has a separate durability guarantee. The
root host persists all pre-compaction messages (including messages created in
the active Run) before old payload is evicted from memory. Island records are
flushed before a slim main JSONL is published. If the main replacement fails,
main and sidecar may temporarily overlap, but stable entry IDs project the
logical entry once. A persistence failure keeps the exact live copy; child
compaction never writes root Session lineage.

The in-process `onCompactedMessages` callback may return a `Promise`. KodaX
awaits it before the next provider request and before
`context.compaction.finished`. Embedded and daemon Runtime execution always
uses Runtime-owned Session storage, regardless of a client-side
`persistedByHost` value; a daemon client cannot be the durability owner because
its callback is not present in the daemon process. Runtime-backed Ink and
classic REPL hosts therefore update only their live projection after the
Runtime acknowledgement; they do not perform a second Session write. If a
headless Runtime Run compacts before its first routine snapshot, Runtime seeds
the new Session from explicit Run metadata before applying the exact compact
transaction. A rejected durability callback also rolls back the tentative
`contextRevision`, so a later successful compact does not expose a phantom gap.

### Context-owned events

`context.compaction.finished` is the canonical post-commit Runtime fact. It
includes stable root/child identity, revision, before/after tokens, strategy,
effective trigger, protected budget, and component accounting. Consumers must
not use `scope: 'worker'` as a parent/child identity substitute.

Operational no-ops are exposed as `context.compaction.skipped`. Its structured
reason is one of `compactable_below_threshold`, `no_compactable_prefix`,
`low_savings_cooldown`, `covered_context_unchanged`, or
`circuit_breaker_cooldown`. A
started attempt always closes with `context.compaction.ended`; managed-task
attempts carry an `outcome`, structured `reason` for skips or failures, and
breaker state. Legacy events and non-managed compaction paths may contain only
`meta`. The
failure breaker counts only summary-generation and persistence failures, waits
two eligible boundaries before a half-open retry, and can rearm earlier after
meaningful compactable-token growth.

```ts
const subscription = runtime.events.subscribe(
  { sessionId: session.id, types: ['context.compaction.finished'] },
  (event) => {
    if (event.type !== 'context.compaction.finished') return;
    const fact = event.payload;
    if (fact.contextKind === 'root' && fact.committed) {
      renderRootContext(fact.tokensAfter, fact.tokensBefore);
    }
  },
);
```

Legacy `onCompactStats`/`onCompact` callbacks remain compatibility projections.
The old `onCompact` callback now receives the post-compact count; it no longer
echoes the pre-compact `currentTokens` value. Hosts that need ownership or
component metrics should use `onContextCompactionFinished` or the Runtime
event. Compatibility success callbacks fire only after a strict token
reduction has restored physical request validity and committed. An unchanged,
failed, stale, or still-oversized candidate is not a successful compaction.

### Transcript observation below the daemon frame limit

`sessions.observe()` no longer embeds `FullTranscriptSessionData`. Its snapshot
contains a bounded `RuntimeTranscriptSlice`. Inline entries carry the complete
transcript entry; an oversized entry carries an explicit descriptor.

```ts
const observation = await runtime.sessions.observe(session.id, onLiveEvent);
let page = observation.snapshot.transcript;

while (page) {
  for (const descriptor of page.entries) {
    if (descriptor.entry) consume(descriptor.entry);
    else await consumeEntryChunks(runtime, session.id, page.revision, descriptor.index);
  }
  if (!page.hasMore) break;
  page = await runtime.sessions.transcriptPage({
    sessionId: session.id,
    cursor: page.nextCursor,
  });
}
```

`transcriptEntryChunk()` returns lossless `base64-json` chunks. Concatenate the
decoded bytes and parse JSON only after `hasMore` becomes false. Page and entry
cursors are opaque and revision-bound. Runtime retains a bounded immutable
snapshot for an in-progress cursor, so new appends do not create duplicates,
gaps, or an endless moving boundary. Once that snapshot is no longer retained,
the next read returns `resync_required`; restart from a fresh observation.
All transcript/history methods accept `{ timeoutMs, signal }` as their final
read options in embedded and daemon mode. The shared daemon's
legacy `session.transcript` method rejects payloads above 512 KiB and names the
page/chunk methods rather than attempting a frame near the 8 MiB ceiling.

### Search compacted history before fetching exact content

Use `transcriptSearch()` when the host or user knows a historical detail but
not its page/index. It searches the authoritative main-plus-sidecar lineage and
returns bounded revision-bound hits with stable `entryId`/`logicalId`, entry
index, role/source, timestamp, active/compacted status, and a citation:

```ts
const found = await runtime.sessions.transcriptSearch({
  sessionId: session.id,
  query: 'permission test output capture',
  role: 'assistant',
  limit: 5,
});

for (const hit of found.hits) {
  renderSearchHit(hit.citation, hit.snippet);
  // For an oversized exact entry, pass found.revision + hit.entryIndex to
  // transcriptEntryChunk(); ordinary entries can be obtained from the page.
}
```

Search is deterministic Unicode lexical/metadata ranking, not an embedding or
background-model index. The Action LLM gets the corresponding
`session_history_search` and `session_history_read` pair only when its current
Run owns full-lineage-capable Session storage. A root Run reads its root
lineage. A persistent child Run gets a separately minted hidden
`managed-task-worker` Session and can recover only that child's compacted
history; it is never given root-history access. Storage-less Runs and a tool
visibility policy that hides either member expose neither member. Results are
low-authority historical evidence; current instructions and freshly verified
workspace state take precedence. System/control entries, hidden-only content,
synthetic current or legacy `[对话历史摘要]` checkpoints, and `[compacted]`
placeholders are neither searchable nor directly readable. Short ordinary
terms do not gain a metadata match merely because they occur inside a random
entry ID; direct identifier lookup is reserved for a sufficiently specific ID
query. Sessions compacted by older builds without an exact main/sidecar copy
cannot reconstruct bytes that were already discarded.

Clients that depend on these guarantees should require
`contextCompaction: 3`, `transcriptPaging: 1`, and `transcriptSearch: 1` during
connection.

---

## 26. Agent mailbox control versus SDK event telemetry (v0.7.74)

The model-visible `wait_agent` tool and the public Runtime Actor event APIs have
different jobs. Do not expose `runtime.agents.wait()` to the model as though it
were the same operation.

| Need | API | Wake/data contract |
|---|---|---|
| Let the action model yield until useful coordination evidence exists | `wait_agent({ timeout_ms })` | Caller-scoped Agent mailbox, root user input, interruption, or timeout; returns only a small acknowledgement. |
| Render or diagnose Actor activity | `runtime.agents.events(sessionId, afterSequence?)` | Bounded event snapshot/replay, including progress and terminal events. |
| Long-poll Actor telemetry from a host | `runtime.agents.wait(sessionId, afterSequence?, timeoutMs?)` | Returns the next sequenced Actor event, including progress. |
| Read one known result | `runtime.agents.output(sessionId, actorPath, turnId?)` | Bounded current/terminal output and structured artifact metadata. |
| Deliver a real user follow-up to the active root Run | `runtime.runs.submitInput(...)` | Ordered active-run input delivered at the next safe Runner boundary; requires `interruptInput:1`. |

For example, a host activity view can replay the current tail and then wait
from its last sequence without causing another action-model request:

```ts
const snapshot = await runtime.agents.events(session.id);
for (const event of snapshot) renderActorEvent(event);

const afterSequence = snapshot.at(-1)?.sequence;
const next = await runtime.agents.wait(session.id, afterSequence, 30_000);
if (next) renderActorEvent(next);
```

Model `wait_agent` has only `timeout_ms` in its schema (10,000 to 3,600,000 ms,
default 120,000). Actor progress and Runtime `system-reminder` messages do not
end that wait. A scoped Agent message/completion produces `mailbox`; queued root
input produces `user_input_pending`; cancellation and expiry produce
`interrupted` and `wait_expired`. Authenticated Agent evidence is drained at the
next safe Runner boundary as synthetic context, while root input remains a real
user turn. The acknowledgement itself never carries raw event batches.

Completion delivery is post-transcript and crash-recoverable. The Actor snapshot
persists the explicit root completion turn IDs that still await transcript
acknowledgement. A hard restart republishes only those IDs; a same-process
Runtime rebuild deduplicates the projected queue by child turn ID. Once the
parent transcript commits and acknowledges the completion, later restores do
not replay it. Legacy snapshots without the explicit pending set do not infer
replay work from historical mailbox content.

This separation changes no Actor event capability or daemon version: existing
SDK snapshot, replay, and long-poll clients keep their telemetry surface. It
only prevents high-frequency progress from becoming a model control signal.

---

## 27. Windows GUI background subprocess visibility (v0.7.75)

KodaX SDK hosts do not need to add process-wide console suppression around the
Runtime. Since the v0.7.75 release candidate, Runtime-reachable
non-interactive/background child processes request `windowsHide: true` at their
own spawn boundary. The covered paths include:

- memory and Git metadata probes;
- provider CLI execution and ACP servers;
- LSP acquisition and language servers;
- clipboard helpers, worktrees, review commands, and extension commands;
- managed-task checkpoints and sandbox helpers.

The contract is intentionally narrow. Explicit external editors, terminal
commands, and PTY sessions remain interactive. POSIX-only `ps`, `tmux`, and
sandbox branches are reviewed bundle-audit exceptions rather than Windows
visibility paths.

The bundled runtime entry points ship with the `dist/semantic-worker.js` and
`dist/constructed-handler-worker.js` sidecars (the former
`dist/runtime-worker.js` sidecar and its build-time child-process audit were
removed with the Worker facade in v0.7.97). The packaged Electron daemon smoke then
runs 20 ordinary queries with a Win32 probe and checks that the expected Git
children never own a visible console window. These checks validate the SDK
boundary, but they do not replace product-level validation in the packaged host.
KodaX Space should install the exact v0.7.75 tarball and complete
[`ISSUE_205_v0.7.75_REGRESSION_GUIDE.md`](../../docs/test-guides/ISSUE_205_v0.7.75_REGRESSION_GUIDE.md)
on Windows 10 and Windows 11 as a non-blocking product validation follow-up.
This follow-up does not gate SDK packaging, tagging, or publication.

---

## 28. Host-configurable Shell Execution Contract (v0.7.77)

The shared daemon is long-lived, so its startup `process.env.PATH` is not a
reliable description of every project's toolchain. A host can opt a Session
into a serializable shell contract:

```ts
await runtime.sessions.updateSettings(session.id, {
  executionCwd: projectDirectory,
  shellExecution: {
    version: 1,
    shell: {
      kind: 'pwsh',             // pwsh | powershell | cmd | bash | zsh
      profile: 'default',
    },
    environment: {
      inherit: 'filtered',
      // Trusted host code, not model input. Use it for a directory-aware
      // activation command when the shell profile does not switch on cwd.
      setup: 'fnm use --silent-if-unchanged',
      windowsPath: 'registry',
    },
    cache: {
      ttlMs: 30_000,
      refreshToken: 'toolchain-revision-1',
    },
    probeTimeoutMs: 10_000,
  },
});
```

An individual Run can supply `options.context.shellExecution`; a concrete Run
contract overrides the Session setting. An omitted value or explicit
`undefined` does not erase the Session setting. Use a `null` Session patch to
remove it.

The contract supports an optional absolute `shell.executable` (for example Git
Bash) and bounded fixed `shell.args`. Command/file/persistence/profile/server
and working-directory control flags are rejected from those fixed arguments.
`environment.set` is for non-secret host variables. `denyPatterns` can remove
additional names but cannot weaken the fixed execution-control deny set.
`inherit: "none"` retains only the OS variables required to start the selected
shell. On Windows, `windowsPath: "registry"` re-reads current Machine/User
environment values instead of reusing the daemon's startup PATH.

Shell profiles and command targets inherit the execution host environment,
including ordinary development credentials. A fixed internal deny set removes
KodaX/Electron execution-control variables. The obsolete
`KodaXOptions.sandbox.envPass`, config field, and environment bridge are inert
compatibility inputs and are omitted by new clients. An attached persistent
daemon must restart after host environment changes.

Resolution is two-stage and uses the effective cwd:

1. sanitize the bootstrap environment, including credentials for built-in,
   custom, active, inactive, and stacked runtime Providers;
2. start the selected shell, load the requested profile/setup, capture a
   random-framed environment, validate and sanitize it again;
3. execute the actual command through that same explicit interpreter.

The cache is in-memory and isolated by normalized contract, canonical cwd,
Session scratch identity, and refresh generation. TTL
is bounded to ten minutes; zero disables caching. Daemon restart clears it.
`clearShellExecutionEnvironmentCache()` is available for an in-process owner
that needs immediate global invalidation.

Native children, nested Actor turns, Workflow child paths, and deterministic
build/test/lint evaluators inherit the effective contract. Runtime exact-command
permission grants bind the interpreter family and contract fingerprint, so a
grant created under cmd cannot silently authorize the same command after a
switch to PowerShell or Bash.

Configured-shell failures are visible and fail closed: KodaX does not reinterpret
the command through another shell. When `shellExecution` is absent, KodaX keeps
the pre-v0.7.77 platform-shell interpreter behavior for compatibility; the
same inherited-environment and fixed execution-control deny contract applies. See
[`ISSUE_214_v0.7.77_REGRESSION_GUIDE.md`](../../docs/test-guides/ISSUE_214_v0.7.77_REGRESSION_GUIDE.md)
for cross-project, cache, cancellation, credential, and Windows argv checks.

---

## 29. Evidence-gated background Skill learning (FEATURE_263, v0.7.78)

> Product clients consume the Host-owned `client.learning` service. Bootstrap
> options below configure the trusted owner, not a separate UI learning engine.

F263 completes the existing Learning Center rather than introducing a second
queue or client-owned Skill store. Episode review runs after durable foreground
completion and stays off the active Run's latency path. A correction, failure,
or verifier result is Memory evidence first; it does not itself authorize a
Skill mutation.

A low-risk declarative Skill can enter automatic project-scoped testing only
after an explicit preserve-as-Skill request with verified terminal evidence,
or repeated independent root episodes plus independent verified artifact
evidence. The owner writes an immutable revision and its canonical capability
record before discovery can expose it. Formal/builtin/plugin/human Skills keep
precedence and cannot be shadowed. Protected/formal changes, user-global
promotion, and Extension authoring remain explicit user actions.

Hosts that require this behavior should negotiate both Runtime capabilities:

```ts
const runtime = await createKodaXRuntime({
  mode: 'daemon',
  requirements: {
    learningCenter: 1,
    skillLearningLoop: 1,
  },
  clientInfo: {
    name: 'my-host',
    instanceId: stableClientId,
    instanceSecret: keychainSecret,
  },
});

const snapshot = await runtime.learning.getSnapshot();
const page = await runtime.learning.list({ limit: 50 });

for await (const event of runtime.learning.subscribe({
  afterRevision: snapshot.revision,
})) {
  renderLearningEvent(event);
}
```

`loadFullTranscript()` remains the nullable compatibility API.
`readFullTranscript()` is the strict host/audit API: it reads main and sidecars
under one Session boundary without migration, execution recovery, takeover, or
repair. It reports `data_corrupt`, `version_incompatible`, `read_timeout`, and
`read_cancelled` instead of turning those cases into an empty/null history.
`readConversationHistory()` uses that same read-only boundary, then derives the
ordinary conversation projection without changing Session or Run state.

For an old or incompatible Session that cannot safely resume, use the
top-level `exportSessionBundle(id, options?)`. It returns the exact main,
`.islands.jsonl`, and legacy `.archive.jsonl` bytes plus hashes and
compatibility diagnostics. Export is read-only and fails closed on ambiguous
duplicate main files; it does not choose a Session, migrate it, or claim that
the task is resumable. Decode each file's `contentBase64` for the canonical
lossless bytes; `content` is only a UTF-8 compatibility preview. `byteLength`
and `sha256` are computed from the original bytes.

`runtime.learning` is the authoritative host surface:

| Need | API |
|---|---|
| Render inventory or one exact record | `list()` / `get()` |
| Render client-specific badges | `getSnapshot()` |
| Replay or follow durable lifecycle events | `events()` / `subscribe()` |
| Clear or defer only this client's notice | `acknowledge()` / `snooze()` |
| Explicitly control a learned revision | `reject()` / `disable()` / `rollback()` / `review()` / `trust()` |
| Promote to the user scope | `promote(nameOrSlugOrId, 'user')` |

Do not scan learned files and infer activation from their presence. Discovery
requires the canonical record, matching project identity, lifecycle,
fingerprint, regular-file checks, formal-name policy, and exact revision.
Testing admission permits one concurrent root binding and at most three
exact-revision invocations. Promotion requires independently verified success;
failed or inconclusive canaries return to Ready/attention. A Run retains the
revision it captured at admission, so rollback or replacement affects future
bindings without mutating an in-flight prompt.

Learning Center notification state is client-specific, but capability
lifecycle and project canary state are owner-global. Renderer code should
receive sanitized records/events through host IPC; it should not receive
daemon credentials or mutate files directly. Inline and daemon
facades expose the same learning methods. A host missing `skillLearningLoop:1`
may still support the older Ready/manual Learning Center surface, but must not
claim the complete F263 project-canary contract.

---

## 30. Standalone sandbox SDK (v0.7.78)

ASRT containment is a public SDK capability, not an Auto[LLM]-only
implementation detail. Import the dedicated subpath when a host needs to
sandbox its own commands or scripts:

```ts
import {
  activateKodaXSandbox,
  doctorKodaXSandbox,
  getKodaXSandboxCapability,
  getKodaXSandboxSetupGuidance,
  runKodaXSandboxed,
} from '@kodax-ai/kodax/sandbox';

const capability = getKodaXSandboxCapability();
const doctor = await doctorKodaXSandbox({ refresh: true });

if (!doctor.ready) {
  showSandboxInfo(getKodaXSandboxSetupGuidance(doctor));
  // Call only from an explicit interactive setup/onboarding action. On Windows
  // this may display UAC; ordinary SDK calls never invoke it.
  const activation = await activateKodaXSandbox();
  if (activation.status !== 'ready') {
    showSandboxInfo(activation.guidance);
  }
}
```

Platform behavior:

- Windows uses the pinned ASRT restricted-user/WFP setup. The parent terminal
  does not need to be elevated; activation requests UAC confirmation, and
  a healthy generation upgrade preserves the existing account SID. Activation
  proves one real no-side-effect target start before returning `ready`.
- macOS uses Seatbelt through `sandbox-exec` and requires ripgrep. Guide users
  to `brew install ripgrep` when doctor reports it missing.
- Linux uses bubblewrap and requires `bubblewrap`, `socat`, and `ripgrep`.
  Present the emitted `apt`/`dnf`/`pacman` guidance; do not run `sudo` or a
  package manager silently. The host must also permit unprivileged user
  namespaces. Do not change sysctls or AppArmor policy silently.

Do not call `activateKodaXSandbox()` during ordinary Runtime/daemon startup,
tool execution, or a background permission check. An SDK application that
wants CLI-equivalent self-healing should call doctor and, only from its own
interactive setup/onboarding surface, call activation before creating its
Runtime. KodaX's bare interactive Windows CLI does exactly that; print-mode and
daemon startup remain verify-only. Multiple activation callers converge through
the setup-only lock, and a follower rechecks the completed setup instead of
installing again.

### Run a host-owned command with an explicit policy

```ts
import os from 'node:os';
import path from 'node:path';
import { runKodaXSandboxed } from '@kodax-ai/kodax/sandbox';

const result = await runKodaXSandboxed({
  command: process.execPath,
  args: ['scripts/generate-report.mjs'],
  cwd: projectDirectory,
  filesystem: {
    allowRead: [projectDirectory, process.execPath],
    allowWrite: [projectDirectory, os.tmpdir()],
    denyRead: [],
    denyWrite: [path.join(projectDirectory, '.git', 'config')],
  },
  network: {
    mode: 'allowlist',
    origins: ['https://api.example.com'],
  },
  // true by default; set false explicitly for KodaX's minimal environment.
  inheritEnvironment: false,
  env: { REPORT_FORMAT: 'pdf' },
  timeoutMs: 120_000,
  maxOutputBytes: 2 * 1024 * 1024,
});

if (result.status === 'unavailable') {
  // The command was NOT run. Decide explicitly whether your product should
  // wait for setup, reject the operation, or use its own non-sandbox path.
  if (result.reason === 'backend_launch_failed') {
    reportBoundedDiagnostic(result.diagnostic);
  }
  showSandboxInfo(getKodaXSandboxSetupGuidance(result.doctor));
} else if (result.status === 'execution_uncertain') {
  // The target may have started. Do not retry blindly.
  throw new Error(result.diagnostic);
} else if (result.exitCode !== 0) {
  throw new Error(result.stderr || `sandboxed command exited ${result.exitCode}`);
}
```

The generic executor supports network `allow`, `deny`, and exact HTTP(S)
origin `allowlist` modes plus filesystem policy roots, environment inheritance,
timeout, cancellation, and bounded output. On POSIX, ASRT permits ordinary
reads by default and `denyRead` removes access. On Windows, a non-empty
per-command `denyRead` returns `unavailable` with reason `unsupported_policy`
before doctor, setup, DACL mutation, or target start because
`WRITE_RESTRICTED` does not enforce restricting SIDs for reads. `allowWrite`
defines the writable roots, while `denyWrite` removes
subtrees and always takes precedence over `allowWrite`. The HTTP(S) `origins`
are normalized to the hostname/port pair enforced by ASRT's network proxy. It
never silently runs without containment: sandbox unavailability is the typed
`{ status: 'unavailable', sandboxed: false, doctor, reason?, diagnostic? }`
result. `doctor_not_ready` means readiness failed before launch;
`backend_launch_failed` means the broker proved the wrapper could not spawn the
target; `unsupported_policy` means the requested platform policy cannot be
enforced. In every case the API does not report a sandboxed completion.
Missing, malformed, oversized, or invocation/backend-mismatched authority is a
separate `{ status: 'execution_uncertain', reason: 'attestation_failed', ... }`
result: the target may have started, so callers must not retry blindly. Broker
requests travel over stdin and authority returns over a bounded descriptor that
is not inherited by the sandbox or fallback target; ordinary files are not an
execution authority.

### v0.7.96 authority split: trusted text tools and native shell containment

KodaX v0.7.96 deliberately separates two authorities that older releases
coupled through one Windows workspace session. The text authority applies on
Windows, Linux, and macOS:

- KodaX's controlled `write`, `edit`, `multi_edit`,
  `insert_after_anchor`, and `undo` tools execute in the trusted Runtime host.
  Their safety boundary is final canonical-path authorization plus a
  handle-relative, revision-checked atomic text transaction. They do not enter
  ASRT, a workspace session, the native command runner, or a sandbox helper.
  Consequently sandbox setup, command-runner health, and command cleanup do
  not make these text tools unavailable. This is policy enforcement by the
  trusted KodaX process; hosts must not describe it as OS-token sandboxing.
  On Windows, replacing a file owned by an obsolete/current sandbox account
  automatically makes the replacement trusted-host-owned while retaining the
  ordered effective ACE policy. The filesystem may canonicalize DACL
  protection/inheritance control at the atomic namespace commit; stale
  inherited authority is not copied from an old parent, so embedders need no
  manual owner or ACL recovery step.
- Commands and scripts use the Windows native shell runner. ASRT supplies the
  dedicated account and network controls; the KodaX runner supplies the
  restricted token and policy capability SID. A nonce-bound private desktop
  requires the exact policy capability and keeps restricted loader
  initialization off the interactive desktop. The target is created suspended,
  attached to a no-breakaway/kill-on-close Job, and only then resumed. Framed
  IPC carries stdin, stdout, stderr, EOF, termination, and exit state.
  `CloseStdin` closes only target input and leaves the control stream alive;
  control and events use independent authenticated directional pipes, and
  cancellation/timeout sends `Terminate` and resolves only after validating a
  nonce-bound record proving the command Job empty. A packaged Electron target receives Node mode
  only at exec and scrubs `ELECTRON_RUN_AS_NODE` before target or child code.
- Native request and terminal records are host control state in a no-reparse,
  protected host/SYSTEM-only directory. The SDK rejects public allow roots
  overlapping that directory in either direction and deny roots at/below it;
  the native host reopens and checks canonical policy roots again before any ACL
  authorization or target creation. Internal startup readiness only verifies the
  state; explicit SDK/CLI doctor also runs one no-side-effect identity command
  with host fallback disabled. Explicit
  setup may create it or repair a no-reparse, host-owned direct cache child
  after proving the sandbox SID idle. Repair retires only expired dead-PID
  requests, aged unconsumed dead-PID network requests, or dead-owner terminal
  records with `jobDrained: true`. Atomic resume/started/deny staging is retired
  only after the encoded creator PID is dead and the file is older than two
  launch budgets; live, unexpired, malformed, unknown, and deny-recovery state
  stays fail-closed.
  Setup uses one elevated native parent with a small explicit base64 envelope
  naming a versioned, digest-bound, single-use request in this protected
  directory and verifies the non-ready `installing` marker. It synchronously
  converges NUL compatibility plus profile read capabilities; the caller
  atomically publishes the ready marker only after confirmed parent success.
  No helper overlaps ordinary admission, shared system Temp is not prewarmed or
  rewritten, and doctor and normal admission never invoke this setup path.

The unreleased Issue 341 fix changes bare interactive Windows CLI startup
(including `kodax -r`): a current disk marker must also pass a read-only check
of the live NUL device's sandbox-account grant before startup skips recovery.
The marker can survive a reboot while that device grant does not. Failure
enters the existing setup child/UAC boundary; historical read roots whose
files disappeared are excluded from installation preflight. SDK, daemon,
print-mode startup, doctor, and ordinary command admission do not gain
automatic setup or ACL repair. SDK hosts should run the explicit host setup
boundary when readiness requires activation, then recheck readiness.

The Windows private desktop uses an ephemeral full-policy capability. Persistent
filesystem authority instead uses stable capabilities derived from the
setup's persistent filesystem nonce, final handle-canonical root, and
`allowRead`/`allowWrite`/`denyWrite` clause. Every canonical root uses the same
stable capability ACE set; each command token activates only its authorized
clauses. Setup owns broad profile-root grants. Ordinary admission verifies those
roots without changing their DACL and converges missing grants only for
command-specific small roots.
The target's enabled Windows traverse privilege reaches an exact allowed root
without persistent ACEs on private ancestors; admission never rewrites a
profile/container DACL merely to make a descendant reachable. Because
`WRITE_RESTRICTED` does not apply restricting SIDs to reads, Windows
per-command `denyRead` is unsupported and fails closed before target start.
Command start/exit performs no logon-SID ACL mutation, cleanup, or receipt
publication. Warm policy ACL admission is read-only. Effective inherited
normal-token access is accepted; a missing exact restricted capability is
converged with `SET_ACCESS` and re-read without acquiring or waiting on a
cross-process target mutex. Artifact/control provisioning
and pre-cutover receipt recovery are setup work, not ordinary command admission.

Native protocol 10 requires the protected setup-marker path and digest on every
request. The host keeps that marker open without delete sharing until the
target's `Started` record is durable, which linearizes setup rotation with
target start without a global admission lock. Setup generation 10 upgrades a
healthy generation-8 account in place while preserving its SID/group and
filesystem nonce, and does not replay the generation-8 one-time legacy ACL
migration. Identity rotates only for missing or damaged account state.

A shared network broker is referenced while readiness or a command lease is
active and is detached from the Node event loop only while idle. Awaiting an
independent Runtime command therefore cannot exit early with an unsettled
top-level Promise, while an unused broker still cannot keep that Runtime alive.

The KodaX root and `/coding` exports of `runKodaX`, `startKodaX`,
`runManagedTask`, `createKodaXTaskRunner`, `createDefaultCodingAgent`, `KodaXClient`, and `Client` bind this native text host automatically when an embedder did not
provide one. The root set is evaluated again for every transaction, so a
linked worktree registered during the Session becomes writable without
recreating the client. Runtime-owned Runs use their authenticated registry;
an explicit host on a direct SDK call remains an embedder-owned policy seam.
The KodaX root and `/repl` `runInteractiveMode`/`runInkInteractiveMode`
entries bind the same host before starting a standalone REPL.
Consumers importing the independently usable `@kodax-ai/repl` workspace
package directly provide that host through `context.trustedTextMutationHost`;
the UI package does not import the root native owner.

On Windows, the embedded release manifest pins the text/shell sidecar protocols
and hashes plus the ASRT release version and hash. Verified bytes are copied
into a protected content-addressed LocalAppData store independent of
`KODAX_HOME`; the ASRT source is checked before materialization and the staged
executable is rechecked before broker startup. A fixed System32 PowerShell
process may perform this one-time ACL/bootstrap step; it never receives model
text, file-mutation content, or shell stdin. Shell policy cannot include that
store as a write root. The text artifact remains Host/SYSTEM-only, the shell
artifact grants read/execute to the dedicated sandbox group SID, and the ASRT
artifact grants local Users read/execute; none grants sandbox write/delete.
In a bundled build, the package-source ASRT file may be a package-store
hardlink: KodaX performs a handle-bound bounded read and accepts it only when
the complete bytes match the embedded digest. Filesystem development manifests
and sources remain single-link. The copied executable used by the broker
remains single-link, ACL-protected, and hash-verified. Embedders therefore do
not need to normalize the package manager's content-store layout.

There is no filesystem-effect lease spanning a command lifetime and no
owner/reset/allow-revoke/poison admission gate shared with text tools. Shells
from different Sessions, Runtime processes, and policies may run concurrently.
One Runtime reuses a healthy
broker only for an exact network-policy/setup-generation match. A readiness,
target-start, or terminal-proof failure immediately detaches that generation
from reuse without stopping unrelated holders. Each startup/control phase is
bounded to 15 seconds without replacing the command deadline. KodaX supplies
ASRT a 64-port range for up to 32 exact authorities and relies on OS bind
arbitration across Runtime processes, without a process-local capacity gate,
idle-broker eviction, hidden serialization, or authority sharing.
KodaX does not serialize arbitrary shell writes to the same file; those remain
ordinary OS data races. Revision/CAS conflict handling applies only to the
controlled text tools.

Issue 309 records a remaining Codex-compatible Windows boundary: stable root
capabilities do not override an explicit child DACL deliberately widened by its
owner to an ambient loader-compatibility trustee. Embedders requiring that
stronger adversarial-shell boundary need a different Windows token/loader
architecture rather than a command-lifetime KodaX lock.

On Linux and macOS, controlled text tools use the same host-owned native
transaction contract with a fixed mode-`0700` per-UID coordination root shared
across Runtime config homes and a separate protected Agent Home addon cache,
descriptor-verified addon loading, no-follow walking, kernel `flock`, CAS,
file/parent `fsync`, metadata preservation (including macOS extended ACLs), and
atomic rename. Sandboxed shell policy cannot write either root. Shells remain independently contained
per command through ASRT bubblewrap or Seatbelt/`sandbox-exec`; there is no
long-lived KodaX workspace-session owner or filesystem-effect lease.

KodaX's own local workspace-shell policy does not add KodaX-specific read
denials: Agent Home, ordinary credential locations, global Git configuration,
and workspace-local `.kodax/runtime` are readable. Writes remain bounded to
the workspace and platform Temp roots; Windows uses an empty per-command child
below system Temp. `.kodax/runtime` remains
write-denied even when the surrounding workspace is writable. Its per-Session
sequence cursor is a recoverable derived index: a lock-held durable write does
not require Windows DELETE sharing, retries short sharing conflicts, and a
truncated cursor is reconstructed from the durable event ledgers. A standalone
SDK host must declare any sensitive read paths required by its own threat
boundary.

On Windows, the workspace-shell adapter gives every shell a unique empty Temp
child and points `TEMP`, `TMP`, and `TMPDIR` to it. The shared system Temp/AppData
roots are not admission ACL targets, even when `KODAX_HOME` is nested below them.
POSIX keeps its platform-canonical Temp roots and inherited Temp variables.
Protected Agent Home directories are materialized only when an actual requested
write root contains them. Standalone `runKodaXSandboxed()` callers remain
responsible for ensuring every explicit policy root they supply exists.

`command` and `args` remain separate process arguments. On Windows KodaX uses
an encoded bootstrap followed by `shell: false`, so `%VAR%`, `&`, embedded
quotes, and spaces are not expanded or re-parsed by the host shell. The
explicit environment policy is overlaid into ASRT's fresh restricted-user
environment; ASRT-owned proxy, CA, and Git safety variables retain precedence.
`timeoutMs` covers the complete broker lifecycle, including ASRT
initialization, the command, and cleanup. Ordinary admission never provisions
artifacts/control state through synchronous PowerShell. A missing setup artifact
fails with setup guidance; cold additive ACL convergence shares one admission-
phase deadline across roots and never waits on a KodaX target mutex.

Custom shell adapters follow one lifecycle: `validateStart` immediately before
spawn, spawn the prepared executable, `closeInput`, optional `attestStart`, then
`cleanup` exactly once on every settlement path. Cancellation, timeout, or an
uncertain started process first calls `terminate` and waits for its drain proof,
then still calls `cleanup` exactly once to retire the prepared request and broker lease. An
attestation returns either `started` or a proven `pre_start_unavailable`; only
the latter may enter the separate host-permission boundary. If an embedder
omits the optional `attestStart` hook, it must not describe a background target
as proven started merely because the wrapper process spawned.

`runKodaXSandboxed()` follows that lifecycle itself on Windows. A generation
change or synchronous host-spawn exception is a proven `not_started` cleanup:
the native request and broker lease are released exactly once. After spawn it
uses target-start and terminal/Job-drain evidence; it never treats wrapper spawn
alone as proof that the requested command ran.

Each Windows command owns only its unique private-Temp leaf. The shared hashed
parent is never removed on the command path. After native lifecycle cleanup has
returned authoritative proof, a brief bounded leaf-removal failure is diagnostic
housekeeping and does not change the SDK result; before proof, cleanup remains
fail-closed and cannot cause host replay.

When ASRT is unavailable, or preparation fails before the target starts, KodaX
reaches a separate host boundary. Exec Policy is evaluated first; Edits uses a
user decision and Auto[LLM] uses an exact independent review. Only an allow may
start one ordinary host attempt. KodaX never retries after the target has
started or start is uncertain, so a sandbox fault cannot duplicate command
side effects. Remote A2A admitted Skill scripts
retain their stronger isolation contract and do not fall back to an
unsandboxed script. On current native protocol 10 that route is POSIX-only and
unavailable on Windows; Windows rejects its required per-command `denyRead` as
`unsupported_policy`. Embedded and daemon Runtime capability metadata expose
`sandboxRuntime` with the platform backend, ASRT version, supported control
dimensions, elevation behavior, and fallback semantics.

On Windows, each admitted command has an independent native-runner lifecycle.
Runner or ASRT startup failure returns a proven pre-start boundary result
without changing the text-tool authority. Once the target
has started, KodaX does not replay it. EOF, cancellation, timeout, runner
failure, and peer loss converge on that command's Job only; they do not reset a
workspace-wide filesystem owner or block later text transactions. macOS and
Linux retain per-command platform containment and the same no-replay rule;
neither backend is an admission dependency for trusted text transactions.

The final Windows target belongs to its Job at process creation. ASRT creates
the shared-account runner before KodaX code executes, so Issue 307 retains that
narrow pre-main upstream window; current Codex has the same runner-bootstrap
residual. Embedders must not report it as closed by KodaX's later runner
hardening. It does not affect trusted text tools.

Runtime event streams may also contain one terminal `tool.sandbox` observation
associated with the tool ID. `applied` is emitted only after the in-sandbox
bootstrap confirms that the real target process reached Node's `spawn` event;
wrapper startup alone is not sufficient. Before that handshake, a local
backend failure may reach host-boundary review. After it, KodaX never
restarts the target:

```ts
runtime.events.subscribe({ sessionId: session.id, type: 'tool.sandbox' }, (event) => {
  if (event.type !== 'tool.sandbox') return;
  const { observation } = event.payload.update;
  // observation.state: 'applied' | 'fallback' | 'not_selected'
  diagnostics.recordSandboxRoute(observation);
});
```

This event is optional diagnostics, not conversation content. It is never added
to model-visible messages. Default consumer UX should not render it in startup
output, command cards, notifications, or conversation history; expose it only
in an explicit advanced diagnostics view. KodaX's own Ink REPL does not
subscribe to the event and refreshes human-readable status only when the user
runs `/sandbox`. Explicit JSON output and SDK subscriptions retain the
structured event for professional diagnostics. `/sandbox` is read-only and
never activates the backend or requests elevation.

---

## Learned Skill promotion reference (v0.7.78)

Promotion is the explicit transfer of one immutable, reviewed `ready` or
`active_learned` Skill revision into the formal user catalog. It is not the
evidence-driven `testing -> active_learned` canary transition. The public named
service type is exported from the Runtime SDK:

```ts
import {
  createKodaXRuntime,
  type RuntimeLearningService,
} from '@kodax-ai/kodax/runtime';

const runtime = await createKodaXRuntime({
  requirements: {
    learningCenter: 1,
    skillLearningLoop: 1,
  },
});

const learning: RuntimeLearningService = runtime.learning;
const record = await learning.get('normalize-release-notes');

try {
  await learning.promote(record.capabilityId, 'user');
} finally {
  await runtime.close();
}
```

`name`, `slug`, and exact `capabilityId` are accepted. Exact IDs are preferred
when multiple projects expose the same display name or slug. `'user'` is the
only supported scope. Daemon clients need the server-issued
`learning:control` scope; advertising a client capability does not grant it.
Inline and daemon facades carry the same v2 learned-record shape and
promotion method.

The Runtime verifies the source is a regular non-symlink file inside the exact
project Learned Area and that its content still matches the recorded
fingerprint. It then creates the configured user Skill destination—normally
`~/.kodax/skills/<slug>/SKILL.md`—with atomic exclusive-publish semantics.
Existing identical content is idempotent; the final path appears only after the
complete temporary file is synced. Different formal content returns an
`action_failed` error and is never overwritten. On success the canonical
project record changes to `promoted_user`.

Terminal users can inspect the same contract with:

```text
/learn promote --help
/learn help promote
/help learn promote
```

The canonical command is
`/learn promote <name|slug|capability-id> --scope user`; omitting the scope is a
backward-compatible shorthand for the same user scope. Unknown, duplicate, or
unsupported options fail before the Runtime mutation.

---

## Migrating to v0.7.97

For the complete product-facing mapping, use the [SDK migration guide](../../docs/SDK_MIGRATION.md).
The table below covers removals in this development tree; it does not claim a
published `v0.7.97` package. Retained Runtime APIs are not automatically Product APIs.

v0.7.97 is a breaking SDK release for embedders. It removes the durable event
journal/replay surface, the generic operation envelope/receipts, the
crash-resumable exit-settlement protocol, and the Worker-hosted embedded
runtime. If you upgrade a host past v0.7.96, map every removed surface to its
replacement:

| Removed in v0.7.97 | Replacement |
|---|---|
| Operation envelope (`operation: { operationId }` on public control mutations), auto-generated operation IDs, `runtime.operations.get` receipts, and the `operationDeduplication` capability/requirement | Mutation identity comes from each mutation's own domain fields (explicit `sessionId` on create, returned `runId`, `expectedRevision` CAS on settings). After a lost response, re-read authoritative state (`runs.get`, `sessions.status`) and reconcile explicitly; there is no transparent retry or receipt query. |
| `settleKodaXRuntimeExit()` SDK export, `daemon.rollbackToInline`, client `stopForInline`, and the `runtimeExitSettlement:2` capability | `runtime.shutdown` / `runtime.daemon.shutdown()` is a real idle shutdown (busy → structured `conflict`). Daemon→inline ownership changes are explicit: `setKodaXRuntimeOwnerMode({ mode, expectedRevision })`, or owner-lock release plus `acquireKodaXInlineOwner()`. The owner mode never changes implicitly. |
| `event.subscribe`/`event.replay` RPCs, the `{ sessionId, journalEpoch, seq }` cursor, `journalEpoch` fields, and the `sessionEventJournal:1` capability | Events are a live in-process stream (`{ id, seq, time, sessionId, runId, turnId?, type, payload }`). Remote consumption reuses `session.observe` notifications; observation snapshots carry a `seq` high-water, live listener events are strictly greater, and `seq` never persists across restarts. Deleting/recreating a Session invalidates observations with `runtime_changed`. |
| Diagnostics RPCs `context.budget.get`, `tool.exposure.preview`, `provider.cache.diagnostics.get` (and the `runtime.diagnostics.latest*` facade) | Removed. `capabilities.contextDiagnostics: true` only gates diagnostic event notifications (`context.budget.snapshot`, `tool.exposure.planned`, `provider.cache.diagnostics`, `context.compaction.skipped`) on the live stream. |
| `isolation: 'worker'`, `worker: { configuredA2A: true }` (and `worker.*` options), `requirements.hardDispose`, and the `dist/runtime-worker.js` sidecar | Deleted. Use inline embedded or daemon mode. For the configured A2A plane, wire `createConfiguredA2ARuntimeIntegration({ configHome })` in the owner and pass its `runtimeOptions` as `externalAgents` — the Runtime itself never reads `integrations/a2a.json`. |
| Late-result redelivery after an abandoned read | Removed. `request.cancel`/`request.ack` remain daemon transport-control frames only; an abandoned read gets no late delivery. |
| The product mode surfaces: the CLI `--runtime-mode` flag, the `KODAX_RUNTIME_MODE` environment variable, and the `runtimeMode` key in `~/.kodax/config.json` | Removed in the fixed-Host release. The `kodax` CLI always starts-or-attaches the daemon owner; SDK callers keep the `mode: 'embedded' | 'daemon'` option on `createKodaXRuntime` (embedded stays a low-level path, never a product fallback). |
| `setThinking` REPL callback | Removed. Use `setReasoningMode` (the shared settings key is `reasoningMode`). |
| `getKodaXRuntimeOwnerPolicy` export | Removed. `getKodaXRuntimeOwnerState()` remains and reports policy, owner status, and the current owner in one call. |

Product UIs connect through `connectKodaXClient` from `@kodax-ai/kodax/client`.
The Host owns execution and saved history; `sessions.observe` delivers the
current display; `readItem` expands display references, while `readHistory`,
`readHistoryEntry` and `searchHistory` provide canonical history and its own
readable references. A display preview is not the full
message. The Runtime-to-product adapter is internal and is not an SDK export.

Keep an input's original text, artifacts and `inputId` until its outcome is
known. After a lost response, query that same Host with `inputs.read`; only a
confirmed withdrawal returns a queued input to the editor. A replacement Host
does not inherit the old Host's input identities.

Product rewind requires the head the user reviewed, so another client's newer
work cannot be silently discarded:

```ts
const lineage = await client.sessions.readLineage(sessionId);
await client.sessions.rewindSession(sessionId, {
  selector: targetEntryId,
  expectedHead: lineage?.activeEntryId ?? null,
});
```

On `conflict`, reload the lineage and let the user review the new state before
trying again. Rewind changes the conversation branch; it does not undo files.
Bound REPL Memory commands use the same daemon owner, and Workflow/Skill
execution uses real Runs with the Session's effective settings and tool policy.

Two compatibilities are unchanged and worth restating: the constructed-handler
worker (repo-intelligence and managed-task workers in `@kodax-ai/coding`) is a
separate, kept surface, and the `mode: 'embedded' | 'daemon'` option on
`createKodaXRuntime` still selects the ownership form. Host-minted compact
identity (`compact_<uuid>`, minted by the daemon for the scoped credential
target of manual compaction) still exists — it is Host-internal, not a client
envelope.

---

## Managed extension execution and Session Stop (FEATURE_299, v0.7.96)

A Stop button uses one owner-side operation:

```ts
const request = { sessionId, expectedRunId: activeRunId, requestId: crypto.randomUUID() };
const receipt = await runtime.sessions.cancel(request);
// Retry this exact request after a transport failure; keep requestId and binding.
// receipt.frontier and receipt.receipts describe the original accepted queue.
```

Require `runtime.capabilities.sessionCancellation.version === 1`. Unsupported
owners require an upgrade; clients must not replace this operation with a
list/abort loop. The Runtime fixes a durable Session order frontier, cancels its
queued Runs before its active Run, and preserves later submissions. It authorizes
from admitted Session/Profile/Run identity and the Runtime owner, independently
of Session history write locks. An incomplete delivery retains a request-specific
queue fence until the same request is repaired. Other successful requests cannot
release that fence.

A first request bound to an already terminal `expectedRunId` is rejected with
`code: 'conflict'`, `denialSource: 'stale_run'` and `retryable: false`, before
publishing a new Stop frontier. This check is atomic inside the Runtime; a
client-side status check is unnecessary. Already accepted requests remain
replayable after their Run ends, including after Runtime restart. Do not replace
a stale request's target with a later Run unless the user requests a new Stop.

`accepted` means a first durable cancellation request. A duplicate has
`accepted: false` without being denied. `state: 'unknown'` means cleanup has not
been confirmed. Await the Run result or observe Run lifecycle events for the
actual terminal outcome. Natural completion/failure wins a terminal race. Stop
covers owned child turns, running tools and pending interactions/interrupt
inputs; already delivered inputs remain in the audit trail. Independent earlier
Actor turns, other Sessions and Runs submitted after the frontier are outside
this request. CLI Ctrl+C and ACP Stop use the same Session operation; input
redirection retains the narrower `runs.abort` scope.

For an explicit tool operation without a model turn, require
`runtime.capabilities.toolInvocation.version === 1` and start a normal Run:

```ts
const run = await runtime.runs.start({
  sessionId,
  prompt: '!git status',
  options: { toolInvocation: { name: 'bash', input: { command: 'git status' } } },
});
const result = await run.result;
```

This uses ordinary tool visibility, permission rules, Run queue, events,
persistence and cancellation. `!command` uses this path. A nonzero Shell exit
is a failed tool invocation. No available execution owner is a structured
capability failure, rather than permission to execute a separate process.
Standalone Coding hosts use `runToolInvocation(options, invocation, prompt)`
and supply their normal host boundaries.

Existing extension registrations remain available. Managed tool handlers receive
`ctx.extensionExecution`; command handlers receive `context.extensionExecution`;
file capability provider `execute`, `read` and `getPrompt` handlers receive it as
a third argument. `api.getExecutionScope()` retrieves the same current scope.
`api.capabilities.executionScope` and `scopedSessionState` are version 1.

```ts
export default function activate(api: KodaXExtensionAPI) {
  api.registerCommand({
    name: 'inspect-source',
    description: 'Inspect a source file through host policy',
    handler: async (args) => {
      const scope = api.getExecutionScope();
      if (!scope) throw new Error('Managed execution is unavailable');
      scope.reportProgress({ message: 'Reading source', data: { path: args[0] ?? '' } });
      const content = await scope.invokeTool('read', { path: args[0] });
      return { message: String(content) };
    },
  });
}
```

The scope contains version, Session/Run/invocation/extension identity, the owning
AbortSignal, optional scoped Actor client and checked `invokeTool`. Nested tools
re-enter normal policy. Accepted managed tool effects are joined before the
handler settles, including calls the extension did not await. Progress is
versioned metadata on standard `tool.progress` events. An extension cannot
self-confirm Run settlement, manufacture owner authority, or use completion
hooks to veto user Stop.

Effectful slash commands run through their registered
`extension_command__<name>` tool and the Session owner. REPL embedders provide
`CommandCallbacks.executeToolInvocation`; both shipped terminal hosts do this.
Commands that only configure or inspect the extension host can declare
`execution: 'configuration'`; these run without a fabricated Run scope. Extension
activation also has no execution scope. Legacy `api.exec` and `api.webhook` are
trusted Node host utilities, not a sandbox or managed permission boundary; use
scope tools/Actor clients for managed work and never rewrite a rejected operation
through those legacy helpers.

Concurrent Sessions and Runtime instances retain their own controllers, tool
versions and extension state. Combined runtimes pin all participating members
before asynchronous admission. Reload changes future Runs; active handlers and
providers drain before disposal. Session records are JSON checkpoints, not
permission grants or authority to replay effects after restart. Current workflow
host APIs propagate the same owner identity/signal and distinguish requested
from confirmed Stop, including paused and already-cancelled owners. Moving the
workflow implementation and its distribution into an extension is a later task.

## See also

- [README.md](../../README.md) — end-user CLI quick start
- [docs/ADR.md ADR-024](../../docs/ADR.md#adr-024-npm-发布物正名-kodax-aikodax--sdk-subpath-exports-形式化-v0739) — SDK subpath architecture rationale
- [docs/ADR.md ADR-032](../../docs/ADR.md#adr-032-sdk-embedder-surface-closure-feature_186-v0742) — FEATURE_186 design record (all 8 phases)
- [docs/ADR.md ADR-057](../../docs/ADR.md#adr-057-large-compaction-is-an-always-on-context-scoped-full-coverage-transaction) — v0.7.74 compaction and exact-history ownership
- [docs/ADR.md ADR-058](../../docs/ADR.md#adr-058-model-agent-wait-is-mailbox-control-not-event-telemetry) — mailbox control versus Actor telemetry
- [docs/features/v0.7.42.md FEATURE_186](../../docs/features/v0.7.42.md#feature_186-sdk-embedder-surface-closure--kodax-space-gap-list--mcp-popout) — gap-by-gap landing matrix
- [docs/features/v0.7.74.md](../../docs/features/v0.7.74.md) — v0.7.74 release-candidate design and verification record
- [docs/features/v0.7.75.md](../../docs/features/v0.7.75.md) — v0.7.75 Windows GUI and Sidecar/Runtime stabilization candidate
- [docs/features/v0.7.77.md](../../docs/features/v0.7.77.md) — v0.7.77 adaptive-quality, governed-memory, and release-hardening record
